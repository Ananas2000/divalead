"""Windows transport for the original actual-plugin VST3 host (no DSP surrogate)."""
from pathlib import Path
import subprocess,threading,queue,os
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
PLUGIN=Path(r'C:\Program Files\Common Files\VST3\ZL Equalizer 2.vst3\Contents\x86_64-win\ZL Equalizer 2.vst3')
class WinVST3:
    def __init__(self,tag):
        self.tag=tag;self.lines=queue.Queue();self.transcript=[]
        self.proc=subprocess.Popen([str(Path(__file__).with_name('vst3_effect_host_20261024.exe')),str(PLUGIN)],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',bufsize=1,creationflags=subprocess.CREATE_NO_WINDOW)
        def read():
            for line in self.proc.stdout:self.lines.put(line.rstrip())
            self.lines.put(None)
        threading.Thread(target=read,daemon=True).start();self.ready=self.read('READY')
    def read(self,prefix):
        while True:
            line=self.lines.get(timeout=45);self.transcript.append(line)
            if line is None:raise RuntimeError(self.transcript[-20:])
            if line.startswith('ERROR'):raise RuntimeError(line)
            if line.startswith(prefix):return line
    def command(self,cmd,prefix):
        self.transcript.append('> '+cmd);self.proc.stdin.write(cmd+'\n');self.proc.stdin.flush();return self.read(prefix)
    def path(self,p):
        q=os.path.relpath(p,ROOT).replace('\\','/');assert q.isascii() and ' ' not in q;return q
    def load(self,p):
        reply=self.command('load '+self.path(p),'LOADED');assert reply=='LOADED 0 0',reply
    def save(self,p):return self.command('save '+self.path(p),'SAVED')
    def dump(self,p):return self.command('dump '+self.path(p),'DUMP')
    def set(self,id,value):return self.command(f'set {int(id)} {float(value):.17g}','SET')
    def plain(self,id,value):return self.command(f'plain {int(id)} {float(value):.17g}','SET')
    def text(self,id,value):return self.command(f'text {int(id)} {value}','SET')
    def render(self,x,folder):
        folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
        inp=folder/(self.tag+'_in.f32');out=folder/(self.tag+'_out.f32')
        np.asarray(x,dtype='<f4').tofile(inp)
        status=self.command(f'render {self.path(inp)} {self.path(out)}','DONE')
        y=np.fromfile(out,dtype='<f4').reshape(-1,2);assert y.shape==x.shape and np.isfinite(y).all()
        return y,status
    def close(self):
        if self.proc.poll() is None:
            self.proc.stdin.write('quit\n');self.proc.stdin.flush();self.proc.wait(timeout=20)
        assert self.proc.returncode==0,self.transcript[-20:]
