"""Keep the complete finite106 experiment; no automatic result adoption."""
from pathlib import Path
import json,shutil,subprocess,sys,time
H=Path(__file__).resolve().parent;R=H/'PRIMARY106_DETECTOR_JOINT_THREE_SWEEPS404';state=H.parent/'native-low-latency-effects/ORIGINAL_PRIMARY106_DETECTOR_JOINT_THREE_SWEEPS404_STUDY.json';s=json.loads(state.read_text());proc=Path('/proc')/str(s['PID']);start=(proc/'stat').read_text().split()[21];deadline=time.monotonic()+7200
while proc.exists():
 try:
  v=(proc/'stat').read_text().split()
  if v[21]!=start or v[2]=='Z':break
 except FileNotFoundError:break
 if time.monotonic()>deadline:raise TimeoutError('Actual106 study still running; do not label it completed')
 time.sleep(.5)
done=json.loads((R/'completion.json').read_text());scripts=R/'scripts';scripts.mkdir()
for name in ['study_PRIMARY106_detector_joint_three_sweeps404.py','Primary106_detector_joint_three_sweeps404_support.py','checked_joint_detector_primary_fit.py','normal_staged_primary_fit.py','watch_PRIMARY106_detector_full_backup.py']:shutil.copyfile(H/name,scripts/name)
args=[sys.executable,'-B',str(H.parent/'stereo-refinement-20261025/backup_complete_finite_study.py'),'--root',str(R),'--label','original-primary106-detector-joint-three-sweeps404','--note','Новый совместный поиск106 параметров: прежние94 плюс knee/RMS length/RMS mix/smooth активных MID20/MID21/SIDE22. Три ОБЩИХ настоящих native-входа, три прохода, два unseen; никаких усреднённых аудиофайлов. Детекторы и94 переменные менялись совместно; новый эффект не добавлен. Оба реальных хоста проходят neutral identity0/0, исходный component загружается перед каждым измерением. Оригинальная функция ошибки, все absolute/paired stereo допуски, 3ноты, ARP/ADSR/native12/POST/trim сохранены. Дополнительный финальный критерий чистоты: Air первых10<=контроль-0.005 dB, обаcold<=контроль. При положительном12тесте ещё нужны latest-context проверка/полный экспорт/независимый replay; этот архив ничего не принимает. Все сохранённые реальные WAV/state/106specs/оценки/код включены.']
if done.get('robust_improvement'):args.append('--retain-local-audio')
deadline=time.monotonic()+1800
while shutil.disk_usage('/workspace').free<96*2**20:
 if time.monotonic()>deadline:raise TimeoutError('Completed106 data preserved; insufficient staging reserve')
 time.sleep(.5)
subprocess.run(args,check=True)
