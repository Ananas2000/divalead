from pathlib import Path
J=Path(__file__).resolve().parent;V=J.parent/'continuation-20261104'
s=(J/'delta29_current620_support.py').read_text().replace('/tmp/divalead-native12-delta29-current620-20261107','/tmp/divalead-Diva-filter-families5-current-20261107').replace('ORIGINAL_NATIVE12_DELTA29_CURRENT620_STUDY.json','ORIGINAL_DIVA_FILTER_FAMILIES5_CURRENT_STUDY.json');(J/'Diva_filter_families5_support.py').write_text(s)
s=(J/'study_Diva_tone_axes620.py').read_text().replace('import Diva_tone_axes620_support as q','import Diva_filter_families5_support as q').replace('DIVA_TONE_AXES11_CURRENT620_OPT','DIVA_FILTER_FAMILIES5_CURRENT').replace('DivaToneAxes620','DivaFilterFamilies5').replace('Diva-toneaxes620','Diva-filter-families5').replace('Diva_toneaxes620','Diva_filter_families5')
s=s.replace("q.prior['source_accepted_cohort']==620","q.prior['full_public_kit_directory']=='ZL-WIP41'").replace("q.prior['full_public_kit_directory']=='ZL-WIP40'","q.prior['full_public_kit_directory']=='ZL-WIP41'")
a=s.index('axes=[');b=s.index('\ndef powers',a);s=s[:a]+"axes=[dict(section='VCF1',key='Model',index=147,origin=0,step=1)]\n"+s[b:]
s=s.replace("round(a['origin']+a['step']*v,2)","int(a['origin']+a['step']*v)")
a=s.index("baseline=evaluate('baseline',[0]*3)");b=s.index(' candidates=sorted(',a)
s=s[:a]+"baseline=evaluate('baseline',[0])\n for model in[1,2,3,4]:evaluate('filter-model-'+str(model),[model])\n"+s[b:]
s=s.replace("p.load(R/('ANCHOR40_PRIMARY.bin'if anchor else'PRIMARY.bin'));z.load(R/'POST.bin')", "p.load(R/('ANCHOR40_PRIMARY.bin'if anchor else'PRIMARY.bin'));z.load(R/('ANCHOR40_POST.bin'if anchor else'POST.bin'))")
needle="(R/'ANCHOR40_PRIMARY.bin').write_bytes(Path('/workspace/divalead/diva-lead/research/native-low-latency-effects/local-fl-studio/cloud-after-1625/2026-10-22/ZL-WIP40/verification/ZL40_PRIMARY_COMPONENT.bin').read_bytes())";assert needle in s;s=s.replace(needle,needle+"\n(R/'ANCHOR40_POST.bin').write_bytes(Path('/workspace/divalead/diva-lead/research/native-low-latency-effects/local-fl-studio/cloud-after-1625/2026-10-22/ZL-WIP40/verification/ZL40_POST_COMPONENT.bin').read_bytes())")
s=s.replace('actual_small_sync_oscillator_global_finetune_PWM','actual_filter_family_model_only').replace('all11_source_cases','all5_filter_model_cases')
s=s.replace('finite_actual_Diva_filter_families5_complete_not_adopted','finite_actual_Diva_filter_families5_complete_not_adopted')
a=s.index('"""');b=s.index('"""',a+3)+3;s='"""Actual Diva VCF filter families: all281/MIDI/chunk audit, same held3, fixed current FX."""'+s[b:]
assert "index=147"in s and "for model in[1,2,3,4]"in s and "R/'ANCHOR40_POST.bin'"in s
(J/'study_Diva_filter_families5_current.py').write_text(s)
print('Prepared five real Diva VCF models with all281/MIDI/chunk/source identity audits; all other synth/effect settings fixed')
