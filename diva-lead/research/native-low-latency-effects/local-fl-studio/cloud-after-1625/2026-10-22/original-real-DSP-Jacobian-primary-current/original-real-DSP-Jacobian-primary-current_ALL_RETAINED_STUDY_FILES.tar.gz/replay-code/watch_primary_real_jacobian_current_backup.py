from pathlib import Path
import json,os,subprocess,sys,time
H=Path(__file__).resolve().parent;N=H.parent/'native-low-latency-effects';state=N/'ORIGINAL_PRIMARY_REAL_JACOBIAN_CURRENT_STUDY.json';s=json.loads(state.read_text());pid=s['PID'];proc=Path('/proc')/str(pid);root=Path(s['root']);assert root==H/'PRIMARY_REAL_JACOBIAN_CURRENT'
try:start=(proc/'stat').read_text().split()[21]
except FileNotFoundError:start=None
deadline=time.monotonic()+7200
while start is not None:
 try:
  v=(proc/'stat').read_text().split()
  if v[21]!=start or v[2]=='Z':break
 except FileNotFoundError:break
 if time.monotonic()>deadline:raise TimeoutError('Still actual DSP; no false completed archive')
 time.sleep(.5)
done=root/'completion.json';positive=False
if done.exists():positive=json.loads(done.read_text()).get('robust_improvement',False)
else:(root/'INCOMPLETE_FINITE_STUDY_BACKUP.json').write_text(json.dumps(dict(job_ended_without_completion=True,last_controller=json.loads(state.read_text()),not_adopted=True),indent=2)+'\n')
args=[sys.executable,'-B',str(H.parent/'stereo-refinement-20261025/backup_complete_finite_study.py'),'--root',str(root),'--label','original-real-DSP-Jacobian-primary-current','--note','Новыйсовместныйпоиск PRIMARY94 черезчисленныереакции НАСТОЯЩЕГОDSP,несуррогата. ТриCOMMONinput,дваunseen;каждыйстолбецJacobian получендвумяреальнымипараметрическимирендерами,scaled/logграницысохранены. LMregularization/trustregionтолькопредлагаютточки,выбираетсяпоНЕИЗМЕННОМУoriginalcriterionиAir/stereoгейтам. Всефинальныестарыеfirst6AND10/cold2допускисохранены. Источник281/3длинныеARP/ADSR/native12/POST37/trimпрежние. Матрица/векторы/всеоставшиесяреальныеWAV/state/метрики/кодсохранены;непринятдополногоэкспорта/актуальногоконтекста. ПостоянноперезаписываемыеотвергнутыеSDKвыходыWAVневыдаютсязасохранённые.']
if positive:args.append('--retain-local-audio')
subprocess.run(args,check=True)
