from pathlib import Path
import json,os,subprocess,sys,time
H=Path(__file__).resolve().parent;N=H.parent/'native-low-latency-effects';state=N/'ORIGINAL_POST_LEFT_PRESENCE7_ORIGINAL37_STUDY.json';s=json.loads(state.read_text());pid=s['PID'];proc=Path('/proc')/str(pid);root=Path(s['root']);assert root==H/'POST_LEFT_PRESENCE7_ORIGINAL37'
try:start=(proc/'stat').read_text().split()[21]
except FileNotFoundError:start=None
deadline=time.monotonic()+7200
while start is not None:
 try:
  v=(proc/'stat').read_text().split()
  if v[21]!=start or v[2]=='Z':break
 except FileNotFoundError:break
 if time.monotonic()>deadline:raise TimeoutError('Still actual DSP; no false completed archive')
 time.sleep(.5)
done=root/'completion.json';positive=False
if done.exists():positive=json.loads(done.read_text()).get('robust_improvement',False)
else:(root/'INCOMPLETE_FINITE_STUDY_BACKUP.json').write_text(json.dumps(dict(job_ended_without_completion=True,last_controller=json.loads(state.read_text()),not_adopted=True),indent=2)+'\n')
args=[sys.executable,'-B',str(H.parent/'stereo-refinement-20261025/backup_complete_finite_study.py'),'--root',str(root),'--label','original-Left-presence7-on37-negative','--note','72малых LeftPeak/HighShelf среза в unusedPOSTslot7 относительно полного37/актуальногоPRIMARY. Задача уменьшить остаточный upperL/Rперекос и приблизить самтембр; прямые точки не прошли полныеусловия и НЕприняты. НастоящийZLenum проверен: HighShelf type3, type2на делеLowPass; ошибочное предположение поймано ДОcandidateaudio/принятия. Калибровка реальнымимпульсом доказывает правыйканалunity0, левыйсрез0dBна100Hz/-.5dBна2kHz/-1dBна10kHz иPDC0. В основнойсерииsourceDiva281/3длинные/ARP/ADSR/native12/PRIMARY/POST0..6/nativeTrimпрежние; требовалось такжеулучшениеupperLRerrorкаждойпары>=.02dB. Все72точныхstate/XML/метрики, три native/controltrainingWAV, calibrationWAV икодсохранены. Только recordimprovingдопустимыеtrainingWAVхранятся; отвергнутыефайлывыхода перезаписывалисьроднымрендером. Основнойполный37сохранён.']
if positive:args.append('--retain-local-audio')
subprocess.run(args,check=True)
