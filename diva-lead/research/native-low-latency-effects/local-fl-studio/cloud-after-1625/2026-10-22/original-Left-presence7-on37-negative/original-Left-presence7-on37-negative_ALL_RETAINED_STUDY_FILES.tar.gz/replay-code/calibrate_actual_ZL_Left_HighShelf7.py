from pathlib import Path
import csv,hashlib,json,os
import numpy as np,soundfile as sf
from win_vst3 import WinVST3,D
H=Path(__file__).resolve().parent;R=H/'LEFT_HIGHSHELF7_CALIBRATION37';R.mkdir();P=Path('/workspace/divalead/diva-lead/research/native-low-latency-effects/local-fl-studio/cloud-after-1625/2026-10-22/ZL-WIP37/verification/ZL37_POST_COMPONENT.bin');params={r['title']:int(r['id'])for r in csv.DictReader((D/'ZL-default-parameters.tsv').open(),delimiter='\t')};z=WinVST3('LeftShelf7-calibration-'+str(os.getpid()))
try:
 z.load(P)
 for k in range(24):z.set(params['Filter Status'+str(k)],0)
 for title,value in [('Filter Status',1),('Filter Type',.3),('LRMode',.25),('Order',1/6),('Dynamic ON',0)]:z.set(params[title+'7'],value)
 for title,value in [('Freq',2000),('Q',.707),('Gain',-1)]:z.text(params[title+'7'],str(value))
 z.save(R/'LEFT_HIGHSHELF7.bin');z.dump(R/'PARAMETERS.tsv');rows=list(csv.DictReader((R/'PARAMETERS.tsv').open(),delimiter='\t'));row=next(x for x in rows if x['title']=='Filter Type7');assert 'shelf'in row['display'].lower()and'high'in row['display'].lower(),row;assert z.latency()==0
 impulse=np.zeros((65536,2),np.float32);impulse[4096]=.05;y,status=z.render(impulse);sf.write(R/'IMPULSE_INPUT.wav',impulse,48000,subtype='FLOAT');sf.write(R/'ACTUAL_LEFT_HIGH_SHELF_OUTPUT.wav',y,48000,subtype='FLOAT');np.testing.assert_allclose(y[:,1],impulse[:,1],rtol=0,atol=2e-7);f=np.fft.rfftfreq(len(y),1/48000);a=np.fft.rfft(y,axis=0);diff=20*np.log10(np.maximum(abs(a[:,0]),1e-15)/np.maximum(abs(a[:,1]),1e-15));sample={str(freq):float(diff[np.argmin(abs(f-freq))])for freq in [100,1000,2000,10000]};assert abs(sample['100'])<.01 and abs(sample['2000']+.5)<.03 and abs(sample['10000']+1)<.03;proof=dict(actual_plugin_type_display=row['display'],actual_minimum_phase_ZL_PDC=0,right_channel_unity_max_error=float(abs(y[:,1]-impulse[:,1]).max()),actual_left_minus_right_transfer_dB=sample,only_left_HighShelf7_active=True,source37_POST_SHA256=hashlib.sha256(P.read_bytes()).hexdigest(),not_adopted=True,reference_match_reached=False);(R/'RESULTS.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof),flush=True)
finally:z.close()
