"""Real Chorus depth/wet and primary coadapt, original score plus less excessair."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,os,tarfile,threading,traceback
import numpy as np,soundfile as sf
from native_chain import NativeChain
from fl20_curve import apply_candidate,native_dsp_settings_SHA256
from normal_real_ZL_refit import RealPrimaryFit
from win_vst3 import WinVST3
H=Path(__file__).resolve().parent;A=Path('/workspace/divalead-work/pc-stereo-20261024');N=Path('/workspace/divalead-work/native-low-latency-effects');R=H/'CHORUS_AIR_PRIMARY_JOINT_CANONICAL';R.mkdir();STATE=N/'ORIGINAL_CHORUS_AIR_PRIMARY_JOINT_CANONICAL_STUDY.json';prior=json.loads((A/'stereo-continuous87/BEST_CANDIDATE.json').read_text());seed=prior['native_base'];base=np.array(seed['x']);bundle=seed['native_saved_state_bundle'];bundle_dir=Path(bundle['directory']);assert prior['native_base_export_directory'].endswith('_10')
for name,key in [('PRIMARY.bin','native_ZL_component_state'),('POST.bin','post_ZL_component_state')]:(R/name).write_bytes(Path(prior[key]).read_bytes())
(R/'PRIOR_CONFIRMED.json').write_text(json.dumps(prior,indent=2)+'\n');os.environ['DIVALEAD_NATIVE_OBJECTIVE_ROOT']=str(R/'assessment')
from fl20_objective import FeaturesOriginal,a
f=FeaturesOriginal();cache=threading.local();power_function=a.powers
def capture_power(*args,**kw):
 result=power_function(*args,**kw);cache.power=result[0];return result
a.powers=capture_power
assert a.BANDS[4:6]==[(3500,4500),(4500,6500)];reg=float(np.sum(base[:28]**2))*.00000025;ref,sr=sf.read('/workspace/divalead/diva-lead/v83-wip/Diva_original_lead_reference.wav',always_2d=True);np.testing.assert_array_equal(ref,a.REF);freq=np.fft.rfftfreq(len(ref),1/48000);masks=[(freq>=lo)&(freq<hi)for lo,hi in [(300,800),(2000,5000),(5000,10000),(10000,14000)]]
def lr(y):
 p=abs(np.fft.rfft(y,axis=0))**2;return np.array([10*np.log10(p[m,0].sum()/p[m,1].sum())for m in masks])
target=lr(ref);maximum_training_air=None
def assess(y,extra=False):
 r=f.residual(y[:288000]);last=f.local.last;error=10*np.log10(np.maximum(cache.power,1e-15)/np.maximum(a.TP,1e-15));assert abs(float(np.sqrt(np.mean(error[:,4:,2:]**2)))-last['metrics']['upper_off'])<1e-6
 air=float(np.maximum(error[:,4:6,2:],0).mean());edit=a.h.edit_aligned(a.h.align_with_pdc(y,dict(alignment_frames=819),latency=0));v=lr(edit);passed=bool(np.sqrt(np.mean((v[1:]-target[1:])**2))<=1.5 and max(abs(v[1:]))<=1.6 and abs(v[0]-target[0])<=3.35)
 return dict(loss=float(r@r)+reg,assessment=last,positive_excess_air_3500_6500_dB=air,LR_dB=v.tolist(),original_stereo_preservation_passed=passed,stereo_preservation_passed=bool(passed and(not extra or air<=maximum_training_air)))
def native(s,tag):
 c=NativeChain(s['source_manifest']['native_input'],tag,fl_graph=True,phase_pair=True,engine_override='fl_native_fl20_host.exe');apply_candidate(c,np.array(s['x']),s)
 for key,value in s['chorus_overrides'].items():c.set(3,int(key),int(value))
 return c
def cascade(raw,p,z,primary):
 p.load(primary);z.load(R/'POST.bin');mid,_=p.render(raw);out,_=z.render(mid);assert p.latency()+z.latency()==0;return out
def record(phase,**kw):
 s=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),original_is_the_only_target=True,source_Diva_MIDI_ARP_ADSR_WS52_other11_native_POST_unchanged=True,Chorus_depth_slotmix_and_primary_varied=True,not_adopted=True,reference_match_reached=False,**kw);p=STATE.with_suffix('.partial');p.write_text(json.dumps(s,indent=2)+'\n');p.replace(STATE)
def add(tar,name,y,members):
 b=io.BytesIO();sf.write(b,y,48000,format='WAV',subtype='FLOAT');data=b.getvalue();entry=tarfile.TarInfo(name);entry.size=len(data);tar.addfile(entry,io.BytesIO(data));members.append(dict(name=name,SHA256=hashlib.sha256(data).hexdigest()))
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(original_score_weights_alignment_and_stereo_gates_unchanged=True,training_native_audio_from_reloaded_serialized_state=True,binary_exact_wet_ratios=True,strict_FST_absolute_gate=2e-7,model_rejected_if_serialization_gate_fails=True,BOTH_first6_and_first10_gain_over_max_floor_and_3SEM=True,floor=.0005,warm10_cold2=True,extra_first10_positive_offharmonic_excess_reduction_3500_6500_dB=.05,extra_both_cold_air_excess_reductions_positive=True,air_measured_on_same_existing_MidSide_offharmonic_features=True,source_and_WS52_unchanged=True),indent=2)+'\n')
models=[dict(name='depth1900_wet5800',depth_raw=1900,wet_raw=5800),dict(name='depth1750_wet6000',depth_raw=1750,wet_raw=6000),dict(name='depth1600_wet6200',depth_raw=1600,wet_raw=6200)];fit=None;hosts=[];natives=[];results=[]
try:
 record('capture_three_NEW_control_native10_inputs');c=native(seed,'ChorusAirSaved-control-training');natives=[c];p=WinVST3('ChorusAirSaved-control-primary');z=WinVST3('ChorusAirSaved-control-post');hosts=[p,z];controls=[]
 for k in range(3):
  raw,_=c.render();out=cascade(raw,p,z,R/'PRIMARY.bin');controls.append(assess(out));sf.write(R/f'CONTROL_NATIVE_{k}.wav',raw,48000,subtype='FLOAT');sf.write(R/f'CONTROL_PROCESSED_{k}.wav',out,48000,subtype='FLOAT')
 c.close();natives=[];p.close();z.close();hosts=[];control_mean=float(np.mean([x['loss']for x in controls]));control_air=float(np.mean([x['positive_excess_air_3500_6500_dB']for x in controls]));maximum_training_air=control_air-.05
 for model in models:
  folder=R/model['name'];folder.mkdir();c=native(seed,'ChorusAirSaved-'+model['name']);natives=[c];x=base.copy();x[87]=model['depth_raw']/5000;x[93]=model['wet_raw']/12800;c.set(3,1,model['depth_raw']);c.gain(0,1-x[93]);c.gain(1,x[93]);manifest=[];saved=folder/'saved-native-bundle'
  for row in bundle['manifest']:
   path=saved/row['state'];path.parent.mkdir(parents=True,exist_ok=True);c.save_state(row['node'],path)
   if row['node']!=3:assert path.read_bytes()==(bundle_dir/row['state']).read_bytes()
   manifest.append(dict(row,state_SHA256=hashlib.sha256(path.read_bytes()).hexdigest(),state_bytes=path.stat().st_size))
  newseed=dict(seed,x=x.tolist());newseed['native_saved_state_bundle']=dict(bundle,directory=str(saved),manifest=manifest,settings_SHA256=native_dsp_settings_SHA256(x,newseed));(folder/'NATIVE_CANDIDATE_RESEARCH_ONLY.json').write_text(json.dumps(newseed,indent=2)+'\n')
  c.close();natives=[];c=native(newseed,'ChorusAirSaved-canonical-'+model['name']);natives=[c]
  for k in range(3):
   raw,_=c.render();raw.astype('<f4').tofile(folder/f'frozen-native-{k}.f32');sf.write(folder/f'TRAINING_NATIVE_{k}.wav',raw,48000,subtype='FLOAT')
  c.set(3,1,0);expected,_=c.render();fresh=native(newseed,'ChorusAirSaved-state-replay-'+model['name']);natives=[c,fresh]
  try:
   fresh.set(3,1,0);again,_=fresh.render();error=float(abs(expected-again).max())
   if error>2e-7:
    sf.write(folder/'REJECTED_WARM_CANONICAL_ZERO_DEPTH.wav',expected,48000,subtype='FLOAT');sf.write(folder/'REJECTED_FRESH_CANONICAL_ZERO_DEPTH.wav',again,48000,subtype='FLOAT');results.append(dict(model=model,folder=str(folder),training_cases=0,serialization_gate_failed=True,native_zero_depth_replay_max_abs_error=error,all_heldout_stereo_and_air_passed=False,not_adopted=True));(R/'COMPLETED_MODEL_REFITS.json').write_text(json.dumps(results,indent=2)+'\n');record('model_rejected_unchanged_absolute_FST_gate',model=model,error=error,absolute_gate=2e-7);continue
  finally:fresh.close();c.close();natives=[]
  fit=RealPrimaryFit(folder,R/'PRIMARY.bin',R/'POST.bin',lambda y:assess(y,True),lambda phase,**kw:record('actual_Chorus_air_and_primary87_refit',model=model,fit_phase=phase,**kw));initial,current=fit.fit(sweeps=2);held=[fit.evaluate(('heldout-'+str(k),current['x']),k,False)for k in [1,2]];p,z=fit.clients[0];fit.configure(p,current['x']);p.save(folder/'PRIMARY_MODEL.bin');mid,_=p.render(input_file=folder/'frozen-native-0.f32');z.load(R/'POST.bin');out,_=z.render(mid);sf.write(folder/'SELECTED_TRAINING_FULL_WIP.wav',out,48000,subtype='FLOAT');(folder/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(fit.rows).encode(),mtime=0));result=dict(model=model,folder=str(folder),training_cases=len(fit.rows),initial=initial,training_candidate=current,heldout=held,heldout_mean=float(np.mean([x['loss']for x in held])),heldout_air=float(np.mean([x['positive_excess_air_3500_6500_dB']for x in held])),all_heldout_stereo_and_air_passed=all(x['stereo_preservation_passed']for x in held),native_other11_state_bytes_exact=True,native_zero_depth_replay_max_abs_error=error,not_adopted=True);results.append(result);(folder/'SCREEN_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');fit.close();fit=None;(R/'COMPLETED_MODEL_REFITS.json').write_text(json.dumps(results,indent=2)+'\n');record('Chorus_air_model_completed',model=model,heldout_mean=result['heldout_mean'],control_mean=control_mean,heldout_air=result['heldout_air'],control_air=control_air)
 eligible=[x for x in results if x['all_heldout_stereo_and_air_passed']];winner=min(eligible,key=lambda x:x['heldout_mean'])if eligible else None;ready=bool(winner and control_mean-winner['heldout_mean']>.0003);summary=dict(training_cases=sum(x['training_cases']for x in results),control_mean=control_mean,control_air=control_air,maximum_training_air=maximum_training_air,winner=winner,sufficient_screen=ready,robust_improvement=False,original_is_the_only_target=True,requires_latest_context_revalidation=True,not_adopted=True,reference_match_reached=False);(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
 if ready:
  folder=Path(winner['folder']);newseed=json.loads((folder/'NATIVE_CANDIDATE_RESEARCH_ONLY.json').read_text());c0=native(seed,'ChorusAirSaved-confirm-control');c1=native(newseed,'ChorusAirSaved-confirm-candidate');natives=[c0,c1];p0=WinVST3('ChorusAirSaved-confirm-primary-control');z0=WinVST3('ChorusAirSaved-confirm-post-control');p1=WinVST3('ChorusAirSaved-confirm-primary-candidate');z1=WinVST3('ChorusAirSaved-confirm-post-candidate');hosts=[p0,z0,p1,z1];captures=[];members=[]
  with tarfile.open(R/'TWELVE_NEW_NATIVE_PROCESSED_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in [10,11]:
     c0.close();c1.close();c0=native(seed,'ChorusAirSaved-cold-control-'+str(rep));c1=native(newseed,'ChorusAirSaved-cold-candidate-'+str(rep));natives=[c0,c1]
    raw0,_=c0.render();old=cascade(raw0,p0,z0,R/'PRIMARY.bin');d0=assess(old);raw1,_=c1.render();new=cascade(raw1,p1,z1,folder/'PRIMARY_MODEL.bin');d1=assess(new);captures.append(dict(rep=rep,control=d0,candidate=d1,improvement=d0['loss']-d1['loss'],air_excess_reduction=d0['positive_excess_air_3500_6500_dB']-d1['positive_excess_air_3500_6500_dB']))
    for name,y in [('native-control',raw0),('native-candidate',raw1),('control',old),('candidate',new)]:add(tar,f'{name}-{rep}.wav',y,members)
    if rep==0:
     for name,y in [('NATIVE_CONTROL',raw0),('NATIVE_CANDIDATE',raw1),('CONTROL',old),('CANDIDATE',new)]:sf.write(R/(name+'_00.wav'),y,48000,subtype='FLOAT')
    record('fresh6_AND_first10_cold2_and_less_air',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  delta=np.array([x['improvement']for x in captures]);air=np.array([x['air_excess_reduction']for x in captures]);s6=float(np.std(delta[:6],ddof=1)/np.sqrt(6));s10=float(np.std(delta[:10],ddof=1)/np.sqrt(10));robust=bool(np.mean(delta[:6])>max(.0005,3*s6)and np.mean(delta[:10])>max(.0005,3*s10)and min(delta[10:])>0 and np.mean(air[:10])>=.05 and min(air[10:])>0 and all(x['candidate']['original_stereo_preservation_passed']for x in captures));summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(np.mean(delta[:6])),first6_SEM=s6,first10_mean_improvement=float(np.mean(delta[:10])),first10_SEM=s10,cold2_improvements=delta[10:].tolist(),first10_mean_air_excess_reduction=float(np.mean(air[:10])),cold2_air_excess_reductions=air[10:].tolist(),robust_improvement=robust)
  with tarfile.open(R/'TWELVE_NEW_NATIVE_PROCESSED_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_Chorus_air_primary_study_complete_not_adopted',robust_improvement=summary['robust_improvement'],sufficient_screen=ready);print(json.dumps({k:v for k,v in summary.items()if k not in ['winner','captures','archive_members']}),flush=True)
except BaseException:record('failed_preserve_full31_and_current_best',error=traceback.format_exc());raise
finally:
 if fit is not None:fit.close()
 for c in natives:c.close()
 for c in hosts:c.close()
