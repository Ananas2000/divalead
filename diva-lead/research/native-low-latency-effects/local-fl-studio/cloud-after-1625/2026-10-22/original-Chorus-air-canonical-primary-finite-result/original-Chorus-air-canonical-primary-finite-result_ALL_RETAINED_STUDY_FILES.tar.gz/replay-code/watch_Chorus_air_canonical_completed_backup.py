"""One-shot durable backup of the current finite job; never claims a match."""
from pathlib import Path
import json,os,subprocess,sys,time
H=Path(__file__).resolve().parent;N=Path('/workspace/divalead-work/native-low-latency-effects');s=json.loads((N/'ORIGINAL_CHORUS_AIR_PRIMARY_JOINT_CANONICAL_STUDY.json').read_text());pid=int(s['PID']);proc=Path('/proc')/str(pid);root=Path(s['root']);assert root==H/'CHORUS_AIR_PRIMARY_JOINT_CANONICAL'
try:start=(proc/'stat').read_text().split()[21]
except FileNotFoundError:start=None
deadline=time.monotonic()+7200
while start is not None:
 try:
  stat=(proc/'stat').read_text().split()
  if stat[21]!=start or stat[2]=='Z':break
 except FileNotFoundError:break
 if time.monotonic()>deadline:raise TimeoutError('Finite job still active; no false completed backup')
 time.sleep(.5)
if not(root/'completion.json').exists():
 (root/'INCOMPLETE_FINITE_STUDY_BACKUP.json').write_text(json.dumps(dict(job_ended_without_completion=True,last_state=json.loads((N/'ORIGINAL_CHORUS_AIR_PRIMARY_JOINT_CANONICAL_STUDY.json').read_text()),not_adopted=True),indent=2)+'\n')
note='Automatic snapshot after finite actualcanonicalChorus-depth/wet+PRIMARYjob ends. Uses reloadedserialized native states for training, binary-exactwetfractions, unchanged2e-7 FSTgate (rejectanymodelthatfails), all originalscore/stereogates, BOTHfirst6ANDfirst10/cold2 plus additionalreduction inpositiveMidSideoffharmonicexcess3500-6500Hz>=.05dB andbothcoldairgainspositive. Finalverdict incompletion.json, noadoptionorfullreferenceclaim. SourceDiva281/3longincomingnotes/ARP/ADSR/WS52 unchanged. AllretainedactualWAV/nativebundles/primarypresetsandmetadata saved, localaudio retainedforindependentexport. CurrentfullkitZL31 until separatelyverifiednewkit. APIremainingpercentunavailable, so completedworkbackedimmediately.'
subprocess.run([sys.executable,'-B','/workspace/divalead-work/stereo-refinement-20261025/backup_complete_finite_study.py','--root',str(root),'--label','original-Chorus-air-canonical-primary-finite-result','--note',note,'--retain-local-audio'],check=True)
print('FINITE_JOB_AUTOMATIC_REMOTE_BACKUP_COMPLETE',flush=True)
