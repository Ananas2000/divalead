"""Actual static native StereoShaper matrix AFTER the two ZLs, no delay."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,traceback
import numpy as np,soundfile as sf
import native_post_matrix_original_support as q
from native_post_trim import NativePostTrim
R=q.ROOT;STATE=q.STATE;WinVST3=q.WinVST3;assert q.prior.get('requires_post_native_trim');(R/'BASE_MATRIX.bin').write_bytes(Path(q.prior['post_native_trim_state']).read_bytes());old_settings=q.prior['post_native_trim'];base_raw=[0,old_settings['left_raw'],old_settings['right_raw'],0];decode=lambda n:np.sign(n)*(3**(abs(n)/12800)-1)/2;base=np.array([decode(n)for n in base_raw]);assert base.shape==(4,);clients=[];pool=q.queue.Queue();rows=[];mutex=q.threading.Lock();controls=[];frozen=[];power_cache=q.threading.local();original_power=q.a.powers
def capture(*args,**kw):
 result=original_power(*args,**kw);power_cache.power=result[0];return result
q.a.powers=capture
def assess(y):
 d=q.assessment(y);e=10*np.log10(np.maximum(power_cache.power,1e-15)/np.maximum(q.a.TP,1e-15));d['positive_excess_air_3500_6500_dB']=float(np.maximum(e[:,4:6,2:],0).mean());return d
def record(phase,**extra):
 d=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),cases=len(rows),actual_native_matrix_hosts=[c.chain.proc.pid for c in clients],actual_Fruity_Stereo_Shaper_after_actual_two_ZL=True,only_four_static_matrix_gains_varied_no_delay=True,source_native12_Diva281_WS52_MIDI3heldnotes_ARP_ADSR_and_both_ZLs_unchanged=True,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False);d.update(extra);p=STATE.with_suffix('.partial');p.write_text(json.dumps(d,indent=2)+'\n');p.replace(STATE)
def raw_values(v):return[NativePostTrim.raw_from_gain(float(g))for g in v]
def evaluate(case,phase=0,keep=True):
 label,v=case;c=pool.get()
 try:
  raw=raw_values(v);c.configure_matrix(raw);out=c.render(frozen[phase]);row=dict(label=label,matrix_gains=list(map(float,v)),matrix_raw=raw,**assess(out))
  if keep:
   with mutex:rows.append(row)
  return row
 finally:pool.put(c)
def eligible(r,k=0,margin=1.46):return r['upper_error']<=margin and max(abs(np.array(r['LR_dB'])[3:]))<=1.6 and r['lowmid_error']<=min(3.25,controls[k]['lowmid_error']+.02)and r['positive_excess_air_3500_6500_dB']<=controls[k]['positive_excess_air_3500_6500_dB']+.01
def choose(checked,current):
 valid=[r for r in checked if eligible(r)]
 if eligible(current):valid.append(current)
 if valid:return min(valid,key=lambda r:r['loss'])
 def distance(r):return max(0,r['upper_error']-1.46)/.02+max(0,max(abs(np.array(r['LR_dB'])[3:]))-1.6)/.02+max(0,r['lowmid_error']-min(3.25,controls[0]['lowmid_error']+.02))/.05+max(0,r['positive_excess_air_3500_6500_dB']-controls[0]['positive_excess_air_3500_6500_dB']-.01)/.02
 return min([current]+checked,key=lambda r:(distance(r),r['loss']))
def prefix_audio(raw,p,z):
 p.load(R/'PRIMARY.bin');z.load(R/'CONTROL_POST.bin');mid,_=p.render(raw);out,_=z.render(mid);assert p.latency()+z.latency()==0;return out
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(four_static_native_matrix_gains_only=True,actual_original_Fruity_Stereo_Shaper_DLL_for_every_candidate=True,matrix_order=['RightToLeft','LeftToLeft','RightToRight','LeftToRight'],phase_delay_parameters_always_zero=True,no_new_plugin_or_source_or_MIDI_change=True,original_score_weights_alignment_unchanged=True,training_upper_RMS_margin_dB=1.46,heldout_and_validation_upper_RMS_max_dB=1.48,upper_abs_LR_max_dB=1.6,lowmid_error_max_dB=3.25,paired_lowmid_increase_max_dB=.02,training_air_increase_max_dB=.01,validation_first10_and_bothcold_air_increase_max_dB=.02,three_new_native_inputs_two_heldouts=True,first6_AND_first10_gain_over_max_0005_and_3SEM=True,warm10_cold2=True,both_cold_gains_positive=True,requires_latest_control_context_if_main_advances=True),indent=2)+'\n');n=None;working=[];validation_matrix=None
try:
 record('three_new_actual_native_ZL_controls_and_matrix_inputs');n=q.native('PostMatrix-training-native');p=WinVST3('PostMatrix-training-primary');z=WinVST3('PostMatrix-training-post');working=[p,z];matrix=NativePostTrim(R/'host-inputs','PostMatrix-training-control',cleanup_on_close=True);matrix.load(R/'BASE_MATRIX.bin')
 try:
  for k in range(3):
   raw,_=n.render();sf.write(R/f'TRAINING_NATIVE_{k}.wav',raw,48000,subtype='FLOAT');pre=prefix_audio(raw,p,z);frozen.append(pre);sf.write(R/f'TRAINING_BEFORE_MATRIX_{k}.wav',pre,48000,subtype='FLOAT');out=matrix.render(pre);controls.append(assess(out));sf.write(R/f'TRAINING_CONTROL_{k}.wav',out,48000,subtype='FLOAT')
 finally:matrix.close();n.close();n=None;p.close();z.close();working=[]
 (R/'CONTROL_ASSESSMENTS.json').write_text(json.dumps(controls,indent=2)+'\n')
 for k in range(2):c=NativePostTrim(R/'host-inputs','PostMatrix-worker-'+str(k),cleanup_on_close=True);clients.append(c);pool.put(c)
 baseline=evaluate(('unchanged_actual_matrix',base));current=baseline;rng=np.random.default_rng(2026102644);cases=[]
 # Broad crossfeed proposals plus small diagonal adjustments; actual DLL
 # output rather than predicted matrix output decides every score.
 for k in range(96):
  v=base.copy();strength=[.25,.5,1.,1.5][k%4];v+=rng.uniform(-1,1,4)*np.array([.12,.04,.04,.12])*strength;v[[0,3]]=np.clip(v[[0,3]],-.2,.2);v[[1,2]]=np.clip(v[[1,2]],.9,1.1);cases.append((f'joint-matrix-{k}',v))
 with q.concurrent.futures.ThreadPoolExecutor(2)as executor:
  current=choose(list(executor.map(evaluate,cases)),current);record('actual_four_gain_matrix_proposals',baseline=baseline['loss'],best=current['loss'],feasible=eligible(current))
  for sweep in range(4):
   for j in rng.permutation(4):
    cases=[]
    for factor in[-2,-1,1,2]:
     v=np.array(current['matrix_gains']);v[j]+=factor*.012*(.6**sweep);v[[0,3]]=np.clip(v[[0,3]],-.2,.2);v[[1,2]]=np.clip(v[[1,2]],.9,1.1);cases.append((f'fine-matrix-{sweep}-{j}-{factor}',v))
    current=choose(list(executor.map(evaluate,cases)),current);record('actual_post_matrix_fine_fit',sweep=sweep,coordinate=int(j),baseline=baseline['loss'],best=current['loss'],feasible=eligible(current))
 held=[evaluate(('heldout-'+str(k),current['matrix_gains']),k,False)for k in[1,2]];clients[0].configure_matrix(current['matrix_raw']);clients[0].save(R/'CANDIDATE_MATRIX.bin');newpoint=(R/'CANDIDATE_MATRIX.bin').read_bytes()!=(R/'BASE_MATRIX.bin').read_bytes();(R/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0));(R/'HELDOUT.json').write_text(json.dumps(held,indent=2)+'\n');ready=bool(newpoint and eligible(current)and baseline['loss']-current['loss']>.0003 and all(eligible(r,k,1.48)and r['loss']<controls[k]['loss']-.0001 for k,r in zip([1,2],held)));summary=dict(training_cases=len(rows),baseline=baseline['loss'],training_candidate=current['loss'],selected_matrix_gains=current['matrix_gains'],selected_matrix_raw=current['matrix_raw'],heldout=held,sufficient_screen=ready,robust_improvement=False,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False);(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
 if ready:
  record('twelve_new_same_input_matrix_validation');n=q.native('PostMatrix-validation-native');p=WinVST3('PostMatrix-validation-primary');z=WinVST3('PostMatrix-validation-post');working=[p,z];old_matrix=NativePostTrim(R/'host-inputs','PostMatrix-validation-old',cleanup_on_close=True);old_matrix.load(R/'BASE_MATRIX.bin');validation_matrix=NativePostTrim(R/'host-inputs','PostMatrix-validation-new',cleanup_on_close=True);validation_matrix.load(R/'CANDIDATE_MATRIX.bin');captures=[];members=[]
  try:
   with q.tarfile.open(R/'TWELVE_NEW_NATIVE_BEFORE_MATRIX_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
    for rep in range(12):
     if rep in[10,11]:n.close();n=q.native('PostMatrix-cold-native-'+str(rep));validation_matrix.close();validation_matrix=NativePostTrim(R/'host-inputs','PostMatrix-cold-new-'+str(rep),cleanup_on_close=True);validation_matrix.load(R/'CANDIDATE_MATRIX.bin')
     raw,_=n.render();pre=prefix_audio(raw,p,z);old=old_matrix.render(pre);d0=assess(old);out=validation_matrix.render(pre);d1=assess(out);captures.append(dict(rep=rep,control=d0,candidate=d1,improvement=d0['loss']-d1['loss'],air_increase=d1['positive_excess_air_3500_6500_dB']-d0['positive_excess_air_3500_6500_dB']))
     for name,y in[('native',raw),('before-matrix',pre),('control',old),('candidate',out)]:q.add(tar,f'{name}-{rep}.wav',y,members)
     if rep==0:
      for name,y in[('NATIVE_INPUT',raw),('BEFORE_MATRIX',pre),('CONTROL',old),('CANDIDATE',out)]:sf.write(R/(name+'_00.wav'),y,48000,subtype='FLOAT')
     record('first6_AND_first10_cold2_actual_matrix',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  finally:old_matrix.close()
  delta=np.array([r['improvement']for r in captures]);air=np.array([r['air_increase']for r in captures]);s6=float(np.std(delta[:6],ddof=1)/np.sqrt(6));s10=float(np.std(delta[:10],ddof=1)/np.sqrt(10));robust=bool(np.mean(delta[:6])>max(.0005,3*s6)and np.mean(delta[:10])>max(.0005,3*s10)and min(delta[10:])>0 and np.mean(air[:10])<=.02 and max(air[10:])<=.02 and all(r['candidate']['upper_error']<=1.48 and max(abs(np.array(r['candidate']['LR_dB'])[3:]))<=1.6 and r['candidate']['lowmid_error']<=min(3.25,r['control']['lowmid_error']+.02)for r in captures));summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(np.mean(delta[:6])),first6_SEM=s6,first10_mean_improvement=float(np.mean(delta[:10])),first10_SEM=s10,cold2_improvements=delta[10:].tolist(),first10_air_increase=float(np.mean(air[:10])),cold2_air_increase=air[10:].tolist(),robust_improvement=robust)
  with q.tarfile.open(R/'TWELVE_NEW_NATIVE_BEFORE_MATRIX_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_actual_post_matrix_complete_not_adopted',sufficient_screen=ready,robust_improvement=summary['robust_improvement']);print(json.dumps({k:v for k,v in summary.items()if k not in['heldout','captures','archive_members']}),flush=True)
except BaseException:record('failed_preserve_current33_and_main',error=traceback.format_exc());raise
finally:
 if n is not None:n.close()
 if validation_matrix is not None:validation_matrix.close()
 for c in working:c.close()
 for c in clients:c.close()
