from pathlib import Path
u=Path(__file__).resolve().parent;q=(u/'WS_OS_joint109_left003_support.py').read_text().replace('/tmp/divalead-WS-native-OS-joint109-left003-current39-20261031','/tmp/divalead-OS-local17-joint109-left004-current39-20261031').replace('ORIGINAL_NATIVE_WS_OS_JOINT109_LEFT003_CURRENT39_STUDY','ORIGINAL_NATIVE_OS_LOCAL17_JOINT109_LEFT004_CURRENT39_STUDY');(u/'OS_local17_joint109_left004_support.py').write_text(q)
s=(u/'study_WS_OS_both_ZL109_left003_current39.py').read_text().replace('import WS_OS_joint109_left003_support as q','import OS_local17_joint109_left004_support as q').replace("'WS_OS_JOINT109_LEFT003_CURRENT39'","'OS_LOCAL17_JOINT109_LEFT004_CURRENT39'")
s=s.replace("GUI_WS=Path('/tmp/divalead-WS-oversampling-spinner-20261031/wheel_up/after.bin')", "GUI_WS=Path('/tmp/divalead-OS-local17-canonical-new12-20261031/CANDIDATE_CANONICAL_WS.bin')")
s=s.replace('GUI_OVERSAMPLING_STEP1_WS.bin','CANONICAL_OS_LOCAL17_WS.bin').replace('LEFT003','LEFT004').replace('Left003','Local17Left004').replace('-.03','-.04')
s=s.replace("'native final left trim requested -.020 to -.030dB, right0'", "'canonical local17 source shape plus native final left trim requested -.020 to -.040dB, right0'")
s=s.replace("source_Diva281_MIDI3held_ARP_ADSR_other11native_unchanged_GUI_WS_OS_step1_and_leftTrim003_changed=True", "source_Diva281_MIDI3held_ARP_ADSR_other11native_unchanged_canonical_OSlocal17_and_leftTrim004_changed=True")
s=s.replace('WS_native_GUI_oversampling_step1_and_final_leftTrim003_changed=True','canonical_WS_OS_local17_f32_and_final_leftTrim004_changed=True')
s=s.replace('training_Air_mean_min_currentLATEST_anchor39_MINUS0003dB=True','training_Air_mean_min_currentLATEST_anchor39_MINUS0100dB=True')
assert s.count(')-.003;low_cap')==1;s=s.replace(')-.003;low_cap',')-.10;low_cap')
s=s.replace('itertools.product([0.,-.02,-.04,-.08],repeat=3)','itertools.product([0.,-.04,-.08,-.16],repeat=3)').replace('seed_deltas=[0.,-.02,-.04,-.08]','seed_deltas=[0.,-.04,-.08,-.16]')
s=s.replace('source_WS_GUI_oversampling_step1_requires_explicit_generator_schema_migration=True','source_WS_GUI_OS_step1_local17_f32_requires_explicit_generator_schema_migration=True')
pos=s.index('CANDIDATE_TRIM=')
s=s[:pos]+'''parent=Path('/tmp/divalead-OS-local17-canonical-new12-20261031')
for name in ['ACTUAL_CANONICAL_NATIVE_STATE_PROOF.json','CANONICAL_POINT_AND_FLOAT32_RECIPE.json','GUI_OS_PARENT_NATIVE11.bin']:(R/name).write_bytes((parent/name).read_bytes())
assert json.loads((R/'ACTUAL_CANONICAL_NATIVE_STATE_PROOF.json').read_text())['two_new_actual_zeroDepth_cold_replay_errors']==[0.,0.]
'''+s[pos:]
(u/'study_OS_local17_both_ZL109_left004_current39.py').write_text(s)
