"""New relative-primary + existing POST retune with stereo/noise margins."""
from pathlib import Path
import json,hashlib,os,traceback
H=Path(__file__).resolve().parent;support=H/'study_existing_POST11_joint_original.py'
prefix=support.read_text().split('try:\n state(',1)[0]
prefix=prefix.replace("Path('/tmp/divalead-post-joint11-20261026-01')","H/'RELATIVE_AIR_PRIMARY_POST_MARGIN'").replace('ORIGINAL_POST_JOINT11_STUDY.json','ORIGINAL_RELATIVE_PRIMARY_POST_MARGIN_STUDY.json')
exec(compile(prefix,str(support)+'-support-only','exec'),globals())
failed=H/'RELATIVE_AIR_PRIMARY_JOINT_RETRY2';assert not json.loads((failed/'completion.json').read_text())['robust_improvement'];(ROOT/'CONTROL_PRIMARY.bin').write_bytes((ROOT/'PRIMARY.bin').read_bytes());(ROOT/'PRIMARY.bin').write_bytes((failed/'CANDIDATE_PRIMARY.bin').read_bytes())
raw_assessment=assessment;original_powers=a.powers;power_cache=threading.local()
def capture_power(*args,**kwargs):
 result=original_powers(*args,**kwargs);power_cache.power=result[0];return result
a.powers=capture_power
def assessment(y):
 result=raw_assessment(y);error=10*np.log10(np.maximum(power_cache.power,1e-15)/np.maximum(a.TP,1e-15));result['positive_excess_air_3500_6500_dB']=float(np.maximum(error[:,4:6,2:],0).mean());return result
def state(phase,**extra):
 result=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(ROOT),cases=len(rows),actual_POST_hosts=[c.child.pid for c in clients],fixed_new_relative_primary=True,source_native10_WS52_MIDI3heldnotes_ARP_ADSR_unchanged=True,only_existing_POST11_controls_varied=True,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False);result.update(extra);p=STATE.with_suffix('.partial');p.write_text(json.dumps(result,indent=2)+'\n');p.replace(STATE)
def accepted_control(raw,p,z):
 p.load(ROOT/'CONTROL_PRIMARY.bin');z.load(ROOT/'CONTROL_POST.bin');mid,_=p.render(raw);out,_=z.render(mid);assert p.latency()+z.latency()==0;return out
def new_output(raw,p,z):
 p.load(ROOT/'PRIMARY.bin');z.load(ROOT/'CANDIDATE_POST.bin');mid,_=p.render(raw);out,_=z.render(mid);assert p.latency()+z.latency()==0;return out
(ROOT/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(new_DSP_point_requires_changed_POST_from_full32=True,PRIMARY_is_fixed_new_relative_air_joint_point=True,existing_POST11_controls_only=True,all_native12_Diva281_source_MIDI3heldnotes_ARP_ADSR_unchanged=True,original_score_weights_alignment_upper_stereo_guards_unchanged=True,strict_extra_lowmid_error_limit_dB=3.25,paired_lowmid_not_worse_over_dB=.02,training_lowmid_control_mean_plus_dB=.01,training_air_control_mean_plus_dB=.01,heldout_and_mean_first10_and_each_cold_air_increase_max_dB=.02,first6_AND_first10_gain_over_max_0005_and_3SEM=True,validation_warm10_cold2=True,each_pair_same_new_actual_native_input=True,all_ZL_PDC_frames_zero=True),indent=2)+'\n')
n=None;working=[]
try:
 state('three_new_native_inputs_with_accepted32_and_new_relative_primary');n=native('RelativePostMargin-training-native');p=WinVST3('RelativePostMargin-training-primary');z=WinVST3('RelativePostMargin-training-post');working=[p,z];controls=[]
 for k in range(3):
  raw,_=n.render();sf.write(ROOT/f'TRAINING_NATIVE_{k}.wav',raw,48000,subtype='FLOAT');old=accepted_control(raw,p,z);controls.append(assessment(old));sf.write(ROOT/f'TRAINING_CONTROL_{k}.wav',old,48000,subtype='FLOAT');p.load(ROOT/'PRIMARY.bin');mid,_=p.render(raw);mid.astype('<f4').tofile(ROOT/f'primary-{k}.f32')
 n.close();n=None;p.close();z.close();working=[];control_mean=float(np.mean([r['loss']for r in controls]));maximum_lowmid=min(3.25,float(np.mean([r['lowmid_error']for r in controls]))+.01);maximum_air=float(np.mean([r['positive_excess_air_3500_6500_dB']for r in controls]))+.01
 (ROOT/'CONTROL_ASSESSMENTS.json').write_text(json.dumps(controls,indent=2)+'\n')
 for k in range(2):c=WinVST3('RelativePostMargin-worker-'+str(k));clients.append(c);pool.put(c)
 baseline=evaluate(('new-relative-primary_with_old-POST',None));rng=np.random.default_rng(2026102661);proposals=[]
 for k in range(128):
  v=dict(origin);strength=[.4,.8,1.6,3.2][k%4]
  for s in specs:
   d=float(rng.uniform(-1,1))*s['step']*strength;v[s['key']]=float(np.clip(v[s['key']]*2**d if s['log']else v[s['key']]+d,s['lo'],s['hi']))
  proposals.append((f'joint-margin-{k}',v))
 def eligible(r):return r['upper_stereo_guard']and r['lowmid_error']<=maximum_lowmid and r['positive_excess_air_3500_6500_dB']<=maximum_air
 def choose(checked,current):
  valid=[r for r in checked if eligible(r)]
  if eligible(current):valid.append(current)
  return min(valid,key=lambda r:r['loss'])if valid else current
 with concurrent.futures.ThreadPoolExecutor(2)as executor:
  checked=list(executor.map(evaluate,proposals));valid=[r for r in checked if eligible(r)];current=min(valid,key=lambda r:r['loss'])if valid else min(checked,key=lambda r:r['loss']);state('actual_existing_POST_margin_joint_proposals',accepted32_mean=control_mean,best=current['loss'],feasible=eligible(current))
  for sweep in range(3):
   for index in rng.permutation(len(specs)):
    s=specs[int(index)];proposals=[]
    for factor in[-2,-1,1,2]:
     v=dict(current['settings']);d=factor*s['step']*(.55**sweep);v[s['key']]=float(np.clip(v[s['key']]*2**d if s['log']else v[s['key']]+d,s['lo'],s['hi']));proposals.append((f'fine-margin-{sweep}-{index}-{factor}',v))
    current=choose(list(executor.map(evaluate,proposals)),current);state('actual_existing_POST_margin_coordinate_fit',sweep=sweep,coordinate=int(index),best=current['loss'],accepted32_mean=control_mean,feasible=eligible(current))
 held=[evaluate(('new-heldout-'+str(k),current['settings']),k,False)for k in[1,2]];c=clients[0];configure(c,current['settings']);c.save(ROOT/'CANDIDATE_POST.bin');now=values(ROOT/'CANDIDATE_POST.bin');changed={k:[v,now[k]]for k,v in original.items()if now[k]!=v};assert set(changed).issubset(origin);newpoint=bool(changed);frozen=dict(selected_settings=current['settings'],changed_XML_fields=changed,new_POST_changed_from_full32=newpoint,primary_SHA256=hashlib.sha256((ROOT/'PRIMARY.bin').read_bytes()).hexdigest(),post_SHA256=hashlib.sha256((ROOT/'CANDIDATE_POST.bin').read_bytes()).hexdigest(),maximum_training_lowmid=maximum_lowmid,maximum_training_air=maximum_air,not_adopted=True);(ROOT/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(frozen,indent=2)+'\n');(ROOT/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0));(ROOT/'HELDOUT.json').write_text(json.dumps(held,indent=2)+'\n')
 ready=bool(newpoint and eligible(current)and control_mean-float(np.mean([r['loss']for r in held]))>.0003 and all(r['loss']<controls[k]['loss']-.0001 and r['upper_stereo_guard']and r['lowmid_error']<=min(3.25,controls[k]['lowmid_error']+.02)and r['positive_excess_air_3500_6500_dB']<=controls[k]['positive_excess_air_3500_6500_dB']+.02 for k,r in zip([1,2],held)));summary=dict(training_cases=len(rows),accepted32_control_mean=control_mean,training_candidate=current['loss'],heldout=held,new_POST_changed_from_full32=newpoint,sufficient_screen=ready,robust_improvement=False,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False)
 if ready:
  state('twelve_new_native_same_input_paired_validation');n=native('RelativePostMargin-validation-native');p=WinVST3('RelativePostMargin-validation-primary');z=WinVST3('RelativePostMargin-validation-post');working=[p,z];captures=[];members=[]
  with tarfile.open(ROOT/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in[10,11]:n.close();n=native('RelativePostMargin-cold-native-'+str(rep))
    raw,_=n.render();old=accepted_control(raw,p,z);d0=assessment(old);out=new_output(raw,p,z);d1=assessment(out);captures.append(dict(rep=rep,control=d0,candidate=d1,improvement=d0['loss']-d1['loss'],air_increase=d1['positive_excess_air_3500_6500_dB']-d0['positive_excess_air_3500_6500_dB']))
    for name,y in[('native',raw),('control',old),('candidate',out)]:add(tar,f'{name}-{rep}.wav',y,members)
    if rep==0:
     for name,y in[('NATIVE_INPUT',raw),('CONTROL',old),('CANDIDATE',out)]:sf.write(ROOT/(name+'_00.wav'),y,48000,subtype='FLOAT')
    state('fresh6_AND_first10_cold2_with_noise_and_stereo_margins',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  n.close();n=None;p.close();z.close();working=[];delta=np.array([r['improvement']for r in captures]);air=np.array([r['air_increase']for r in captures]);s6=float(np.std(delta[:6],ddof=1)/np.sqrt(6));s10=float(np.std(delta[:10],ddof=1)/np.sqrt(10));robust=bool(np.mean(delta[:6])>max(.0005,3*s6)and np.mean(delta[:10])>max(.0005,3*s10)and min(delta[10:])>0 and np.mean(air[:10])<=.02 and max(air[10:])<=.02 and all(r['candidate']['upper_stereo_guard']and r['candidate']['lowmid_error']<=min(3.25,r['control']['lowmid_error']+.02)for r in captures));summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(np.mean(delta[:6])),first6_SEM=s6,first10_mean_improvement=float(np.mean(delta[:10])),first10_SEM=s10,cold2_improvements=delta[10:].tolist(),first10_air_increase=float(np.mean(air[:10])),cold2_air_increase=air[10:].tolist(),robust_improvement=robust)
  with tarfile.open(ROOT/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
 (ROOT/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');state('finite_relative_primary_POST_margin_complete_not_adopted',sufficient_screen=ready,robust_improvement=summary['robust_improvement']);print(json.dumps({k:v for k,v in summary.items()if k not in['captures','archive_members','heldout']}),flush=True)
except BaseException:state('failed_preserve_full32_and_BEST',error=traceback.format_exc());raise
finally:
 if n is not None:n.close()
 for c in working:c.close()
 for c in clients:c.close()
