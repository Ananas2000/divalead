"""Actual native-DLL sensitivity only; Chorus depth0 is a control, not newlead."""
from pathlib import Path
import json,struct,hashlib
import numpy as np,soundfile as sf
from native_chain import NativeChain
from fl20_curve import apply_candidate,HIGH_CENTERS,HIGH_WIDTHS
H=Path(__file__).resolve().parent;R=H/'HIGH4_SENSITIVITY_RESEARCH_ONLY';R.mkdir();prior=json.loads(Path('/workspace/divalead-work/pc-stereo-20261024/stereo-continuous87/BEST_CANDIDATE.json').read_text());seed=prior['native_base'];bundle=seed['native_saved_state_bundle'];row=next(r for r in bundle['manifest']if r['node']==0);canonical=(Path(bundle['directory'])/row['state']).read_bytes();y0=np.array([struct.unpack_from('<d',canonical,42+24*k)[0]for k in range(129)]);u=np.linspace(0,1,129);basis=(u[:,None]*(1-u[:,None])/(HIGH_CENTERS*(1-HIGH_CENTERS)))**2*np.exp(-.5*((u[:,None]-HIGH_CENTERS)/HIGH_WIDTHS)**2);basis/=basis.max(axis=0)
c=NativeChain(seed['source_manifest']['native_input'],'HIGH4-native-probe',fl_graph=True,phase_pair=True,engine_override='fl_native_fl20_host.exe');rows=[]
try:
 apply_candidate(c,np.array(seed['x']),seed)
 for key,value in seed['chorus_overrides'].items():c.set(3,int(key),int(value))
 c.set(3,1,0);control,_=c.render();sf.write(R/'RESEARCH_ZERO_DEPTH_CONTROL.wav',control,48000,subtype='FLOAT')
 for j in range(4):
  ys=np.clip(y0+basis[:,j]*.001,0,1);assert min(np.diff(ys))>=-1e-10
  b=bytearray(canonical)
  for k,value in enumerate(ys):struct.pack_into('<d',b,42+24*k,float(value))
  p=R/f'HIGH{j}_RESEARCH_ONLY.bin';p.write_bytes(b);c.load_state(0,p);out,_=c.render();sf.write(R/f'HIGH{j}_RESEARCH_ZERO_DEPTH.wav',out,48000,subtype='FLOAT');rows.append(dict(center=float(HIGH_CENTERS[j]),coefficient=.001,actual_native_max_abs_effect=float(abs(out-control).max()),actual_native_RMS_effect=float(np.sqrt(np.mean((out-control)**2)))))
 p=R/'RESTORE_CANONICAL.bin';p.write_bytes(canonical);c.load_state(0,p);again,_=c.render();error=float(abs(again-control).max());assert error<=2e-7
finally:c.close()
result=dict(actual_native_DLL_probed=True,other11_native_and_source_unchanged=True,Chorus_depth0_control_only=True,not_a_working_lead_candidate=True,not_adopted=True,canonical_restoration_max_abs_error=error,results=rows)
(R/'completion.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
