Internal native base for the full native+ZL chain. It is not the recommended standalone sound. Restore the full public ZL kit for FL Studio use.
