"""Optimize previously fixed detectors of the six existing dynamic EQ bands.

No added filter, lookahead, plugin, changed source or MIDI. Actual official
VST3 processing, frozen before new warm/cold paired original-WAV validation.
"""
from pathlib import Path
import concurrent.futures,csv,datetime,gzip,hashlib,io,json,os,queue,struct,tarfile,threading,traceback,xml.etree.ElementTree as ET
import numpy as np,soundfile as sf
from native_chain import NativeChain
from fl20_curve import apply_candidate
from win_vst3 import WinVST3,D
H=Path(__file__).resolve().parent;A=Path('/workspace/divalead-work/pc-stereo-20261024');N=Path('/workspace/divalead-work/native-low-latency-effects');R=H/'PRIMARY_DYNAMIC_DETECTOR24';R.mkdir();STATE=N/'ORIGINAL_PRIMARY_DYNAMIC_DETECTOR24_STUDY.json'
assert json.loads((N/'zl-stereo-continuation.stop').read_text())['owner']=='dynamic-detector-family-20261026'
main=json.loads((N/'FL20_ZL_STEREO_CONTINUOUS_CONTROLLER.json').read_text());assert main['phase'].startswith('stopped_');proc=Path('/proc')/str(main['owner']['PID']);assert not proc.exists()or(proc/'stat').read_text().split()[2]=='Z'
prior=json.loads((A/'stereo-continuous87/BEST_CANDIDATE.json').read_text());seed=prior['native_base'];assert prior['accepted_full_public_kit']=='ZL32'
for name,key in [('CONTROL_PRIMARY.bin','native_ZL_component_state'),('POST.bin','post_ZL_component_state')]:(R/name).write_bytes(Path(prior[key]).read_bytes())
(R/'PRIOR_CONFIRMED.json').write_text(json.dumps(prior,indent=2)+'\n');os.environ['DIVALEAD_NATIVE_OBJECTIVE_ROOT']=str(R/'assessment')
from fl20_objective import FeaturesOriginal,a
f=FeaturesOriginal();reg=float(np.sum(np.array(seed['x'])[:28]**2))*.00000025
ref,sr=sf.read('/workspace/divalead/diva-lead/v83-wip/Diva_original_lead_reference.wav',always_2d=True);np.testing.assert_array_equal(ref,a.REF);frequency=np.fft.rfftfreq(len(ref),1/48000);masks=[(frequency>=lo)&(frequency<hi)for lo,hi in [(300,800),(2000,5000),(5000,10000),(10000,14000)]]
def lr(y):
 p=abs(np.fft.rfft(y,axis=0))**2;return np.array([10*np.log10(p[m,0].sum()/p[m,1].sum())for m in masks])
target=lr(ref)
def assess(y):
 residual=f.residual(y[:288000]);edit=a.h.edit_aligned(a.h.align_with_pdc(y,dict(alignment_frames=819),latency=0));v=lr(edit);return dict(loss=float(residual@residual)+reg,assessment=f.local.last,LR_dB=v.tolist(),stereo_preservation_passed=bool(np.sqrt(np.mean((v[1:]-target[1:])**2))<=1.5 and max(abs(v[1:]))<=1.6 and abs(v[0]-target[0])<=3.35))
def native(tag):
 c=NativeChain(seed['source_manifest']['native_input'],tag,fl_graph=True,phase_pair=True,engine_override='fl_native_fl20_host.exe');apply_candidate(c,np.array(seed['x']),seed)
 for key,value in seed['chorus_overrides'].items():c.set(3,int(key),int(value))
 return c
def values(path):
 b=Path(path).read_bytes();return {p.attrib['id']:float(p.attrib['value'])for p in ET.fromstring(b[8:8+struct.unpack_from('<I',b,4)[0]]).find('Para')}
original=values(R/'CONTROL_PRIMARY.bin');dynamic=[k for k in range(24)if original['filter_status'+str(k)]==2 and original['dynamic_on'+str(k)]==1];assert dynamic==[14,15,16,17,20,21]
params={r['title']:int(r['id'])for r in csv.DictReader((D/'ZL-default-parameters.tsv').open(),delimiter='\t')};specs=[]
for k in dynamic:
 for title,key,step,lo,hi in [('Knee Width','knee_width',2.,0.,24.),('Dynamic RMS Length','dynamic_rms_length',3.,0.,40.),('Dynamic RMS Mix','dynamic_rms_mix',12.,0.,100.),('Dynamic Smooth','dynamic_smooth',10.,0.,100.)]:specs.append(dict(title=title+str(k),key=key+str(k),step=step,lo=lo,hi=hi))
origin={p['key']:original[p['key']]for p in specs};clients=[];pool=queue.Queue();mutex=threading.Lock();rows=[]
def record(phase,**kw):
 s=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),cases=len(rows),actual_ZL_hosts=[c.child.pid for pair in clients for c in pair],only_existing_six_dynamic_band_detector24_varied=True,source_native_POST_unchanged=True,no_added_filters_or_plugins_or_lookahead=True,original_is_the_only_target=True,only_three_held_notes=True,not_adopted=True,reference_match_reached=False,**kw);p=STATE.with_suffix('.partial');p.write_text(json.dumps(s,indent=2)+'\n');p.replace(STATE)
def configure(p,v):
 p.load(R/'CONTROL_PRIMARY.bin')
 if v is not None:
  for s in specs:p.text(params[s['title']],format(v[s['key']],'.12g'))
def evaluate(case,phase=0,keep=True):
 label,v=case;p,z=pool.get()
 try:
  configure(p,v);z.load(R/'POST.bin');mid,_=p.render(input_file=R/f'native-{phase}.f32');out,_=z.render(mid);assert p.latency()+z.latency()==0;row=dict(label=label,settings=v,**assess(out))
  if keep:
   with mutex:rows.append(row)
  return row
 finally:pool.put((p,z))
def add(tar,name,y,members):
 b=io.BytesIO();sf.write(b,y,48000,format='WAV',subtype='FLOAT');data=b.getvalue();i=tarfile.TarInfo(name);i.size=len(data);tar.addfile(i,io.BytesIO(data));members.append(dict(name=name,bytes=len(data),SHA256=hashlib.sha256(data).hexdigest()))
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(variable_parameters=specs,all_remaining_primary_XML_and_native_Diva_POST_MIDI_ARP_ADSR_unchanged=True,original_score_weights_alignment_stereo_gates_unchanged=True,training_three_new_native_inputs_two_heldouts=True,BOTH_first6_AND_first10_gain_over_max_0005_and_3SEM=True,warm10_cold2=True,both_cold_gains_positive=True,all_candidate_render_PDC_frames_zero=True,same_native_input_per_control_candidate_pair=True),indent=2)+'\n');c=None
try:
 record('capture_three_new_real_native10_training_inputs');c=native('DynamicDetector24-training-native')
 for k in range(3):
  raw,_=c.render();raw.astype('<f4').tofile(R/f'native-{k}.f32');sf.write(R/f'TRAINING_NATIVE_{k}.wav',raw,48000,subtype='FLOAT')
 c.close();c=None
 for k in range(2):p=WinVST3('DynamicDetector24-primary-'+str(k));z=WinVST3('DynamicDetector24-post-'+str(k));clients.append((p,z));pool.put((p,z))
 baseline=evaluate(('baseline-current-confirmed',None));current=baseline;rng=np.random.default_rng(2026102626);cases=[]
 for k in range(96):
  v=dict(origin)
  # Try both individual detectors and coupled detector changes.
  selected=range(len(specs))if k%3==0 else rng.choice(len(specs),size=1+k%6,replace=False)
  for j in selected:
   s=specs[int(j)];v[s['key']]=float(np.clip(v[s['key']]+rng.uniform(-1,1)*s['step']*[.5,1,2,4][k%4],s['lo'],s['hi']))
  cases.append((f'detector24-{k}',v))
 def choose(checked,current):return min([current]+[r for r in checked if r['stereo_preservation_passed']],key=lambda r:r['loss'])
 with concurrent.futures.ThreadPoolExecutor(2)as executor:
  current=choose(list(executor.map(evaluate,cases)),current);record('actual_existing_detector24_joint_proposals',baseline=baseline['loss'],best=current['loss'])
  for sweep in range(2):
   for j in rng.permutation(len(specs)):
    s=specs[int(j)];cases=[]
    for factor in [-2,-1,1,2]:
     v=dict(current['settings']or origin);v[s['key']]=float(np.clip(v[s['key']]+factor*s['step']*(.6**sweep),s['lo'],s['hi']));cases.append((f'fine-{sweep}-{j}-{factor}',v))
    current=choose(list(executor.map(evaluate,cases)),current);record('actual_existing_detector24_coordinate_refit',baseline=baseline['loss'],best=current['loss'],sweep=sweep,coordinate=int(j))
 held=[dict(control=evaluate(('heldout-control',None),k,False),candidate=evaluate(('heldout-candidate',current['settings']),k,False))for k in [1,2]];p,z=clients[0];configure(p,current['settings']);p.save(R/'CANDIDATE_PRIMARY.bin');p.dump(R/'CANDIDATE_610_PARAMETERS.tsv');now=values(R/'CANDIDATE_PRIMARY.bin');changed={k:[v,now[k]]for k,v in original.items()if now[k]!=v};assert set(changed).issubset(origin),changed
 frozen=dict(selected_settings=current['settings'],changed_XML_fields=changed,primary_SHA256=hashlib.sha256((R/'CANDIDATE_PRIMARY.bin').read_bytes()).hexdigest(),not_adopted=True);(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(frozen,indent=2)+'\n');(R/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0));(R/'HELDOUT.json').write_text(json.dumps(held,indent=2)+'\n');ready=bool(changed and baseline['loss']-current['loss']>.0003 and all(r['control']['loss']>r['candidate']['loss']+.0001 and r['candidate']['stereo_preservation_passed']for r in held));summary=dict(training_cases=len(rows),baseline=baseline['loss'],training_selected=current['loss'],sufficient_screen=ready,robust_improvement=False,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False)
 if ready:
  record('twelve_new_native_paired_validation');c=native('DynamicDetector24-validation-native');captures=[];members=[];p,z=clients[0]
  with tarfile.open(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in [10,11]:c.close();c=native('DynamicDetector24-cold-native-'+str(rep))
    raw,_=c.render();p.load(R/'CONTROL_PRIMARY.bin');z.load(R/'POST.bin');mid,_=p.render(raw);old,_=z.render(mid);d0=assess(old);p.load(R/'CANDIDATE_PRIMARY.bin');z.load(R/'POST.bin');mid,_=p.render(raw);out,_=z.render(mid);d1=assess(out);assert p.latency()+z.latency()==0;captures.append(dict(rep=rep,control=d0,candidate=d1,improvement=d0['loss']-d1['loss']))
    for name,y in [('native',raw),('control',old),('candidate',out)]:add(tar,f'{name}-{rep}.wav',y,members)
    if rep==0:
     for name,y in [('NATIVE_INPUT',raw),('CONTROL',old),('CANDIDATE',out)]:sf.write(R/(name+'_00.wav'),y,48000,subtype='FLOAT')
    record('first6_AND_first10_plus_cold2_running',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  c.close();c=None;delta=np.array([r['improvement']for r in captures]);sem6=float(np.std(delta[:6],ddof=1)/np.sqrt(6));sem10=float(np.std(delta[:10],ddof=1)/np.sqrt(10));robust=bool(np.mean(delta[:6])>max(.0005,3*sem6)and np.mean(delta[:10])>max(.0005,3*sem10)and min(delta[10:])>0 and all(r['candidate']['stereo_preservation_passed']for r in captures));summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(np.mean(delta[:6])),first6_SEM=sem6,first10_mean_improvement=float(np.mean(delta[:10])),first10_SEM=sem10,cold2_improvements=delta[10:].tolist(),robust_improvement=robust)
  with tarfile.open(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_existing_detector24_study_complete_not_adopted',robust_improvement=summary['robust_improvement'],sufficient_screen=ready);print(json.dumps({k:v for k,v in summary.items()if k not in ['captures','archive_members']}),flush=True)
except BaseException:record('failed_preserve_full32_and_current_best',error=traceback.format_exc());raise
finally:
 if c is not None:c.close()
 for p,z in clients:p.close();z.close()
