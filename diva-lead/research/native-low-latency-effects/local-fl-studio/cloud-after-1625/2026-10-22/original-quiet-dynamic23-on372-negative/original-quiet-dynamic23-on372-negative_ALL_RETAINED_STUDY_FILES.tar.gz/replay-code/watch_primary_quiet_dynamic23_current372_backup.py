from pathlib import Path
import json,os,subprocess,sys,time
H=Path(__file__).resolve().parent;N=H.parent/'native-low-latency-effects';state=N/'ORIGINAL_PRIMARY_QUIET_DYNAMIC23_CURRENT372_STUDY.json';s=json.loads(state.read_text());pid=s['PID'];proc=Path('/proc')/str(pid);root=Path(s['root']);assert root==H/'PRIMARY_QUIET_DYNAMIC23_CURRENT372'
try:start=(proc/'stat').read_text().split()[21]
except FileNotFoundError:start=None
deadline=time.monotonic()+7200
while start is not None:
 try:
  v=(proc/'stat').read_text().split()
  if v[21]!=start or v[2]=='Z':break
 except FileNotFoundError:break
 if time.monotonic()>deadline:raise TimeoutError('Still actual DSP; no false completed archive')
 time.sleep(.5)
done=root/'completion.json';positive=False
if done.exists():positive=json.loads(done.read_text()).get('robust_improvement',False)
else:(root/'INCOMPLETE_FINITE_STUDY_BACKUP.json').write_text(json.dumps(dict(job_ended_without_completion=True,last_controller=json.loads(state.read_text()),not_adopted=True),indent=2)+'\n')
args=[sys.executable,'-B',str(H.parent/'stereo-refinement-20261025/backup_complete_finite_study.py'),'--root',str(root),'--label','original-quiet-dynamic23-on372-negative','--note','48новыхMid/Sidequietdynamic23срезов3.5/4.8/6.2kHz,Q.7/1.4,gain-1/-2,target0,RelativeON,threshold-18/-12. Источник281/3длинныеARP/ADSR/native12/POST37/trim/PRIMARY0..22прежние. Требовалсяисходныйgainи уменьшениеAir,нониоднаscreenнепройдена,непринято. Все48точныхcomponentstate/XML/метрик иоставшиесяреальныеWAV/кодсохранены. КандидатыбыливнастоящемZL,неэмуляцияDSP. Основная372неизменна.']
if positive:args.append('--retain-local-audio')
subprocess.run(args,check=True)
