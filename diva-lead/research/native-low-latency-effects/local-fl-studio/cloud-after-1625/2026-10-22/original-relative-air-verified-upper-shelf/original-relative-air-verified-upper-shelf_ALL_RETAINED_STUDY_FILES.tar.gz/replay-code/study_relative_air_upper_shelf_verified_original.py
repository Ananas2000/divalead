"""Repair measured upper-band L/R bias with one ordinary ZL shelf.

Reference upper L/R is slightly right-heavy. The new relative-primary point
fits the timbre/noise but one validation had high-band LR RMS error1.503>1.5.
Test a Left cut or Right boost in a new POST HighShelf, with tighter margin.
"""
from pathlib import Path
import datetime,gzip,hashlib,json,os,traceback
import numpy as np,soundfile as sf
import relative_air_upper_shelf_support_verified as q
R=q.ROOT;H=Path(__file__).resolve().parent;STATE=q.STATE;WinVST3=q.WinVST3;params=q.params
failed=H/'RELATIVE_AIR_PRIMARY_JOINT_RETRY2';assert not json.loads((failed/'completion.json').read_text())['robust_improvement'];(R/'CONTROL_PRIMARY.bin').write_bytes((R/'PRIMARY.bin').read_bytes());(R/'PRIMARY.bin').write_bytes((failed/'CANDIDATE_PRIMARY.bin').read_bytes());controls=[];rows=[];clients=[];pool=q.queue.Queue();mutex=q.threading.Lock();cache=q.threading.local();old_powers=q.a.powers
def capture(*args,**kwargs):
 result=old_powers(*args,**kwargs);cache.power=result[0];return result
q.a.powers=capture
def assess(y):
 d=q.assessment(y);e=10*np.log10(np.maximum(cache.power,1e-15)/np.maximum(q.a.TP,1e-15));d['positive_excess_air_3500_6500_dB']=float(np.maximum(e[:,4:6,2:],0).mean());return d
def record(phase,**extra):
 d=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),cases=len(rows),actual_POST_hosts=[c.child.pid for c in clients],only_one_new_ordinary_left_or_right_HighShelf_in_existing_POST=True,previous_five_POST_filters_unchanged=True,new_relative_primary_fixed=True,source_native10_WS52_MIDI3heldnotes_ARP_ADSR_unchanged=True,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False);d.update(extra);p=STATE.with_suffix('.partial');p.write_text(json.dumps(d,indent=2)+'\n');p.replace(STATE)
def configure(c,v):
 c.load(R/'CONTROL_POST.bin')
 c.text(params['Filter Status5'],'On');c.text(params['Filter Type5'],'High Shelf');c.text(params['LRMode5'],v['mode']);c.text(params['Order5'],'12 dB/oct');c.text(params['Gain5'],format(v['gain'],'.9g'));c.text(params['Freq5'],format(v['freq'],'.9g'));c.text(params['Q5'],format(v['Q'],'.9g'))
def evaluate(case,phase=0,keep=True):
 label,v=case;c=pool.get()
 try:
  configure(c,v);out,_=c.render(input_file=R/f'primary-{phase}.f32');assert c.latency()==0;row=dict(label=label,settings=v,**assess(out))
  if keep:
   with mutex:rows.append(row)
  return row
 finally:pool.put(c)
def eligible(d,k=0):return d['upper_error']<=1.48 and max(abs(np.array(d['LR_dB'])[3:]))<=1.6 and d['lowmid_error']<=min(3.25,controls[k]['lowmid_error']+.02)and d['positive_excess_air_3500_6500_dB']<=controls[k]['positive_excess_air_3500_6500_dB']+.02
def choose(checked,current):
 valid=[r for r in checked if eligible(r)]
 if current is not None and eligible(current):valid.append(current)
 if valid:return min(valid,key=lambda r:r['loss'])
 candidates=checked+([current]if current is not None else[])
 def violation(d):return max(0,d['upper_error']-1.48)/.02+max(0,max(abs(np.array(d['LR_dB'])[3:]))-1.6)/.02+max(0,d['lowmid_error']-min(3.25,controls[0]['lowmid_error']+.02))/.05+max(0,d['positive_excess_air_3500_6500_dB']-controls[0]['positive_excess_air_3500_6500_dB']-.02)/.02
 return min(candidates,key=lambda r:(violation(r),r['loss']))
def control_audio(raw,p,z):
 p.load(R/'CONTROL_PRIMARY.bin');z.load(R/'CONTROL_POST.bin');mid,_=p.render(raw);out,_=z.render(mid);assert p.latency()+z.latency()==0;return out
def candidate_audio(raw,p,z):
 p.load(R/'PRIMARY.bin');z.load(R/'CANDIDATE_POST.bin');mid,_=p.render(raw);out,_=z.render(mid);assert p.latency()+z.latency()==0;return out
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(new_actual_HighShelf_filter_in_unused_POST_slot5_only=True,modes=['Left negative gain','Right positive gain'],old_five_POST_filters_fixed=True,new_relative_primary_fixed=True,original_score_weights_alignment_unchanged=True,stricter_upper_LR_RMS_error_dB=1.48,original_upper_max_abs_LR_limit_dB=1.6,lowmid_error_limit_dB=3.25,paired_lowmid_error_increase_limit_dB=.02,paired_air_excess_increase_limit_dB=.02,three_new_training_native_inputs_two_heldouts=True,first6_AND_first10_gain_over_max_0005_and_3SEM=True,warm10_cold2=True,both_cold_gain_positive=True,each_validation_pair_same_native_input=True,all_ZL_PDC_frames_zero=True),indent=2)+'\n')
n=None;working=[]
try:
 record('three_new_native_inputs_with_accepted32_and_relative_primary');n=q.native('RelativeShelf-training-native');p=WinVST3('RelativeShelf-training-primary');z=WinVST3('RelativeShelf-training-post');working=[p,z]
 for k in range(3):
  raw,_=n.render();sf.write(R/f'TRAINING_NATIVE_{k}.wav',raw,48000,subtype='FLOAT');old=control_audio(raw,p,z);controls.append(assess(old));sf.write(R/f'TRAINING_CONTROL_{k}.wav',old,48000,subtype='FLOAT');p.load(R/'PRIMARY.bin');mid,_=p.render(raw);mid.astype('<f4').tofile(R/f'primary-{k}.f32')
 n.close();n=None;p.close();z.close();working=[];(R/'CONTROL_ASSESSMENTS.json').write_text(json.dumps(controls,indent=2)+'\n')
 for k in range(2):c=WinVST3('RelativeShelf-worker-'+str(k));clients.append(c);pool.put(c)
 # First verify the host's actual parsed enum/mode/state rather than assume it.
 test=dict(mode='Left',gain=-.1,freq=2200.,Q=.707);configure(clients[0],test);clients[0].save(R/'ENUM_AND_MODE_PROBE.bin');clients[0].dump(R/'ACTUAL_SHELF_ENUM_610_PARAMETERS.tsv');probe=q.values(R/'ENUM_AND_MODE_PROBE.bin');enum_rows=list(q.csv.DictReader((R/'ACTUAL_SHELF_ENUM_610_PARAMETERS.tsv').open(),delimiter='\t'));type_row=next(row for row in enum_rows if row['title']=='Filter Type5');assert 'high' in str(type_row).lower()and 'shelf'in str(type_row).lower(),type_row;assert probe['filter_status5']==2 and probe['filter_type5']==3 and probe['lr_mode5']==1, {k:v for k,v in probe.items()if k.endswith('5')};assert probe['gain5']<0
 proposals=[(f'{mode}-{freq}-{gain}-{Q}',dict(mode=mode,freq=freq,gain=sign*gain,Q=Q))for mode,sign in [('Left',-1),('Right',1)]for freq in[1000.,1600.,2200.,3200.,5000.,8000.]for gain in[.05,.1,.2,.35,.5,.75,1.,1.5]for Q in[.5,.707,1.]];current=None
 with q.concurrent.futures.ThreadPoolExecutor(2)as executor:
  for k,row in enumerate(executor.map(evaluate,proposals)):
   current=choose([row],current)
   if k%24==0:record('actual_left_cut_right_boost_shelf_screen',best=current['loss'],feasible=eligible(current))
  for sweep in range(2):
   for key,step,log in [('gain',.05,False),('freq',.1,True),('Q',.2,True)]:
    cases=[]
    for factor in[-2,-1,1,2]:
     v=dict(current['settings']);d=factor*step*(.6**sweep);v[key]=v[key]*2**d if log else v[key]+d
     if 0.01<=abs(v['gain'])<=2.5 and 500<=v['freq']<=12000 and .15<=v['Q']<=3 and((v['mode']=='Left'and v['gain']<0)or(v['mode']=='Right'and v['gain']>0)):cases.append((f'fine-{sweep}-{key}-{factor}',v))
    current=choose(list(executor.map(evaluate,cases)),current);record('actual_shelf_fine_fit',sweep=sweep,parameter=key,best=current['loss'],feasible=eligible(current))
 held=[evaluate(('new-heldout-'+str(k),current['settings']),k,False)for k in[1,2]];c=clients[0];configure(c,current['settings']);c.save(R/'CANDIDATE_POST.bin');now=q.values(R/'CANDIDATE_POST.bin');changed={k:[v,now[k]]for k,v in q.original.items()if now[k]!=v};assert set(changed).issubset({'filter_status5','filter_type5','lr_mode5','order5','gain5','freq5','q5'}),changed;assert now['filter_status5']==2 and now['filter_type5']==3 and abs(now['gain5'])>.01
 (R/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0));(R/'HELDOUT.json').write_text(json.dumps(held,indent=2)+'\n');(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(dict(selected_settings=current['settings'],changed_XML_fields=changed,primary_SHA256=hashlib.sha256((R/'PRIMARY.bin').read_bytes()).hexdigest(),post_SHA256=hashlib.sha256((R/'CANDIDATE_POST.bin').read_bytes()).hexdigest(),not_adopted=True),indent=2)+'\n');control_mean=float(np.mean([d['loss']for d in controls]));ready=bool(eligible(current)and control_mean-float(np.mean([r['loss']for r in held]))>.0003 and all(eligible(r,k)and r['loss']<controls[k]['loss']-.0001 for k,r in zip([1,2],held)));summary=dict(training_cases=len(rows),accepted32_control_mean=control_mean,training_candidate=current['loss'],heldout=held,selected_settings=current['settings'],sufficient_screen=ready,robust_improvement=False,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False)
 if ready:
  record('twelve_new_native_paired_validation');n=q.native('RelativeShelf-validation-native');p=WinVST3('RelativeShelf-validation-primary');z=WinVST3('RelativeShelf-validation-post');working=[p,z];captures=[];members=[]
  with q.tarfile.open(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in[10,11]:n.close();n=q.native('RelativeShelf-cold-native-'+str(rep))
    raw,_=n.render();old=control_audio(raw,p,z);d0=assess(old);out=candidate_audio(raw,p,z);d1=assess(out);captures.append(dict(rep=rep,control=d0,candidate=d1,improvement=d0['loss']-d1['loss'],air_increase=d1['positive_excess_air_3500_6500_dB']-d0['positive_excess_air_3500_6500_dB']))
    for name,y in[('native',raw),('control',old),('candidate',out)]:q.add(tar,f'{name}-{rep}.wav',y,members)
    if rep==0:
     for name,y in[('NATIVE_INPUT',raw),('CONTROL',old),('CANDIDATE',out)]:sf.write(R/(name+'_00.wav'),y,48000,subtype='FLOAT')
    record('first6_AND_first10_cold2_with_shelf_margin',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  n.close();n=None;p.close();z.close();working=[];delta=np.array([r['improvement']for r in captures]);air=np.array([r['air_increase']for r in captures]);s6=float(np.std(delta[:6],ddof=1)/np.sqrt(6));s10=float(np.std(delta[:10],ddof=1)/np.sqrt(10));robust=bool(np.mean(delta[:6])>max(.0005,3*s6)and np.mean(delta[:10])>max(.0005,3*s10)and min(delta[10:])>0 and np.mean(air[:10])<=.02 and max(air[10:])<=.02 and all(r['candidate']['upper_error']<=1.48 and max(abs(np.array(r['candidate']['LR_dB'])[3:]))<=1.6 and r['candidate']['lowmid_error']<=min(3.25,r['control']['lowmid_error']+.02)for r in captures));summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(np.mean(delta[:6])),first6_SEM=s6,first10_mean_improvement=float(np.mean(delta[:10])),first10_SEM=s10,cold2_improvements=delta[10:].tolist(),first10_air_increase=float(np.mean(air[:10])),cold2_air_increase=air[10:].tolist(),robust_improvement=robust)
  with q.tarfile.open(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_relative_air_shelf_study_complete_not_adopted',sufficient_screen=ready,robust_improvement=summary['robust_improvement']);print(json.dumps({k:v for k,v in summary.items()if k not in['captures','archive_members','heldout']}),flush=True)
except BaseException:record('failed_preserve_full32_and_BEST',error=traceback.format_exc());raise
finally:
 if n is not None:n.close()
 for c in working:c.close()
 for c in clients:c.close()
