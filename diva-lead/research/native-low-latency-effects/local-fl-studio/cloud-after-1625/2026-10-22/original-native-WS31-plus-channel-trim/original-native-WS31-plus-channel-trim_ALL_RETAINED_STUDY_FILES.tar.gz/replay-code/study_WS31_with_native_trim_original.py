"""New joint point: promising WS curve plus actual post-ZL channel trim."""
from pathlib import Path
import concurrent.futures,datetime,gzip,hashlib,json,os,struct,threading,traceback
import numpy as np,soundfile as sf
import WS31_native_trim_support as q
from native_post_trim import NativePostTrim
R=q.ROOT;N=q.N;STATE=q.STATE;OLD=R.parent/'WS_INTERLEAVED31_ORIGINAL';old=json.loads((OLD/'completion.json').read_text());assert not old['robust_improvement'];assert old['winner']['curve_vector']!=[0.]*31
bundle=q.seed['native_saved_state_bundle'];ws=next(r for r in bundle['manifest']if r['node']==0);canonical=(Path(bundle['directory'])/ws['state']).read_bytes();Y0=np.array([struct.unpack_from('<d',canonical,34+24*k+8)[0]for k in range(129)]);u=np.linspace(0,1,129);centers=np.linspace(.03,.63,31);basis=(u[:,None]*(1-u[:,None])/(centers*(1-centers)))**2*np.exp(-.5*((u[:,None]-centers)/.0065)**2);basis/=basis.max(axis=0);Y=Y0+basis@np.array(old['winner']['curve_vector']);assert min(Y)>=-1e-12 and max(Y)<=1+1e-12 and min(np.diff(Y))>=-1e-10;b=bytearray(canonical)
for k,v in enumerate(np.clip(Y,0,1)):struct.pack_into('<d',b,34+24*k+8,float(v))
(R/'CANDIDATE_WS.bin').write_bytes(b);assert bytes(b)!=canonical;(R/'CONTROL_TRIM.bin').write_bytes(Path(q.prior['post_native_trim_state']).read_bytes());rows=[];pool=q.queue.Queue();trimhosts=[];controls=[];pre_candidates=[];natives=[];vsts=[];cache=threading.local();origpowers=q.a.powers
def powers(*args,**kw):
 result=origpowers(*args,**kw);cache.power=result[0];return result
q.a.powers=powers
def assess(y):
 d=q.assessment(y);error=10*np.log10(np.maximum(cache.power,1e-15)/np.maximum(q.a.TP,1e-15));d['positive_excess_air_dB']=float(np.maximum(error[:,4:6,2:],0).mean());return d
def record(phase,**kw):
 d=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),cases=len(rows),actual_native_hosts=[c.proc.pid for c in natives],actual_ZL_hosts=[c.child.pid for c in vsts],actual_native_trim_hosts=[c.chain.proc.pid for c in trimhosts],new_joint_WS31_curve_and_post_trim_point=True,original_is_the_only_target=True,Diva281_three_held_notes_ARP_ADSR_other11native_PRIMARY_POST_unchanged=True,not_adopted=True,reference_match_reached=False);d.update(kw);tmp=STATE.with_suffix('.partial');tmp.write_text(json.dumps(d,indent=2)+'\n');tmp.replace(STATE)
def native(tag,candidate=False):
 c=q.native(tag)
 if candidate:c.load_state(0,R/'CANDIDATE_WS.bin')
 return c
def prefix(raw,p,z):
 p.load(R/'PRIMARY.bin');z.load(R/'CONTROL_POST.bin');mid,_=p.render(raw);out,_=z.render(mid);assert p.latency()+z.latency()==0;return out
def wave(name,y):sf.write(R/(name+'.wav'),y,48000,subtype='FLOAT')
def allowed(row,k=0,margin=1.46):return row['upper_error']<=margin and max(abs(np.array(row['LR_dB'])[3:]))<=1.6 and row['lowmid_error']<=min(3.25,controls[k]['lowmid_error']+.02)and row['positive_excess_air_dB']<=controls[k]['positive_excess_air_dB']+.02
def evaluate(case,k=0,keep=True):
 label,settings=case;c=pool.get()
 try:
  c.configure(settings['left_raw'],settings['right_raw']);row=dict(label=label,settings=settings,**assess(c.render(pre_candidates[k])))
  if keep:rows.append(row)
  return row
 finally:pool.put(c)
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(new_candidate_is_curve_AND_native_channel_trim_not_retesting_rejected_curve_alone=True,old_negative_curve_study_preserved=True,old_curve_winner=old['winner'],three_new_native_inputs_each_control_and_candidate=True,three_incoming_held_notes_source_Diva281_ARP_ADSR_all_other11native_and_two_ZL_components_fixed=True,actual_original_Fruity_Stereo_Shaper_after_ZLs=True,post_trim_no_crossfeed_no_delay=True,training_upper_margin_dB=1.46,all_validation_upper_RMS_max_dB=1.48,abs_upper_LR_max_dB=1.6,lowmid_error_max_dB=3.25,each_pair_lowmid_increase_limit_dB=.02,training_and_first10_and_cold_air_increase_limit_dB=.02,first6_AND_first10_gain_over_max_0005_3SEM=True,both_cold_gains_positive=True,original_fullscore_weights_alignment_unchanged=True,supported_metadata_latest_context_fullkit_cold_replay_required=True),indent=2)+'\n')
try:
 record('new_WS_and_native_trim_capture_three_actual_prefix_pairs');n0=native('WS31Trim-training-control');n1=native('WS31Trim-training-candidate',True);natives=[n0,n1];p=q.WinVST3('WS31Trim-training-primary');z=q.WinVST3('WS31Trim-training-post');vsts=[p,z];c=NativePostTrim(R/'buffers','WS31Trim-training-control-trim',cleanup_on_close=True);c.load(R/'CONTROL_TRIM.bin');trimhosts=[c]
 for k in range(3):
  raw0,_=n0.render();pre0=prefix(raw0,p,z);out=c.render(pre0);controls.append(assess(out));raw1,_=n1.render();pre1=prefix(raw1,p,z);pre_candidates.append(pre1)
  for name,y in [('TRAINING_CONTROL_NATIVE',raw0),('TRAINING_CONTROL',out),('TRAINING_CANDIDATE_NATIVE',raw1),('TRAINING_CANDIDATE_PRETRIM',pre1)]:wave(name+'_'+str(k),y)
 for c in natives:c.close()
 for c in vsts:c.close()
 for c in trimhosts:c.close()
 natives=[];vsts=[];trimhosts=[];(R/'CONTROL_ASSESSMENTS.json').write_text(json.dumps(controls,indent=2)+'\n')
 for k in range(2):c=NativePostTrim(R/'buffers','WS31Trim-fit-'+str(k),cleanup_on_close=True);trimhosts.append(c);pool.put(c)
 settings=q.prior['post_native_trim'];baseL=settings['requested_left_dB'];baseR=settings['requested_right_dB'];cases=[]
 for dl in[-.15,-.10,-.075,-.05,-.025,0.,.025,.05,.075]:
  for dr in[-.025,0.,.025]:
   l=baseL+dl;r=baseR+dr;cases.append((f'dL{dl}_dR{dr}',dict(requested_left_dB=l,requested_right_dB=r,left_raw=NativePostTrim.raw_from_dB(l),right_raw=NativePostTrim.raw_from_dB(r))))
 with concurrent.futures.ThreadPoolExecutor(2)as ex:checked=list(ex.map(evaluate,cases))
 valid=[r for r in checked if allowed(r)];winner=min(valid,key=lambda r:r['loss'])if valid else None;held=[]
 if winner:
  held=[evaluate(('heldout-'+str(k),winner['settings']),k,False)for k in[1,2]];trimhosts[0].configure(winner['settings']['left_raw'],winner['settings']['right_raw']);trimhosts[0].save(R/'CANDIDATE_TRIM.bin')
 ready=bool(winner and(R/'CANDIDATE_TRIM.bin').read_bytes()!=(R/'CONTROL_TRIM.bin').read_bytes()and controls[0]['loss']-winner['loss']>.0003 and all(allowed(r,k,1.48)and r['loss']<controls[k]['loss']-.0001 for k,r in zip([1,2],held)));summary=dict(training_cases=len(rows),winner=winner,heldout=held,sufficient_screen=ready,robust_improvement=False,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False);(R/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0));(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
 if ready:
  record('twelve_new_WS_and_trim_full_chain_validation');n0=native('WS31Trim-validation-control');n1=native('WS31Trim-validation-candidate',True);natives=[n0,n1];p=q.WinVST3('WS31Trim-validation-primary');z=q.WinVST3('WS31Trim-validation-post');vsts=[p,z];oldtrim=NativePostTrim(R/'buffers','WS31Trim-validation-old',cleanup_on_close=True);oldtrim.load(R/'CONTROL_TRIM.bin');newtrim=NativePostTrim(R/'buffers','WS31Trim-validation-new',cleanup_on_close=True);newtrim.load(R/'CANDIDATE_TRIM.bin');trimhosts.extend([oldtrim,newtrim]);captures=[];members=[]
  with q.tarfile.open(R/'TWELVE_NEW_NATIVE_PROCESSED_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in[10,11]:
     n0.close();n1.close();n0=native('WS31Trim-cold-control-'+str(rep));n1=native('WS31Trim-cold-candidate-'+str(rep),True);natives=[n0,n1];newtrim.close();newtrim=NativePostTrim(R/'buffers','WS31Trim-cold-trim-'+str(rep),cleanup_on_close=True);newtrim.load(R/'CANDIDATE_TRIM.bin');trimhosts.append(newtrim)
    raw0,_=n0.render();out0=oldtrim.render(prefix(raw0,p,z));d0=assess(out0);raw1,_=n1.render();pre1=prefix(raw1,p,z);out1=newtrim.render(pre1);d1=assess(out1);captures.append(dict(rep=rep,control=d0,candidate=d1,improvement=d0['loss']-d1['loss'],air_increase=d1['positive_excess_air_dB']-d0['positive_excess_air_dB']))
    for name,y in [('native-control',raw0),('native-candidate',raw1),('control',out0),('candidate',out1)]:q.add(tar,f'{name}-{rep}.wav',y,members)
    if rep==0:
     for name,y in [('NATIVE_CONTROL',raw0),('NATIVE_CANDIDATE',raw1),('CONTROL',out0),('BEFORE_TRIM',pre1),('CANDIDATE',out1)]:wave(name+'_00',y)
    record('WS31_trim_first6_AND_first10_cold2',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  delta=np.array([r['improvement']for r in captures]);air=np.array([r['air_increase']for r in captures]);s6=float(np.std(delta[:6],ddof=1)/np.sqrt(6));s10=float(np.std(delta[:10],ddof=1)/np.sqrt(10));robust=bool(np.mean(delta[:6])>max(.0005,3*s6)and np.mean(delta[:10])>max(.0005,3*s10)and min(delta[10:])>0 and np.mean(air[:10])<=.02 and max(air[10:])<=.02 and all(r['candidate']['upper_error']<=1.48 and max(abs(np.array(r['candidate']['LR_dB'])[3:]))<=1.6 and r['candidate']['lowmid_error']<=min(3.25,r['control']['lowmid_error']+.02)for r in captures));summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(np.mean(delta[:6])),first6_SEM=s6,first10_mean_improvement=float(np.mean(delta[:10])),first10_SEM=s10,cold2_improvements=delta[10:].tolist(),first10_air_increase=float(np.mean(air[:10])),cold2_air_increase=air[10:].tolist(),robust_improvement=robust)
  with q.tarfile.open(R/'TWELVE_NEW_NATIVE_PROCESSED_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_new_WS31_plus_native_trim_complete_not_adopted',sufficient_screen=ready,robust_improvement=summary['robust_improvement']);print(json.dumps({k:v for k,v in summary.items()if k not in ['winner','heldout','captures','archive_members']}),flush=True)
except BaseException:record('failed_preserve_confirmed_native10_full33_and_main',error=traceback.format_exc());raise
finally:
 for c in natives:c.close()
 for c in vsts:c.close()
 for c in trimhosts:c.close()
