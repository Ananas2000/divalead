"""Use the original frozen12 actual inputs/candidate WAVs against latest accepted639.

No candidate resampling, new selection or pooling; a failed original gate cannot
be rescued. Only the new comparator is actually rendered on the same12 inputs.
"""
from pathlib import Path
import datetime,hashlib,io,json,os,shutil,tarfile,threading
import numpy as np,soundfile as sf
from win_vst3 import WinVST3
from native_post_trim import NativePostTrim
J=Path(__file__).resolve().parent;A=J.parent/'pc-stereo-20261024';Q=Path('/tmp/divalead-native12-joint109-sixdraw-full41-20261107');R=Path('/tmp/divalead-sixdraw41-vs-latest639-same12-20261107');R.mkdir();read=lambda p:json.loads(Path(p).read_text())
original=read(Q/'completion.json');assert original['robust_improvement']and len(original['captures'])==12
latest=read(A/'stereo-continuous87/BEST_CANDIDATE.json');assert latest['source_accepted_cohort']==639 and read(A/'stereo-continuous87/cohort-0639/REMOTE_BACKUP.json')['all24_validation_WAVs_remote_byte_verified'];prior=read(Q/'PRIOR_COMBINED_CANDIDATE.json')
assert latest['native_base']['native_saved_state_bundle']['settings_SHA256']==prior['native_base']['native_saved_state_bundle']['settings_SHA256']and latest['native_base']['source_manifest']['source_preset_SHA256']==prior['native_base']['source_manifest']['source_preset_SHA256']
(R/'LATEST_FROZEN.json').write_text(json.dumps(latest,indent=2)+'\n')
for name,key in [('PRIMARY.bin','native_ZL_component_state'),('POST.bin','post_ZL_component_state'),('TRIM.bin','post_native_trim_state')]:shutil.copyfile(latest[key],R/name)
os.environ['DIVALEAD_NATIVE_OBJECTIVE_ROOT']=str(R/'assessment');from fl20_objective import FeaturesOriginal,a
features=FeaturesOriginal();reg=float(np.sum(np.asarray(prior['native_base']['x'])[:28]**2))*.00000025;cache=threading.local();power=a.powers
def powers(*args,**kw):result=power(*args,**kw);cache.power=result[0];return result
a.powers=powers
freq=np.fft.rfftfreq(len(a.REF),1/48000);masks=[(freq>=lo)&(freq<hi)for lo,hi in[(300,800),(2000,5000),(5000,10000),(10000,14000)]]
def lr(y):
    f=abs(np.fft.rfft(y,axis=0))**2;return np.array([10*np.log10(f[m,0].sum()/f[m,1].sum())for m in masks])
reference_lr=lr(a.REF)
def assess(y):
    residual=features.residual(y[:288000]);edit=a.h.edit_aligned(a.h.align_with_pdc(y,dict(alignment_frames=819),latency=0));balance=lr(edit);upper=float(np.sqrt(np.mean((balance[1:]-reference_lr[1:])**2)));low=abs(float(balance[0]-reference_lr[0]));err=10*np.log10(np.maximum(cache.power,1e-15)/np.maximum(a.TP,1e-15));return dict(loss=float(residual@residual)+reg,assessment=features.local.last,LR_dB=balance.tolist(),upper_LR_error=upper,lowmid_error=low,positive_excess_air_dB=float(np.maximum(err[:,4:6,2:],0).mean()),original_stereo_preservation_passed=bool(upper<=1.48 and max(abs(balance[1:]))<=1.6 and low<=3.25))
reference=Path('/workspace/divalead/diva-lead/v83-wip/Diva_original_lead_reference.wav');assert hashlib.sha256(reference.read_bytes()).hexdigest()=='7617928f743f5ceed1c3d7cf557423e2a5ff0a5e0b2b7c87f00c118a63aff14f'
(R/'PROTOCOL.json').write_text(json.dumps(dict(original_quality_passed_required=True,exact_same_original12_candidate_WAVs_and_native_inputs=True,new_comparator639_only_rendered=True,no_new_candidate_draws_or_pooling=True,all_original41_AND_full40_gates_still_required=True,latest639_first6AND10_gain_over_max0005_3SEM=True,bothcoldpositive=True,Airfirst10_bothcold_nonincreasing=True,TONE_nonincreasing=True,all_stereo148_abs16_lowmid325_paired002=True,latest_context_full_export_still_required_before_adoption=True),indent=2)+'\n')
rows=[];members=[];p=z=t=None
def start(k):return WinVST3('Latest639Same12-P-'+str(k)),WinVST3('Latest639Same12-Z-'+str(k)),NativePostTrim(R/'buffers','Latest639Same12-T-'+str(k),cleanup_on_close=True)
try:
    p,z,t=start(0)
    with tarfile.open(Q/'TWELVE_NEW_NATIVE_CONTROL_ANCHOR_CANDIDATE_WAVs.tar.gz')as source,tarfile.open(R/'ALL12_NEW_LATEST639_CONTROL_WAVs.tar.gz','w:gz',compresslevel=3)as saved:
        for rep in range(12):
            if rep in[10,11]:p.close();z.close();t.close();p,z,t=start(rep)
            raw,rate=sf.read(io.BytesIO(source.extractfile(f'native-control-{rep}.wav').read()),dtype='float32',always_2d=True);raw1,rate1=sf.read(io.BytesIO(source.extractfile(f'native-candidate-{rep}.wav').read()),dtype='float32',always_2d=True);np.testing.assert_array_equal(raw,raw1);candidate,rate2=sf.read(io.BytesIO(source.extractfile(f'candidate-{rep}.wav').read()),dtype='float32',always_2d=True);assert rate==rate1==rate2==48000
            d1=assess(candidate);old=original['captures'][rep]['candidate'];assert abs(d1['loss']-old['loss'])<1e-9 and abs(d1['positive_excess_air_dB']-old['positive_excess_air_dB'])<1e-9
            p.load(R/'PRIMARY.bin');z.load(R/'POST.bin');t.load(R/'TRIM.bin');mid,_=p.render(raw);pre,_=z.render(mid);out=t.render(pre);assert p.latency()+z.latency()==0;d0=assess(out);rows.append(dict(rep=rep,latest639=d0,unchanged_candidate=d1,gain=d0['loss']-d1['loss'],Air_delta=d1['positive_excess_air_dB']-d0['positive_excess_air_dB']))
            buffer=io.BytesIO();sf.write(buffer,out,48000,format='WAV',subtype='FLOAT');blob=buffer.getvalue();name=f'latest639-control-{rep}.wav';info=tarfile.TarInfo(name);info.size=len(blob);saved.addfile(info,io.BytesIO(blob));members.append(dict(name=name,bytes=len(blob),SHA256=hashlib.sha256(blob).hexdigest()))
            if rep==0:sf.write(R/'LATEST639_CONTROL_00.wav',out,48000,subtype='FLOAT')
    gain=np.array([d['gain']for d in rows]);air=np.array([d['Air_delta']for d in rows]);s6=float(gain[:6].std(ddof=1)/np.sqrt(6));s10=float(gain[:10].std(ddof=1)/np.sqrt(10));tone=float(np.mean([d['unchanged_candidate']['assessment']['tone_score']-d['latest639']['assessment']['tone_score']for d in rows[:10]]));guard=all(d['unchanged_candidate']['original_stereo_preservation_passed']and d['unchanged_candidate']['lowmid_error']<=d['latest639']['lowmid_error']+.02 for d in rows);passed=bool(gain[:6].mean()>max(.0005,3*s6)and gain[:10].mean()>max(.0005,3*s10)and min(gain[10:])>0 and air[:10].mean()<=0 and max(air[10:])<=0 and tone<=0 and guard)
    with tarfile.open(R/'ALL12_NEW_LATEST639_CONTROL_WAVs.tar.gz')as saved:
        for member in members:assert hashlib.sha256(saved.extractfile(member['name']).read()).hexdigest()==member['SHA256']
    result=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows,archive_members=members,original12_independent_candidate_data_not_resampled=True,original_pass_vs41_and40_retained=True,frozen_latest639=True,first6_gain=float(gain[:6].mean()),first6_SEM=s6,first10_gain=float(gain[:10].mean()),first10_SEM=s10,cold2_gains=gain[10:].tolist(),first10_Air_delta=float(air[:10].mean()),cold2_Air_delta=air[10:].tolist(),TONE_delta=tone,all12_stereo_pairedlowmid=guard,robust_improvement=passed,not_adopted=True,reference_match_reached=False)
    (R/'completion.json').write_text(json.dumps(result,indent=2)+'\n');(J/'SIXDRAW41_POINT_LATEST639_SAME12_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in['rows','archive_members']}),flush=True)
finally:
    for host in[p,z,t]:
        if host is not None:host.close()
