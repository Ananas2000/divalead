from pathlib import Path
import json,os,subprocess,sys,time
H=Path(__file__).resolve().parent;N=H.parent/'native-low-latency-effects';state=N/'ORIGINAL_PRIMARY_AIR_DIRECTION_MERGE372_STUDY.json';s=json.loads(state.read_text());pid=s['PID'];proc=Path('/proc')/str(pid);root=Path(s['root']);assert root==H/'PRIMARY_AIR_DIRECTION_MERGE372'
try:start=(proc/'stat').read_text().split()[21]
except FileNotFoundError:start=None
deadline=time.monotonic()+7200
while start is not None:
 try:
  v=(proc/'stat').read_text().split()
  if v[21]!=start or v[2]=='Z':break
 except FileNotFoundError:break
 if time.monotonic()>deadline:raise TimeoutError('Still actual DSP; no false completed archive')
 time.sleep(.5)
done=root/'completion.json';positive=False
if done.exists():positive=json.loads(done.read_text()).get('robust_improvement',False)
else:(root/'INCOMPLETE_FINITE_STUDY_BACKUP.json').write_text(json.dumps(dict(job_ended_without_completion=True,last_controller=json.loads(state.read_text()),not_adopted=True),indent=2)+'\n')
args=[sys.executable,'-B',str(H.parent/'stereo-refinement-20261025/backup_complete_finite_study.py'),'--root',str(root),'--label','original-primary-air-direction-merge372-negative','--note','Шесть новых alphaпереносов отдельно найденного более тихого направления PRIMARY на последнюю принятую372: логарифмические freq/Q умножаются, линейные gain/dynamics складываются; все94границы сохраняются. Три COMMONnative входа плюсдва heldout и сравнениесразу с372 Иполн37. Требовался новыйлокальныйвыигрыш>.0003 иAirtraininganchor37+.005, затем строгие12новыхпар; ниоднаточкане прошласcreen, не принята. На372этотдельтатихимнеоказался: измеренные cumulativeAir+.041..+.064dB. ИсточникDiva281/3длинные/ARP/ADSR/native12/POST37/nativeTrimфиксированы. Все сохранённые реальныенative/control372/anchor37/candidateWAV,state/протоколы/код архивированы. Основная372сохранена, дальнейшийотдельный anchoredPRIMARYfitter требуетполнуюпроверкуобоихсравнений.']
if positive:args.append('--retain-local-audio')
subprocess.run(args,check=True)
