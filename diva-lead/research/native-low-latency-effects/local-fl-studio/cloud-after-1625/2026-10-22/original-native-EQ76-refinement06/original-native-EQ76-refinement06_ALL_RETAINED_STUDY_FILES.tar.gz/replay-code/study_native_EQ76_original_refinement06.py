"""Actual native gain/matrix/EQ76 refit in current WS52/two-ZL context.

Reset exact saved states each trial and change only requested native controls.
Never reconstruct a different WaveShaper while evaluating EQ parameters.
"""
from pathlib import Path
import concurrent.futures,datetime,gzip,hashlib,io,json,os,queue,tarfile,threading,traceback
import numpy as np,soundfile as sf
import original_native_EQ76_ref06_library as q
from fl20_curve import apply_candidate,native_dsp_settings_SHA256
R=q.ROOT;STATE=q.STATE;seed=q.seed;base=np.array(seed['x']);bundle=seed['native_saved_state_bundle'];bundle_dir=Path(bundle['directory']);assert q.prior['accepted_full_public_kit']=='ZL32'and q.prior['native_base_export_directory'].endswith('_10')
FREQS=np.array([40,65,100,160,250,400,630,1000,1600,2500,4000,6300,10000,16000],float);steps=np.r_[np.full(28,.2),[.1,.1],np.full(4,.01),np.full(28,.009),np.full(14,.006)];clients=[];pool=queue.Queue();mutex=threading.Lock();rows=[];natives=[]
def quant(v):
 v=np.asarray(v,float).copy();changed=v[:76]!=base[:76]
 v[:30]=np.round(np.clip(v[:30],-18,18)*100)/100;v[30:34]=np.round(np.clip(v[30:34],-1,1)*12800)/12800;v[34:62]=np.clip(v[34:62],-.9,.9);v[62:76]=np.round(np.clip(v[62:76],.005,.85)*65536)/65536
 v[:76]=np.where(changed,v[:76],base[:76]);assert np.array_equal(v[76:],base[76:]);return v
def configure(c,v):
 apply_candidate(c,base,seed)
 for key,value in seed['chorus_overrides'].items():c.set(3,int(key),int(value))
 for j in np.flatnonzero(v[:76]!=base[:76]):
  j=int(j)
  if j<28:c.set(4+j//7,j%7,int(round(v[j]*100)))
  elif j<30:
   for node in ([4,5]if j==28 else[6,7]):c.set(node,35,int(round(v[j]*100)))
  elif j<34:c.set(8,j-30,int(round(v[j]*12800)))
  elif j<62:
   n=j-34;freq=FREQS[n%14]*2**v[j];raw=int(round(np.log(np.clip(freq,20,20000)/20)/np.log(1000)*65536));c.set(4+n//7,7+n%7,raw)
  else:
   n=j-62
   for node in ([4,6]if n<7 else[5,7]):c.set(node,14+n%7,int(round(v[j]*65536)))
def native(v,tag):
 c=q.native(q.source['native_input'],tag);configure(c,v);return c
def record(phase,**kw):
 s=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),cases=len(rows),actual_native_hosts=[c.proc.pid for c,p,z in clients],actual_ZL_hosts=[v.child.pid for c,p,z in clients for v in[p,z]],original_is_the_only_target=True,only_native_EQ76_varied=True,WS52_Chorus_source_Diva281_MIDI_ARP_ADSR_both_ZL_unchanged=True,only_three_held_notes=True,not_adopted=True,reference_match_reached=False,**kw);p=STATE.with_suffix('.partial');p.write_text(json.dumps(s,indent=2)+'\n');p.replace(STATE)
def assess(y,v):
 d=q.assess(y);d['loss']+=float(np.sum(v[:28]**2)-np.sum(base[:28]**2))*.00000025;return d
def evaluate(case,reps=3,keep=True):
 label,v=case;v=quant(v);c,p,z=pool.get()
 try:
  configure(c,v);captures=[]
  for k in range(reps):raw,_=c.render();out=q.cascade(raw,p,z);captures.append(assess(out,v))
  row=dict(label=label,x=v.tolist(),loss=float(np.mean([d['loss']for d in captures])),realization_losses=[d['loss']for d in captures],stereo_preservation_passed=all(d['stereo_preservation_passed']for d in captures),assessment=captures[len(captures)//2])
  if keep:
   with mutex:rows.append(row)
  return row
 finally:pool.put((c,p,z))
def add(tar,name,y,members):
 b=io.BytesIO();sf.write(b,y,48000,format='WAV',subtype='FLOAT');data=b.getvalue();i=tarfile.TarInfo(name);i.size=len(data);tar.addfile(i,io.BytesIO(data));members.append(dict(name=name,bytes=len(data),SHA256=hashlib.sha256(data).hexdigest()))
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(native76_gain_matrix_EQ_only=True,canonical_saved_native_states_reset_each_trial=True,only_changed_parameters_set=True,original_WS52_bytes_and_other_fixed_native_states_preserved=True,training_repetitions_per_trial=3,finalists_new12_realizations=True,full_original_score_weights_alignment_stereo_guards_unchanged=True,BOTH_first6_AND_first10_gain_over_max_0005_and_3SEM=True,validation_warm10_cold2=True,both_cold_gains_positive=True,strict_native_zeroDepth_FST_replay_max_abs=2e-7,strict_actual_ZL_replay_rtol_float32eps=8,strict_actual_ZL_replay_atol=1e-12),indent=2)+'\n')
try:
 record('starting_canonical_native_EQ76_original_refit')
 for k in range(2):c=native(base,'NativeEQ76ref06-'+str(k));p=q.WinVST3('NativeEQ76ref06-primary-'+str(k));z=q.WinVST3('NativeEQ76ref06-post-'+str(k));clients.append((c,p,z));pool.put((c,p,z))
 # Origin means no SDK parameter edits after exact bundle restoration.
 c=clients[0][0];configure(c,base)
 for row in bundle['manifest']:
  dst=R/('origin-'+str(row['node'])+'.bin');c.save_state(row['node'],dst);assert dst.read_bytes()==(bundle_dir/row['state']).read_bytes()
 (R/'UNCHANGED_ORIGIN_ALL12_CANONICAL_STATE_PROOF.json').write_text(json.dumps(dict(all12_actual_plugin_state_bytes_unchanged=True,no_generated_approximate_WS_replacement=True),indent=2)+'\n')
 baseline=evaluate(('unchanged-current-control',base),12);current=baseline;rng=np.random.default_rng(2026102676)
 def choose(checked,current):return min([current]+[r for r in checked if r['stereo_preservation_passed']],key=lambda r:r['loss'])
 with concurrent.futures.ThreadPoolExecutor(2)as executor:
  for sweep in range(2):
   proposals=[]
   for k in range(48):
    v=np.array(current['x']);ix=rng.choice(76,size=int(rng.choice([2,4,8,16])),replace=False);v[ix]+=rng.normal(size=len(ix))*steps[ix]*float(rng.choice([.5,1,2]))*(.7**sweep);proposals.append((f'coupled-{sweep}-{k}',v))
   current=choose(list(executor.map(evaluate,proposals)),current)
   for j in rng.permutation(76):
    proposals=[]
    for factor in [-2,-1,1,2]:
     v=np.array(current['x']);v[j]+=factor*steps[j]*(.65**sweep);proposals.append((f'coordinate-{sweep}-{j}-{factor}',v))
    current=choose(list(executor.map(evaluate,proposals)),current);record('actual_native_EQ76_coordinate_fit',sweep=sweep,coordinate=int(j),control_mean=baseline['loss'],best_mean=current['loss'])
 (R/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0));unique=[];seen=set()
 for row in sorted(rows,key=lambda r:r['loss']):
  key=tuple(row['x'])
  if row['stereo_preservation_passed']and key not in seen:unique.append(row);seen.add(key)
  if len(unique)==4:break
 finalists=[evaluate(('fresh-finalist-'+str(k),r['x']),12,False)for k,r in enumerate(unique)];control_fresh=evaluate(('fresh-current-control',base),12,False);winner=min(finalists,key=lambda r:r['loss']);ready=bool(winner['x']!=base.tolist()and control_fresh['loss']-winner['loss']>.0003 and winner['stereo_preservation_passed']);summary=dict(training_cases=len(rows),training_control_mean=baseline['loss'],fresh_control=control_fresh,finalists=finalists,winner=winner,sufficient_screen=ready,robust_improvement=False,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False);(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
 if ready:
  chosen=np.array(winner['x']);c0,p0,z0=clients[0];c1,p1,z1=clients[1];configure(c0,base);configure(c1,chosen);captures=[];members=[];record('twelve_new_native_EQ76_paired_validation')
  with tarfile.open(R/'TWELVE_FRESH_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in[10,11]:
     c0.close();c1.close();c0=native(base,'NativeEQ76ref06-cold-control-'+str(rep));c1=native(chosen,'NativeEQ76ref06-cold-candidate-'+str(rep));clients[0]=(c0,p0,z0);clients[1]=(c1,p1,z1)
    raw0,_=c0.render();old=q.cascade(raw0,p0,z0);d0=assess(old,base);raw1,_=c1.render();out=q.cascade(raw1,p1,z1);d1=assess(out,chosen);captures.append(dict(rep=rep,control=d0,candidate=d1,improvement=d0['loss']-d1['loss']))
    for name,y in[('native-control',raw0),('native-candidate',raw1),('control',old),('candidate',out)]:add(tar,f'{name}-{rep}.wav',y,members)
    if rep==0:
     for name,y in[('NATIVE_CONTROL',raw0),('NATIVE_CANDIDATE',raw1),('CONTROL',old),('CANDIDATE',out)]:sf.write(R/(name+'_00.wav'),y,48000,subtype='FLOAT')
    record('first6_AND_first10_plus_cold2_running',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  delta=np.array([r['improvement']for r in captures]);s6=float(np.std(delta[:6],ddof=1)/np.sqrt(6));s10=float(np.std(delta[:10],ddof=1)/np.sqrt(10));robust=bool(np.mean(delta[:6])>max(.0005,3*s6)and np.mean(delta[:10])>max(.0005,3*s10)and min(delta[10:])>0 and all(r['candidate']['stereo_preservation_passed']for r in captures));saved=R/'saved-native-bundle';manifest=[];changed=[]
  for row in bundle['manifest']:
   dst=saved/row['state'];dst.parent.mkdir(parents=True,exist_ok=True);c1.save_state(row['node'],dst)
   if dst.read_bytes()!=(bundle_dir/row['state']).read_bytes():changed.append(row['node'])
   if row['node']not in[4,5,6,7,8]:assert dst.read_bytes()==(bundle_dir/row['state']).read_bytes()
   manifest.append(dict(row,state_bytes=dst.stat().st_size,state_SHA256=hashlib.sha256(dst.read_bytes()).hexdigest()))
  newseed=dict(seed,x=chosen.tolist());newseed['native_saved_state_bundle']=dict(bundle,directory=str(saved),manifest=manifest,settings_SHA256=native_dsp_settings_SHA256(chosen,newseed));c1.set(3,1,0);expected,_=c1.render();fresh=q.native(q.source['native_input'],'NativeEQ76ref06-strict-state-replay');natives=[fresh]
  apply_candidate(fresh,chosen,newseed)
  for key,value in seed['chorus_overrides'].items():fresh.set(3,int(key),int(value))
  fresh.set(3,1,0);again,_=fresh.render();error=float(abs(again-expected).max());assert error<=2e-7,error;fresh.close();natives=[]
  with tarfile.open(R/'TWELVE_FRESH_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
  summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(np.mean(delta[:6])),first6_SEM=s6,first10_mean_improvement=float(np.mean(delta[:10])),first10_SEM=s10,cold2_improvements=delta[10:].tolist(),robust_improvement=robust,changed_native_nodes=changed,unchanged_WS52_and_other_fixed_native_states_byte_exact=True,strict_native_zeroDepth_replay_error=error);(R/'NATIVE_CANDIDATE_RESEARCH_ONLY.json').write_text(json.dumps(newseed,indent=2)+'\n');combined=dict(q.prior,native_base=newseed,loss=float(np.mean([r['candidate']['loss']for r in captures[:10]])),not_adopted_until_supported_export=True);(R/'COMBINED_CANDIDATE_RESEARCH_ONLY.json').write_text(json.dumps(combined,indent=2)+'\n')
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_native_EQ76_ref06_complete_not_adopted',robust_improvement=summary['robust_improvement'],sufficient_screen=ready);print(json.dumps({k:v for k,v in summary.items()if k not in['captures','archive_members','winner','finalists','fresh_control']}),flush=True)
except BaseException:record('failed_preserve_current_full32_and_best',error=traceback.format_exc());raise
finally:
 for c in natives:c.close()
 for c,p,z in clients:c.close();p.close();z.close()
