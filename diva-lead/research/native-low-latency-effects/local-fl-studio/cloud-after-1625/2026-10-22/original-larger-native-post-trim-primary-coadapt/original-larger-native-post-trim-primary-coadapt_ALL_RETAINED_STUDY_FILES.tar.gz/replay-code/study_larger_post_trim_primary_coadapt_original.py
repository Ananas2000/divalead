"""Test stronger post-channel balancing with a separate real primary fit."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,traceback
import numpy as np,soundfile as sf
import larger_post_trim_coadapt_support as q
from native_post_trim import NativePostTrim
from normal_real_ZL_refit import RealPrimaryFit
R=q.ROOT;H=Path(__file__).resolve().parent;STATE=q.STATE;WinVST3=q.WinVST3;assert q.prior.get('requires_post_native_trim');(R/'BASE_TRIM.bin').write_bytes(Path(q.prior['post_native_trim_state']).read_bytes());models=[dict(name='LeftCut'+str(db),left_dB=db,right_dB=0.,left_raw=NativePostTrim.raw_from_dB(db),right_raw=12800)for db in[-.5,-1.,-1.5,-2.]];clients=[];trim_clients=[];native=None;fit=None;results=[];control_air=None;control_lowmid=None;power_cache=q.threading.local();original_power=q.a.powers
def capture(*args,**kw):
 result=original_power(*args,**kw);power_cache.power=result[0];return result
q.a.powers=capture
def assessment(y):
 d=q.assessment(y);e=10*np.log10(np.maximum(power_cache.power,1e-15)/np.maximum(q.a.TP,1e-15));d['positive_excess_air_3500_6500_dB']=float(np.maximum(e[:,4:6,2:],0).mean());d['original_stereo_preservation_passed']=bool(d['upper_stereo_guard']and d['lowmid_error']<=3.25 and d['upper_error']<=1.48);d['stereo_preservation_passed']=d['original_stereo_preservation_passed'];return d
def record(phase,**extra):
 d=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),actual_ZL_hosts=[c.child.pid for p,z in clients for c in[p,z]],actual_native_post_trim_hosts=[c.chain.proc.pid for c in trim_clients],source_native12_Diva281_WS52_POST_MIDI3heldnotes_ARP_ADSR_fixed=True,separate_actual_primary87_refit_for_each_larger_trim=True,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False);d.update(extra);p=STATE.with_suffix('.partial');p.write_text(json.dumps(d,indent=2)+'\n');p.replace(STATE)
def cascade(raw,p,z,primary):
 p.load(primary);z.load(R/'CONTROL_POST.bin');mid,_=p.render(raw);out,_=z.render(mid);assert p.latency()+z.latency()==0;return out
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(models=models,actual_Fruity_Stereo_Shaper_for_all_candidate_processing=True,separate_actual_primary87_refit_each_model=True,source_native12_Diva281_WS52_POST_MIDI3heldnotes_ARP_ADSR_unchanged=True,three_new_native_training_inputs_two_heldouts=True,all_original_score_weights_alignment_unchanged=True,upper_LR_RMS_error_limit_dB=1.48,max_abs_upper_LR_dB=1.6,extra_per_pair_lowmid_error_reduction_at_least_dB=.25,lowmid_absolute_error_limit_dB=3.25,training_air_max_control_mean_plus_dB=.01,validation_first10_mean_and_both_cold_air_increase_max_dB=.02,first6_AND_first10_gain_over_max_0005_and_3SEM=True,warm10_cold2=True,both_cold_gains_positive=True,latest_control_revalidation_required_if_main_advances=True),indent=2)+'\n')
try:
 record('three_new_actual_native_inputs_and_current_native13_controls');native=q.native('LargerPostTrim-source-training');p=WinVST3('LargerPostTrim-control-primary');z=WinVST3('LargerPostTrim-control-post');clients=[(p,z)];trim=NativePostTrim(R/'host-inputs','LargerPostTrim-control-trim',cleanup_on_close=True);trim.load(R/'BASE_TRIM.bin');trim_clients=[trim];controls=[]
 for k in range(3):
  raw,_=native.render();raw.astype('<f4').tofile(R/f'frozen-native-{k}.f32');sf.write(R/f'TRAINING_NATIVE_{k}.wav',raw,48000,subtype='FLOAT');out=cascade(raw,p,z,R/'PRIMARY.bin');out=trim.render(out);controls.append(assessment(out));sf.write(R/f'CONTROL_{k}.wav',out,48000,subtype='FLOAT')
 native.close();native=None;p.close();z.close();clients=[];trim.close();trim_clients=[];control_mean=float(np.mean([r['loss']for r in controls]));control_air=float(np.mean([r['positive_excess_air_3500_6500_dB']for r in controls]));control_lowmid=float(np.mean([r['lowmid_error']for r in controls]));(R/'CONTROL_ASSESSMENTS.json').write_text(json.dumps(controls,indent=2)+'\n')
 for model in models:
  folder=R/model['name'];folder.mkdir()
  for k in range(3):os.link(R/f'frozen-native-{k}.f32',folder/f'frozen-native-{k}.f32')
  trim_pool=q.queue.Queue()
  for k in range(2):
   c=NativePostTrim(folder/'host-inputs','LargerPostTrim-'+str(os.getpid())+'-'+model['name']+'-native-'+str(k),cleanup_on_close=True);c.configure(model['left_raw'],model['right_raw']);trim_clients.append(c);trim_pool.put(c)
  def model_assess(before):
   c=trim_pool.get()
   try:
    y=c.render(before);d=assessment(y);d['stereo_preservation_passed']=bool(d['original_stereo_preservation_passed']and d['lowmid_error']<=control_lowmid-.25 and d['positive_excess_air_3500_6500_dB']<=control_air+.01);return d
   finally:trim_pool.put(c)
  fit=RealPrimaryFit(folder,R/'PRIMARY.bin',R/'CONTROL_POST.bin',model_assess,lambda phase,**kw:record('actual_larger_trim_primary87_fit',model=model,fit_phase=phase,**kw));clients=fit.clients;initial,current=fit.fit(sweeps=1);held=[fit.evaluate(('heldout-'+str(k),current['x']),k,False)for k in[1,2]];p,z=fit.clients[0];fit.configure(p,current['x']);p.save(folder/'CANDIDATE_PRIMARY.bin');trim_clients[0].save(folder/'CANDIDATE_TRIM.bin');mid,_=p.render(input_file=folder/'frozen-native-0.f32');z.load(R/'CONTROL_POST.bin');before,_=z.render(mid);out=trim_clients[0].render(before);sf.write(folder/'SELECTED_TRAINING_FULL_WIP.wav',out,48000,subtype='FLOAT');(folder/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(fit.rows).encode(),mtime=0));row=dict(model=model,folder=str(folder),training_cases=len(fit.rows),initial=initial,selected=current,heldout=held,heldout_mean=float(np.mean([r['loss']for r in held])),heldout_all_constraints_passed=all(r['original_stereo_preservation_passed']and r['lowmid_error']<=controls[k]['lowmid_error']-.25 and r['positive_excess_air_3500_6500_dB']<=controls[k]['positive_excess_air_3500_6500_dB']+.02 for k,r in zip([1,2],held)),not_adopted=True);results.append(row);(folder/'SCREEN_RESULT.json').write_text(json.dumps(row,indent=2)+'\n');fit.close();fit=None;clients=[]
  for c in trim_clients:c.close()
  trim_clients=[];(R/'COMPLETED_MODEL_REFITS.json').write_text(json.dumps(results,indent=2)+'\n');record('larger_trim_model_complete',model=model,heldout_mean=row['heldout_mean'],accepted_control_mean=control_mean)
 eligible=[r for r in results if r['heldout_all_constraints_passed']];winner=min(eligible,key=lambda r:r['heldout_mean'])if eligible else None;ready=bool(winner and control_mean-winner['heldout_mean']>.0003);summary=dict(training_cases=sum(r['training_cases']for r in results),accepted_control_mean=control_mean,control_lowmid_error=control_lowmid,control_air=control_air,winner=winner,sufficient_screen=ready,robust_improvement=False,requires_latest_main_context_revalidation=True,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False);(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
 if ready:
  folder=Path(winner['folder']);record('twelve_new_same_input_native13_paired_validation');native=q.native('LargerPostTrim-validation-source');p=WinVST3('LargerPostTrim-validation-primary');z=WinVST3('LargerPostTrim-validation-post');clients=[(p,z)];old_trim=NativePostTrim(R/'host-inputs','LargerPostTrim-validation-old-trim',cleanup_on_close=True);old_trim.load(R/'BASE_TRIM.bin');new_trim=NativePostTrim(R/'host-inputs','LargerPostTrim-validation-new-trim',cleanup_on_close=True);new_trim.load(folder/'CANDIDATE_TRIM.bin');trim_clients=[old_trim,new_trim];captures=[];members=[]
  with q.tarfile.open(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in[10,11]:
     native.close();native=q.native('LargerPostTrim-cold-source-'+str(rep));old_trim.close();new_trim.close();old_trim=NativePostTrim(R/'host-inputs','LargerPostTrim-cold-old-'+str(rep),cleanup_on_close=True);old_trim.load(R/'BASE_TRIM.bin');new_trim=NativePostTrim(R/'host-inputs','LargerPostTrim-cold-new-'+str(rep),cleanup_on_close=True);new_trim.load(folder/'CANDIDATE_TRIM.bin');trim_clients=[old_trim,new_trim]
    raw,_=native.render();old=cascade(raw,p,z,R/'PRIMARY.bin');old=old_trim.render(old);d0=assessment(old);before=cascade(raw,p,z,folder/'CANDIDATE_PRIMARY.bin');out=new_trim.render(before);d1=assessment(out);captures.append(dict(rep=rep,control=d0,candidate=d1,improvement=d0['loss']-d1['loss'],air_increase=d1['positive_excess_air_3500_6500_dB']-d0['positive_excess_air_3500_6500_dB'],lowmid_error_reduction=d0['lowmid_error']-d1['lowmid_error']))
    for name,y in[('native',raw),('control',old),('candidate',out)]:q.add(tar,f'{name}-{rep}.wav',y,members)
    if rep==0:
     for name,y in[('NATIVE_INPUT',raw),('CONTROL',old),('BEFORE_TRIM',before),('CANDIDATE',out)]:sf.write(R/(name+'_00.wav'),y,48000,subtype='FLOAT')
    record('first6_AND_first10_cold2_with_balance_improvement',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  delta=np.array([r['improvement']for r in captures]);air=np.array([r['air_increase']for r in captures]);s6=float(np.std(delta[:6],ddof=1)/np.sqrt(6));s10=float(np.std(delta[:10],ddof=1)/np.sqrt(10));robust=bool(np.mean(delta[:6])>max(.0005,3*s6)and np.mean(delta[:10])>max(.0005,3*s10)and min(delta[10:])>0 and np.mean(air[:10])<=.02 and max(air[10:])<=.02 and all(r['candidate']['original_stereo_preservation_passed']and r['lowmid_error_reduction']>=.25 for r in captures));summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(np.mean(delta[:6])),first6_SEM=s6,first10_mean_improvement=float(np.mean(delta[:10])),first10_SEM=s10,cold2_improvements=delta[10:].tolist(),first10_air_increase=float(np.mean(air[:10])),cold2_air_increase=air[10:].tolist(),robust_improvement=robust)
  with q.tarfile.open(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_larger_native_trim_primary_coadapt_complete_not_adopted',sufficient_screen=ready,robust_improvement=summary['robust_improvement']);print(json.dumps({k:v for k,v in summary.items()if k not in['winner','captures','archive_members']}),flush=True)
except BaseException:record('failed_preserve_full33_and_latest_main',error=traceback.format_exc());raise
finally:
 if native is not None:native.close()
 if fit is not None:fit.close();clients=[]
 for p,z in clients:p.close();z.close()
 for c in trim_clients:c.close()
