"""Check whether nominally unchanged detector text commands preserve the DSP."""
from pathlib import Path
import csv,hashlib,json,struct,xml.etree.ElementTree as E
import numpy as np,soundfile as sf
from win_vst3 import D,WinVST3
H=Path(__file__).resolve().parent;R=H/'PRIMARY_DYNAMIC_DETECTOR24';Q=H/'DYNAMIC_DETECTOR24_UNCHANGED_DIAGNOSTIC';Q.mkdir();params={r['title']:int(r['id'])for r in csv.DictReader((D/'ZL-default-parameters.tsv').open(),delimiter='\t')}
def values(b):return {p.attrib['id']:float(p.attrib['value'])for p in E.fromstring(b[8:8+struct.unpack_from('<I',b,4)[0]]).find('Para')}
original=values((R/'CONTROL_PRIMARY.bin').read_bytes());specs=json.loads((R/'PREDECLARED_PROTOCOL.json').read_text())['variable_parameters'];p=WinVST3('Detector24-unchanged-physical');z=WinVST3('Detector24-unchanged-post');rows=[]
try:
 p.load(R/'CONTROL_PRIMARY.bin');z.load(R/'POST.bin');mid,_=p.render(input_file=R/'native-0.f32');old,_=z.render(mid);sf.write(Q/'CONTROL.wav',old,48000,subtype='FLOAT')
 for case in ['ALL_UNCHANGED',*[s['key']for s in specs]]:
  p.load(R/'CONTROL_PRIMARY.bin');commands=[]
  for s in specs:
   if case=='ALL_UNCHANGED'or case==s['key']:commands.append(dict(parameter=s['title'],sent=original[s['key']],response=p.text(params[s['title']],format(original[s['key']],'.12g'))))
  dst=Q/(case+'.bin');p.save(dst);now=values(dst.read_bytes());changed={k:[v,now[k]]for k,v in original.items()if now[k]!=v};z.load(R/'POST.bin');mid,_=p.render(input_file=R/'native-0.f32');out,_=z.render(mid);error=float(abs(out-old).max());rows.append(dict(case=case,commands=commands,changed_XML=changed,max_abs_error=error,PDC_frames=p.latency()+z.latency()));
  if case=='ALL_UNCHANGED':sf.write(Q/'NOMINALLY_UNCHANGED_ALL_COMMANDS.wav',out,48000,subtype='FLOAT')
finally:p.close();z.close()
result=dict(cases=rows,not_adopted=True,reference_match_reached=False);(Q/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(rows),flush=True)
