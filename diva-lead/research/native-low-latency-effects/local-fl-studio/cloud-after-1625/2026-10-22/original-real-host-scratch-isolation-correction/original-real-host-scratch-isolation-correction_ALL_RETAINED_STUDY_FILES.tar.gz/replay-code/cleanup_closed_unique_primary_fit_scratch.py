"""Release only inactive regenerable, uniquely named VST3 render buffers."""
from pathlib import Path
import datetime,hashlib,json,os,re,shutil
D=Path('/tmp/divalead-local-1625/internet-plugins-20261023');H=Path(__file__).resolve().parent
active=set();opened=set()
for folder in Path('/proc').glob('[0-9]*/fd'):
 try:
  for fd in folder.iterdir():
   try:
    name=os.readlink(fd);opened.add(name)
    if name.startswith(str(D)+'/')and name.endswith('-host.log'):active.add(Path(name).name[:-len('-host.log')])
   except OSError:pass
 except OSError:pass
removed=[]
for p in D.glob('PrimaryFit-*.f32'):
 m=re.fullmatch(r'(PrimaryFit-[0-9a-f]{12}-[0-9]+-(?:primary|post)-[01])-(?:input|output)\.f32',p.name)
 if not m or p.is_symlink()or m[1]in active or str(p)in opened:continue
 log=D/(m[1]+'-host.log');assert log.is_file()and'READY 'in log.read_text(errors='replace')
 removed.append(dict(path=str(p),bytes=p.stat().st_size,SHA256=hashlib.sha256(p.read_bytes()).hexdigest(),owning_plugin_host_log_closed_and_no_file_descriptors_open=True));p.unlink()
ledger=H/'CLOSED_UNIQUE_PRIMARY_FIT_SCRATCH_RELEASE.json';prior=json.loads(ledger.read_text())if ledger.exists()else dict(runs=[])
prior['runs'].append(dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),removed=removed,logical_bytes=sum(r['bytes']for r in removed),tmp_free_MiB=shutil.disk_usage('/tmp').free/2**20,only_default_regenerable_host_scratch_not_selected_audio_or_states=True));ledger.write_text(json.dumps(prior,indent=2)+'\n');print(json.dumps({k:v for k,v in prior['runs'][-1].items()if k!='removed'}))
