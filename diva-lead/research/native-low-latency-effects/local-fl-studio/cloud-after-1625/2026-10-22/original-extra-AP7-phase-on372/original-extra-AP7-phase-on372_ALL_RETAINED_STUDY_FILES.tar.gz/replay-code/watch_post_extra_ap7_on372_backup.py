from pathlib import Path
import json,os,subprocess,sys,time
H=Path(__file__).resolve().parent;N=H.parent/'native-low-latency-effects';state=N/'ORIGINAL_POST_EXTRA_AP7_ON372_STUDY.json';s=json.loads(state.read_text());pid=s['PID'];proc=Path('/proc')/str(pid);root=Path(s['root']);assert root==H/'POST_EXTRA_AP7_ON372'
try:start=(proc/'stat').read_text().split()[21]
except FileNotFoundError:start=None
deadline=time.monotonic()+7200
while start is not None:
 try:
  v=(proc/'stat').read_text().split()
  if v[21]!=start or v[2]=='Z':break
 except FileNotFoundError:break
 if time.monotonic()>deadline:raise TimeoutError('Still actual DSP; no false completed archive')
 time.sleep(.5)
done=root/'completion.json';positive=False
if done.exists():positive=json.loads(done.read_text()).get('robust_improvement',False)
else:(root/'INCOMPLETE_FINITE_STUDY_BACKUP.json').write_text(json.dumps(dict(job_ended_without_completion=True,last_controller=json.loads(state.read_text()),not_adopted=True),indent=2)+'\n')
args=[sys.executable,'-B',str(H.parent/'stereo-refinement-20261025/backup_complete_finite_study.py'),'--root',str(root),'--label','original-extra-AP7-phase-on372','--note','88новыхAP7длясогласованияфазыStereo/Mid/Side напоследней372. Этофазоваягипотеза,необещаниеуменьшенияшума: inheritedAirнакопленныймежду37и372отдельнонеобъявляетсясохранённым. Обычныепрежниеlocalfirst6AND10/cold2/stereo/Air+.02нетронуты,sourceDiva281/3длинныеARP/ADSR/native12/PRIMARY372/POST0..6/nativeTrimфиксированы. Новаяточкадоfullcold/экспорта/актуальногоконтекстанепринята. Сохраняютсяточныесостояния/метрикивсех88проб иrecordimprovingtrainingWAV;еслиready,все36validationnative/control/candidateWAVlosslessво вложенномTAR.']
if positive:args.append('--retain-local-audio')
subprocess.run(args,check=True)
