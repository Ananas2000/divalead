from pathlib import Path
u=Path(__file__).resolve().parent;q=(u/'bipolar_finalist1_air_margin_support.py').read_text().replace("ROOT=H/'BIPOLAR_FINALIST1_AIR_MARGIN_REPAIR'","ROOT=Path('/tmp/divalead-WS-native-oversampling-joint109-current39-20261031')").replace('ORIGINAL_BIPOLAR_FINALIST1_AIR_MARGIN_REPAIR_STUDY','ORIGINAL_NATIVE_WS_OVERSAMPLING_JOINT109_CURRENT39_STUDY');(u/'WS_OS_joint109_support.py').write_text(q)
s=(u/'study_joint109_current556_anchor38.py').read_text().replace('import Joint109_current556_anchor38_support as q','import WS_OS_joint109_support as q')
s=s.replace('556','LATEST').replace('38','39');s=s.replace("assert q.prior['source_accepted_cohort']==LATEST","assert q.prior['full_public_kit_directory']=='ZL-WIP39'")
s=s.replace('fit=n=p=z=trim=None','fit=n=nc=p=z=trim=None');s=s.replace("R=q.ROOT;STATE=q.STATE;", "R=q.ROOT;STATE=q.STATE;(Path(__file__).resolve().parent/'WS_OS_JOINT109_CURRENT39').symlink_to(R,target_is_directory=True);")
loc=s.index('def cascade(')
s=s[:loc]+'''GUI_WS=Path('/tmp/divalead-WS-oversampling-spinner-20261031/wheel_up/after.bin');(R/'GUI_OVERSAMPLING_STEP1_WS.bin').write_bytes(GUI_WS.read_bytes())
def candidate_native(tag):
 c=q.native(q.source['native_input'],tag);c.load_state(0,R/'GUI_OVERSAMPLING_STEP1_WS.bin');return c
'''+s[loc:]
s=s.replace('three_COMMON_native_inputs_for_currentLATEST_anchor39_and_every_training_proposal=True','three_COMMON_oversampled_native_inputs_for_every_training_proposal_control_separate_native_draws=True')
s=s.replace('source_Diva281_MIDI3held_ARP_ADSR_native12_nativeTrim_unchanged=True','source_Diva281_MIDI3held_ARP_ADSR_other11native_nativeTrim_unchanged_only_GUI_WS_oversampling_step1=True,frozen_comparator_cohort=q.prior[\'source_accepted_cohort\']')
s=s.replace('no_source_native_MIDI_or_trim_change=True','no_source_MIDI_or_trim_change=True,only_WS_native_GUI_oversampling_step1_changed=True,supported_generator_for_byte18_not_yet_migrated=True')
s=s.replace('three_exact_same_native_realizations_shared_by_control_and_every_primary_proposal=True','three_exact_same_candidate_native_realizations_shared_by_every_proposal_control_uses_old_WS=True')
s=s.replace('three_primary_coordinate_sweeps=True','two_primary_coordinate_sweeps=True').replace('fit.fit(sweeps=3)','fit.fit(sweeps=2)')
s=s.replace("+'-native');p=q.WinVST3", "+'-control-native');nc=candidate_native('WS_OS_Joint109-'+str(os.getpid())+'-candidate-native');p=q.WinVST3")
s=s.replace('raw,_=n.render();inputs.append(raw);out=cascade(raw','raw,_=n.render();candidate_raw,_=nc.render();inputs.append(candidate_raw);sf.write(R/f\'TRAINING_OS_NATIVE_{k}.wav\',candidate_raw,48000,subtype=\'FLOAT\');out=cascade(raw')
s=s.replace('n.close();n=None;(R/','n.close();n=None;nc.close();nc=None;(R/')
s=s.replace("+'-validation-native');p=q.WinVST3", "+'-validation-native');nc=candidate_native('WS_OS_Joint109-'+str(os.getpid())+'-validation-candidate-native');p=q.WinVST3")
s=s.replace("if rep in[10,11]:n.close();n=q.native(q.source['native_input'],'Oct31Joint109-LATEST-'+str(os.getpid())+'-cold-native-'+str(rep))", "if rep in[10,11]:n.close();nc.close();n=q.native(q.source['native_input'],'Oct31Joint109-LATEST-'+str(os.getpid())+'-cold-native-'+str(rep));nc=candidate_native('WS_OS_Joint109-'+str(os.getpid())+'-cold-candidate-'+str(rep))")
s=s.replace('new=cascade(raw,component,post_component)','candidate_raw,_=nc.render();new=cascade(candidate_raw,component,post_component)')
s=s.replace("[('native',raw),('controlLATEST',old)","[('native-control',raw),('native-OS-candidate',candidate_raw),('controlLATEST',old)")
s=s.replace("[('NATIVE_INPUT',raw),('CONTROLLATEST',old)","[('NATIVE_CONTROL',raw),('NATIVE_CANDIDATE',candidate_raw),('CONTROLLATEST',old)")
s=s.replace('for c in[n,p,z,trim]:','for c in[n,nc,p,z,trim]:')
s=s.replace('not_adopted_until_supported_full_export=True,requires_latest_BEST_revalidation=True','not_adopted_until_supported_full_export=True,requires_latest_BEST_revalidation=True,source_WS_GUI_oversampling_step1_requires_explicit_generator_schema_migration=True')
s=s.replace("if summary['sufficient_screen']:\n", "if summary['sufficient_screen']:\n  assert component.read_bytes()!=(R/'PRIMARY.bin').read_bytes()or post_component.read_bytes()!=(R/'POST.bin').read_bytes(),'Do not retest the unchanged failed direct-OS point'\n")
assert 'candidate_raw,_=nc.render();new=cascade' in s and 'nc=candidate_native' in s
(u/'study_WS_OS_both_ZL109_current39.py').write_text(s)
