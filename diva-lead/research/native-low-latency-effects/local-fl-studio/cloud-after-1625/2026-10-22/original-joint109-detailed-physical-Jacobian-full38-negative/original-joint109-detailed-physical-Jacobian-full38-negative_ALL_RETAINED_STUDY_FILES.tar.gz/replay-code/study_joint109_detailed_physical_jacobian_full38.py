"""Finite-difference real-DSP Jacobian, joint bounded LM proposals; original loss unchanged."""
from pathlib import Path
import ast,concurrent.futures,csv,datetime,gzip,hashlib,io,json,os,queue,struct,tarfile,threading,traceback,xml.etree.ElementTree as ET
import numpy as np,soundfile as sf
import Joint109_detailed_jacobian_support as q
from scipy.optimize import minimize
from native_post_trim import NativePostTrim
R=q.ROOT;STATE=q.STATE;n=None;clients=[];pool=queue.Queue();cache=threading.local();rows=[];captures=[];members=[];lock=threading.Lock();native_inputs=[];controls=[];oldpowers=q.a.powers;oldres=q.features.residual
params={r['title']:int(r['id'])for r in csv.DictReader((q.D/'ZL-default-parameters.tsv').open(),delimiter='\t')};ns=dict(Path=Path,ET=ET,struct=struct,np=np,params=params);source=Path('/workspace/divalead-work/pc-stereo-20261024/continue_stereo_ZL_matching.py').read_text();tree=ast.parse(source)
for name in ['specs_from_component','configure']:
 node=next(v for v in tree.body if isinstance(v,ast.FunctionDef)and v.name==name);exec(compile(ast.get_source_segment(source,node),'<main-'+name+'>','exec'),ns)
primary_specs,dynamic=ns['specs_from_component'](R/'PRIMARY.bin');ns.update(specs=primary_specs,dynamic=dynamic);configure_primary=ns['configure'];assert len(primary_specs)==94
blob=(R/'POST.bin').read_bytes();xml=ET.fromstring(blob[8:8+struct.unpack_from('<I',blob,4)[0]]);values={p.attrib['id']:float(p.attrib['value'])for p in xml.find('Para')};post_specs=[]
for band in[0,1,2,3,5,6]:
 assert values['filter_type'+str(band)]==9 and values['filter_status'+str(band)]==2
 for title,key,step,lo,hi in[('Freq','freq',.06,20,18000),('Q','q',.09,.15,25)]:post_specs.append(dict(title='Post '+title+str(band),parameter_title=title+str(band),value=values[key+str(band)],step=step,lo=lo,hi=hi,log=True))
assert values['filter_type4']==0 and values['lr_mode4']==1 and values['filter_status4']==2
for title,key,step,lo,hi,log in[('Freq','freq',.06,200,5000,True),('Q','q',.09,.15,25,True),('Gain','gain',.15,-6,3,False)]:post_specs.append(dict(title='Post '+title+'4',parameter_title=title+'4',value=values[key+'4'],step=step,lo=lo,hi=hi,log=log))
specs=[dict(s,title='Primary '+s['title'])for s in primary_specs]+post_specs;initial=np.array([v['value']for v in specs]);steps=np.array([v['step']for v in specs]);air_cap=low_cap=None
assert len(specs)==109
def configure_pair(p,z,x):
 p.load(R/'PRIMARY.bin');configure_primary(p,x[:94]);z.load(R/'POST.bin')
 for spec,value in zip(post_specs,x[94:]):
  if float(value)!=spec['value']:z.text(params[spec['parameter_title']],format(value,'.12g'))

def powers(*args,**kw):
 v=oldpowers(*args,**kw);cache.power=v[0];return v
q.a.powers=powers
from fl20_objective import TONE,SCALES
weights=q.HARMONIC_WEIGHTS
for module,name,key in[(q.a,'erbpower','erb'),(q.a.wave,'features','shape'),(q.a.h,'harmonic_errors','harmonic')]:
 def wrapped(*args,_module=module,_name=name,_key=key,_old=getattr(module,name),**kw):
  value=_old(*args,**kw);setattr(cache,_key,value);return value
 setattr(module,name,wrapped)
def rawgroups(metrics):
 error=10*np.log10(np.maximum(cache.power,1e-15)/np.maximum(q.a.TP,1e-15));erb=10*np.log10(np.maximum(cache.erb,1e-12)/np.maximum(q.a.TE,1e-12));phase=cache.shape[0];targets=[q.a.TS,q.a.TS*np.exp(1j*np.pi*(1-q.a.wave.ORDERS))[None]];chosen=min(targets,key=lambda target:np.sum(abs(phase-target)**2*q.a.TW));d=(phase-chosen)*np.sqrt(q.a.TW)
 groups=dict(H24=(np.array(cache.harmonic['harmonic_errors_db'])*np.sqrt(weights)).ravel(),upper_harm=error[:,4:,:2].ravel()/np.sqrt(error[:,4:,:2].size),upper_off=error[:,4:,2:].ravel()/np.sqrt(error[:,4:,2:].size),low_harm=error[:,:4,:2].ravel()/np.sqrt(error[:,:4,:2].size),ERB=(erb*np.sqrt(q.a.EW)).ravel(),relative_phase=np.r_[d.real.ravel(),d.imag.ravel()])
 for key,v in groups.items():assert abs(float(np.linalg.norm(v))-metrics[key])<1e-6,(key,np.linalg.norm(v),metrics[key])
 return groups

def assess(y):
 d=q.assess(y);e=10*np.log10(np.maximum(cache.power,1e-15)/np.maximum(q.a.TP,1e-15));d['positive_excess_air_dB']=float(np.maximum(e[:,4:6,2:],0).mean());v=np.array(d['LR_dB']);d['original_stereo_preservation_passed']=bool(np.sqrt(np.mean((v[1:]-q.reference_LR[1:])**2))<=1.48 and max(abs(v[1:]))<=1.6 and abs(v[0]-q.reference_LR[0])<=3.25)
 parts=[];m=d['assessment']['metrics'];detailed=rawgroups(m)
 for key in sorted(set(TONE)|set(q.a.WEIGHTS)):
  contribution=(.65*TONE.get(key,0)+.35*q.a.WEIGHTS.get(key,0))*m[key]/SCALES[key];assert contribution>=0
  if key in detailed:
   shape=np.array(detailed[key],copy=True);norm=float(np.linalg.norm(shape));assert norm>0;parts.append(shape/norm*np.sqrt(contribution))
  else:parts.append(np.array([np.sqrt(contribution)]))
 gain=d['assessment']['diagnostics']['global_RMS_gain_for_AB'];parts.append(np.array([np.sqrt(.05*abs(np.log(gain))),np.sqrt(20)*max(0,d['assessment']['peak']-.95)]));cache.residual=np.concatenate(parts);np.testing.assert_allclose(cache.residual@cache.residual,d['loss']-q.reg,rtol=1e-12,atol=1e-12)
 return d

def record(phase,**kw):
 d=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),actual_ZL_hosts=[c.child.pid for p,z,t in clients for c in[p,z]],actual_nativeTrim_hosts=[t.chain.proc.pid for p,z,t in clients],source_Diva281_threeheld_MIDI_ARP_ADSR_native12_trim_unchanged=True,existing_PRIMARY94_POST15_both_changed=True,all_residual_weights_alignment_and_final_quality_thresholds_unchanged=True,real_DSP_finite_difference_Jacobian_no_surrogate_audio=True,not_adopted=True,reference_match_reached=False,**kw);tmp=STATE.with_suffix('.partial');tmp.write_text(json.dumps(d,indent=2)+'\n');tmp.replace(STATE)
def project(t):
 return np.array([float(np.clip(v*2**(s['step']*d)if s['log']else v+s['step']*d,s['lo'],s['hi']))for v,s,d in zip(initial,specs,t)])
def effective(j,v):return float(np.log2(v/initial[j])/steps[j])if specs[j]['log']else float((v-initial[j])/steps[j])
def evaluate(case,indices=(0,1,2),keep=True):
 label,x=case;p,z,trim=pool.get()
 try:
  ds=[];rs=[]
  for k in indices:
   configure_pair(p,z,x);mid,_=p.render(native_inputs[k]);pre,_=z.render(mid);y=trim.render(pre);assert p.latency()+z.latency()==0;ds.append(assess(y));rs.append(cache.residual.copy())
  row=dict(label=label,x=list(map(float,x)),loss=float(np.mean([d['loss']for d in ds])),positive_excess_air_dB=float(np.mean([d['positive_excess_air_dB']for d in ds])),lowmid_error=float(np.mean([d['lowmid_error']for d in ds])),captures=ds,original_stereo_preservation_passed=all(d['original_stereo_preservation_passed']for d in ds));row['feasible']=bool(row['original_stereo_preservation_passed']and(air_cap is None or row['positive_excess_air_dB']<=air_cap)and(low_cap is None or row['lowmid_error']<=low_cap))
  if keep:
   with lock:rows.append(row)
  return row,np.concatenate(rs)/np.sqrt(len(rs))
 finally:pool.put((p,z,trim))
def cascade(raw,component,p,z,t,post_component=None):
 p.load(component);z.load(post_component or R/'POST.bin');mid,_=p.render(raw);pre,_=z.render(mid);return t.render(pre)
def add(tar,name,y):
 b=io.BytesIO();sf.write(b,y,48000,format='WAV',subtype='FLOAT');data=b.getvalue();info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data));members.append(dict(name=name,bytes=len(data),SHA256=hashlib.sha256(data).hexdigest()))
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(parameter_count=len(specs),parameters=specs,three_COMMON_actual_native_training_inputs_two_unseen=True,finite_difference_scaled_steps_plusminus05=True,both_hosts_baseline_loaded_every_case_and_neutral_identity_required=True,detailed_ALL_SIX_TONE_feature_groups_plus_other_metric_residual_exactly_matches_original_loss=True,physical_bounds_and_log_parameterization_preserved=True,LM_solver_regularizations=[.001,.01,.1,1.],trust_radius_infinity4=True,line_search_scales=[.125,.25,.5,1.],trainingAir_current_plus0=True,training_lowmid_current_mean_plus0005=True,strict_first6AND10_gain_over_max0005_3SEM_bothcold_positive=True,all_original_stereo148_abs16_lowmid325_unchanged=True,EXTRA_first10_and_bothcold_Air_nonincreasing=True,unconstrained_AND_constrained_LM_proposals_real_rendered=True,latest_context_full_export_required=True),indent=2)+'\n')
try:
 for k in range(2):
  tag='Joint109DetailedJac-'+str(os.getpid())+'-'+str(k);p=q.WinVST3(tag+'-primary');p.load(R/'PRIMARY.bin');z=q.WinVST3(tag+'-post');z.load(R/'POST.bin');t=NativePostTrim(R/'buffers',tag+'-trim',cleanup_on_close=True);t.load(q.prior['post_native_trim_state']);clients.append((p,z,t));pool.put((p,z,t))
 n=q.native(q.source['native_input'],'Joint109DetailedJac-'+str(os.getpid())+'-native');record('five_actual_common_native_inputs')
 for k in range(5):
  raw,_=n.render();native_inputs.append(raw);sf.write(R/f'TRAINING_NATIVE_{k}.wav',raw,48000,subtype='FLOAT');p,z,t=clients[0];y=cascade(raw,R/'PRIMARY.bin',p,z,t);controls.append(assess(y));sf.write(R/f'TRAINING_CONTROL_{k}.wav',y,48000,subtype='FLOAT')
 n.close();n=None;neutral=[]
 for i,(host,post,nt)in enumerate(clients):
  direct=cascade(native_inputs[0],R/'PRIMARY.bin',host,post,nt);configure_pair(host,post,initial);mid,_=host.render(native_inputs[0]);pre,_=post.render(mid);got=nt.render(pre);np.testing.assert_allclose(got,direct,rtol=8*np.finfo(np.float32).eps,atol=1e-12);neutral.append(dict(worker=i,neutral_configured_vs_direct_load_max_error=float(abs(got-direct).max()),baseline_loaded_into_both_hosts=True))
 (R/'BOTH_HOST_BASELINE_NEUTRAL_IDENTITY.json').write_text(json.dumps(neutral,indent=2)+'\n');(R/'CONTROL_ASSESSMENTS.json').write_text(json.dumps(controls,indent=2)+'\n');air_cap=float(np.mean([d['positive_excess_air_dB']for d in controls[:3]]));low_cap=min(3.25,float(np.mean([d['lowmid_error']for d in controls[:3]]))+.005);baseline,r0=evaluate(('actual-baseline',initial));columns=[];denominators=[];air_columns=[];low_columns=[]
 with concurrent.futures.ThreadPoolExecutor(2)as ex:
  for j,s in enumerate(specs):
   tp=np.zeros(len(specs));tm=tp.copy();tp[j]=.5;tm[j]=-.5;xp,xm=project(tp),project(tm);rp,rm=list(ex.map(evaluate,[(s['title']+'-plus',xp),(s['title']+'-minus',xm)]));den=effective(j,xp[j])-effective(j,xm[j]);assert den>0;columns.append((rp[1]-rm[1])/den);denominators.append(den);air_columns.append((rp[0]['positive_excess_air_dB']-rm[0]['positive_excess_air_dB'])/den);low_columns.append((rp[0]['lowmid_error']-rm[0]['lowmid_error'])/den);record('actual_real_plugin_Jacobian_column',completed_columns=j+1,total_columns=len(specs),actual_training_DSP_renders=3*len(rows))
  J=np.column_stack(columns);assert J.shape[0]==len(r0)and np.isfinite(J).all();np.savez_compressed(R/'ACTUAL_SCALED_JACOBIAN.npz',J=J,residual=r0,initial=initial,steps=steps,denominators=np.array(denominators));jtj=J.T@J;g=J.T@r0;scale=max(float(np.max(np.diag(jtj))),1e-10);cases=[];directions=[]
  for damping in[.001,.01,.1,1.]:
   delta=np.linalg.solve(jtj+damping*scale*np.eye(len(specs)),-g);delta*=min(1.,4/max(abs(delta).max(),1e-12));directions.append(dict(damping=damping,delta=delta.tolist()))
   for alpha in[.125,.25,.5,1.]:cases.append((f'LM-{damping}-scale-{alpha}',project(delta*alpha)))
  Aineq=np.array([air_columns,low_columns]);bineq=np.array([-.003,.005]);constrained=[]
  for damping in[.001,.01,.1,1.]:
   matrix=jtj+damping*scale*np.eye(len(specs));sol=minimize(lambda d:float(d@matrix@d+2*g@d),np.zeros(len(specs)),jac=lambda d:2*(matrix@d+g),method='SLSQP',bounds=[(-4,4)]*len(specs),constraints=[dict(type='ineq',fun=lambda d:bineq-Aineq@d,jac=lambda d:-Aineq)],options=dict(maxiter=500,ftol=1e-13))
   constrained.append(dict(damping=damping,success=bool(sol.success),message=sol.message,delta=sol.x.tolist(),predicted_Air_and_lowmid_delta=(Aineq@sol.x).tolist()))
   if sol.success:
    for alpha in[.125,.25,.5,1.]:cases.append((f'constrained-LM-{damping}-scale-{alpha}',project(sol.x*alpha)))
  (R/'CONSTRAINED_LM_PROPOSALS.json').write_text(json.dumps(constrained,indent=2)+'\n')
  candidates=list(ex.map(evaluate,cases));valid=[row for row,r in candidates if row['feasible']];selected=min([baseline,*valid],key=lambda d:d['loss']);(R/'LM_DIRECTIONS.json').write_text(json.dumps(directions,indent=2)+'\n');held=[evaluate(('unseen-'+str(k),selected['x']),(k,),False)[0]for k in[3,4]]
 gain=float(np.mean([controls[k]['loss']-d['loss']for k,d in zip([3,4],held)]));ok=all(d['original_stereo_preservation_passed']and d['lowmid_error']<=controls[k]['lowmid_error']+.02 and d['positive_excess_air_dB']<=controls[k]['positive_excess_air_dB']+.02 for k,d in zip([3,4],held));p,z,t=clients[0];configure_pair(p,z,selected['x']);component=R/'CANDIDATE_PRIMARY.bin';post_component=R/'CANDIDATE_POST.bin';p.save(component);z.save(post_component);p.load(component);z.load(post_component);p.save(R/'PRIMARY_RESAVED.bin');z.save(R/'POST_RESAVED.bin');assert component.read_bytes()==(R/'PRIMARY_RESAVED.bin').read_bytes();assert post_component.read_bytes()==(R/'POST_RESAVED.bin').read_bytes();y=cascade(native_inputs[0],component,p,z,t,post_component);sf.write(R/'SELECTED_FULL_TRAINING_WIP.wav',y,48000,subtype='FLOAT');(R/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0));summary=dict(training_cases=len(rows),actual_training_DSP_renders=3*len(rows),Jacobian_shape=list(J.shape),baseline=baseline,selected=selected,heldout=held,heldout_mean_gain=gain,heldout_constraints_passed=ok,component=str(component),sufficient_screen=bool(gain>.0003 and ok),robust_improvement=False,not_adopted=True,reference_match_reached=False);(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
 if summary['sufficient_screen']:
  n=q.native(q.source['native_input'],'Joint109DetailedJac-'+str(os.getpid())+'-validation')
  archive=Path('/tmp/divalead-joint109-detailed-Jacobian-validation-'+str(os.getpid())+'.tar.gz');(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz').symlink_to(archive)
  with tarfile.open(archive,'w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in[10,11]:n.close();n=q.native(q.source['native_input'],'Joint109DetailedJac-'+str(os.getpid())+'-cold-'+str(rep))
    raw,_=n.render();a=cascade(raw,R/'PRIMARY.bin',p,z,t);da=assess(a);b=cascade(raw,component,p,z,t,post_component);db=assess(b);captures.append(dict(rep=rep,control=da,candidate=db,improvement=da['loss']-db['loss'],air_increase=db['positive_excess_air_dB']-da['positive_excess_air_dB']))
    for name,y in [('native',raw),('control',a),('candidate',b)]:add(tar,f'{name}-{rep}.wav',y)
    if rep==0:
     for name,y in [('NATIVE_INPUT',raw),('CONTROL',a),('CANDIDATE',b)]:sf.write(R/(name+'_00.wav'),y,48000,subtype='FLOAT')
    record('joint_actual_first6AND10_cold2_validation',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  d=np.array([v['improvement']for v in captures]);air=np.array([v['air_increase']for v in captures]);s6=float(d[:6].std(ddof=1)/np.sqrt(6));s10=float(d[:10].std(ddof=1)/np.sqrt(10));guard=all(v['candidate']['original_stereo_preservation_passed']and v['candidate']['lowmid_error']<=v['control']['lowmid_error']+.02 for v in captures);robust=bool(d[:6].mean()>max(.0005,3*s6)and d[:10].mean()>max(.0005,3*s10)and min(d[10:])>0 and air[:10].mean()<=0 and max(air[10:])<=0 and guard);summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(d[:6].mean()),first6_SEM=s6,first10_mean_improvement=float(d[:10].mean()),first10_SEM=s10,cold2_improvements=d[10:].tolist(),first10_air_increase=float(air[:10].mean()),cold2_air_increase=air[10:].tolist(),robust_improvement=robust)
  with tarfile.open(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
 (R/'COMBINED_CANDIDATE_RESEARCH_ONLY.json').write_text(json.dumps(dict(q.prior,native_ZL_component_state=str(component),post_ZL_component_state=str(post_component),not_adopted_until_supported_full_export=True,requires_latest_BEST_revalidation=True),indent=2)+'\n');(R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_real_Jacobian_primary_complete_not_adopted',sufficient_screen=summary['sufficient_screen'],robust_improvement=summary['robust_improvement']);print(json.dumps({k:v for k,v in summary.items()if k not in ['baseline','selected','heldout','captures','archive_members']}),flush=True)
except BaseException:record('failed_preserve_current_accepted_state',error=traceback.format_exc());raise
finally:
 if n is not None:n.close()
 for p,z,t in clients:p.close();z.close();t.close()
