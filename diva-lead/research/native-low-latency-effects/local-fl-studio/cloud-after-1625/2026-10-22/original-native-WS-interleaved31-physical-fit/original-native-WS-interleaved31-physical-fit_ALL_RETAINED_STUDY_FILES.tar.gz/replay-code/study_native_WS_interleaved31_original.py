"""Actual stock WaveShaper half-step controls; original reference is analysis only."""
from pathlib import Path
import concurrent.futures,datetime,gzip,hashlib,json,os,struct,traceback
import numpy as np,soundfile as sf
from scipy.optimize import lsq_linear
from scipy.stats import qmc
import native_WS_interleaved31_original_support as q
R=q.R;rows=q.rows;origin=q.origin;step=q.step;count=len(origin);clients=q.clients
def addtrim(p,tag):
 c=q.NativePostTrim(R/'post-trim-host-inputs',tag,cleanup_on_close=True);c.load(q.prior['post_native_trim_state']);q.trims[p.child.pid]=c
def savewave(name,y):sf.write(R/(name+'.wav'),y,48000,subtype='FLOAT')
try:
 protocol=dict(original_is_the_only_target=True,three_held_notes_ARP_ADSR_Diva_all_other_native_states_PRIMARY_POST_posttrim_unchanged=True,new_basis='31 narrow half-step bumps between existing 32 fine controls, .03:.02:.63 width .0065',same_stock129_point_monotone_WaveShaper_format=True,parameter_step=step.tolist(),training_air_cap_control_plus_dB=.01,training_lowmid_cap_control_plus_dB=.01,first6_AND_first10_improvement_over_max_0005_or_3SEM=True,both_cold_gains_positive=True,all_original_stereo_guards_upper148_abs16_lowmid325=True,first10_and_both_cold_air_increase_cap_dB=.02,zero_extra_ZL_PDC=True,no_adoption_without_latest_context_and_supported_export=True)
 (R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
 for k in range(2):
  c=q.native('OriginalWSHalf31-native-'+str(k));p=q.WinVST3('OriginalWSHalf31-primary-'+str(k));z=q.WinVST3('OriginalWSHalf31-post-'+str(k));addtrim(p,'OriginalWSHalf31-trim-'+str(k));clients.append((c,p,z));q.pool.put((c,p,z))
 q.record('actual_stock_WS_half_step_baseline12')
 baseline=q.evaluate(('unchanged-canonical-control',origin),12);q.training_air_cap=baseline['positive_excess_air_dB']+.01;q.training_lowmid_cap=min(3.25,baseline['lowmid_error']+.01);m=baseline['assessment']['assessment']['metrics'];q.factors={key:float(np.sqrt((.65*q.TONE[key]+.35*q.a.WEIGHTS.get(key,0))/(q.SCALES[key]*max(m[key],1e-6))))for key in q.TONE};cases=[];endpoints={}
 for j in range(count):
  endpoints[j]={}
  for sign in [-1,1]:
   strength=1.
   while strength>=1/64:
    v=origin.copy();v[j]+=sign*step[j]*strength
    if q.curve(v)is not None:break
    strength*=.5
   if strength<1/64:endpoints[j][sign]=(0.,None);continue
   label=f'derivative-{j}-{sign}';endpoints[j][sign]=(strength,label);cases.append((label,v))
 with concurrent.futures.ThreadPoolExecutor(2)as ex:
  for k,row in enumerate(ex.map(q.evaluate,cases)):
   if k%6==0:q.record('actual_WS_half_step_physical_derivative_renders',control_mean=baseline['loss'],best_mean=min(r['loss']for r in rows if r['stereo_preservation_passed']))
  bylabel={r['label']:r for r in rows};f0=q.vector(baseline);columns=[]
  for j in range(count):
   ap,lp=endpoints[j][1];am,lm=endpoints[j][-1];plus=q.vector(bylabel[lp])if lp else f0;minus=q.vector(bylabel[lm])if lm else f0;columns.append((plus-minus)/max(ap+am,1e-12))
  J=np.column_stack(columns);direction=lsq_linear(np.r_[J,np.eye(count)*.025],np.r_[-f0,np.zeros(count)],bounds=(-1.5,1.5),tol=1e-9).x;top=np.argsort(np.linalg.norm(J,axis=0))[-12:];sparse=np.zeros(count);sparse[top]=lsq_linear(np.r_[J[:,top],np.eye(12)*.025],np.r_[-f0,np.zeros(12)],bounds=(-1.5,1.5),tol=1e-9).x
  (R/'ACTUAL_DERIVATIVE_PROPOSALS.json').write_text(json.dumps(dict(direction=direction.tolist(),strong12_direction=sparse.tolist(),step=step.tolist(),original_complete_criterion_unchanged=True),indent=2)+'\n');proposals=[]
  for mode,d in [('all31',direction),('strong12',sparse)]:
   for scale in [.125,.25,.5,.75,1.]:
    v=origin+step*d*scale
    if q.curve(v)is not None:proposals.append((f'joint-{mode}-{scale}',v))
  for k,unit in enumerate(qmc.LatinHypercube(count,seed=2026102701).random(48)):
   v=origin+(unit*2-1)*step*[.25,.5,1,2][k%4]
   if q.curve(v)is not None:proposals.append((f'coupled-LHS-{k}',v))
  for k,row in enumerate(ex.map(q.evaluate,proposals)):
   if k%6==0:q.record('actual_WS_half_step_joint_candidate_renders',control_mean=baseline['loss'],best_mean=min(r['loss']for r in rows if r['stereo_preservation_passed']))
 (R/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0));eligible=sorted([r for r in rows if r['stereo_preservation_passed']],key=lambda r:r['loss'])[:4];finalists=[q.evaluate(('fresh-finalist-'+str(k),r['curve_vector']),12,False)for k,r in enumerate(eligible)];winner=min(finalists,key=lambda r:r['loss']);ready=bool(winner['curve_vector']!=origin.tolist()and baseline['loss']-winner['loss']>.0003 and winner['stereo_preservation_passed']);summary=dict(training_cases=len(rows),baseline=baseline,winner=winner,finalists=finalists,sufficient_screen=ready,robust_improvement=False,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False,requires_latest_main_context_revalidation=True)
 (R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n');c0,p0,z0=clients[0];c1,p1,z1=clients[1];q.configure(c1,winner['curve_vector']);raw,_=c1.render();savewave('SELECTED_NATIVE_TRAINING',raw);savewave('SELECTED_FULL_TRAINING_WIP',q.cascade(raw,p1,z1))
 if ready:
  q.configure(c0,origin);captures=[];members=[]
  with q.tarfile.open(R/'TWELVE_FRESH_NATIVE_PROCESSED_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in [10,11]:
     c0.close();c1.close();c0=q.native('OriginalWSHalf31-cold-control-'+str(rep));c1=q.native('OriginalWSHalf31-cold-candidate-'+str(rep));q.configure(c0,origin);q.configure(c1,winner['curve_vector']);clients[0]=(c0,p0,z0);clients[1]=(c1,p1,z1)
    raw0,_=c0.render();old=q.cascade(raw0,p0,z0);d0,_=q.assess(old);raw1,_=c1.render();out=q.cascade(raw1,p1,z1);d1,_=q.assess(out);captures.append(dict(rep=rep,control=d0,candidate=d1,improvement=d0['loss']-d1['loss'],air_increase=d1['positive_excess_air_dB']-d0['positive_excess_air_dB']))
    for name,y in [('native-control',raw0),('native-candidate',raw1),('control',old),('candidate',out)]:q.add(tar,f'{name}-{rep}.wav',y,members)
    if rep==0:
     for name,y in [('NATIVE_CONTROL',raw0),('NATIVE_CANDIDATE',raw1),('CONTROL',old),('CANDIDATE',out)]:savewave(name+'_00',y)
    q.record('half_step_WS_first6_AND_first10_cold2_original_confirmation',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  delta=np.array([r['improvement']for r in captures]);air=np.array([r['air_increase']for r in captures]);s6=float(np.std(delta[:6],ddof=1)/np.sqrt(6));s10=float(np.std(delta[:10],ddof=1)/np.sqrt(10));robust=bool(np.mean(delta[:6])>max(.0005,3*s6)and np.mean(delta[:10])>max(.0005,3*s10)and min(delta[10:])>0 and np.mean(air[:10])<=.02 and max(air[10:])<=.02 and all(r['candidate']['original_stereo_preservation_passed']and r['candidate']['lowmid_error']<=r['control']['lowmid_error']+.02 for r in captures));summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(np.mean(delta[:6])),first6_SEM=s6,first10_mean_improvement=float(np.mean(delta[:10])),first10_SEM=s10,cold2_improvements=delta[10:].tolist(),first10_air_increase=float(np.mean(air[:10])),cold2_air_increase=air[10:].tolist(),robust_improvement=robust)
  # Preserve exact native states and test actual replay without inventing a
  # compatible fingerprint for this new research parameterization.
  bundle=q.bundle;newdir=R/'saved-native-bundle';manifest=[]
  for row in bundle['manifest']:
   path=newdir/row['state'];path.parent.mkdir(parents=True,exist_ok=True);c1.save_state(row['node'],path)
   if row['node']!=0:assert path.read_bytes()==(q.bundledir/row['state']).read_bytes(),('unrelated native state changed',row['node'])
   manifest.append(dict(row,state_bytes=path.stat().st_size,state_SHA256=hashlib.sha256(path.read_bytes()).hexdigest()))
  expected_WS=next(newdir/r['state']for r in manifest if r['node']==0);c1.set(3,1,0);expected,_=c1.render();fresh=q.native('OriginalWSHalf31-independent-exact-state-replay')
  try:
   fresh.load_state(0,expected_WS);fresh.set(3,1,0);again,_=fresh.render();error=float(abs(again-expected).max());assert error<=2e-7,error
   for row in manifest:
    if row['node']==3:continue
    path=R/('COLD_STATE_NODE_'+str(row['node'])+'.bin');fresh.save_state(row['node'],path);assert path.read_bytes()==(newdir/row['state']).read_bytes()
  finally:fresh.close()
  with q.tarfile.open(R/'TWELVE_FRESH_NATIVE_PROCESSED_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
  summary.update(other11_native_states_byte_exact=True,independent_native_zero_depth_state_replay_max_abs_error=error)
  (R/'RESEARCH_CANDIDATE_REQUIRES_SUPPORTED_METADATA_MIGRATION.json').write_text(json.dumps(dict(prior=q.prior,curve_vector=winner['curve_vector'],basis_centers=q.centers.tolist(),basis_width=q.width,native_state_manifest=manifest,exact_WS_state=str(expected_WS),not_compatible_with_standard_x95_exporter=True,not_adopted=True,requires_supported_format_fingerprint_and_latest_context_fullkit_replay=True),indent=2)+'\n')
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');q.record('finite_half_step_WS31_study_complete_not_adopted',sufficient_screen=ready,robust_improvement=summary['robust_improvement']);print(json.dumps({k:v for k,v in summary.items()if k not in ['baseline','winner','finalists','captures','archive_members']}),flush=True)
except BaseException:q.record('failed_preserve_current_confirmed_full33_and_numeric_best',error=traceback.format_exc());raise
finally:
 for c,p,z in clients:c.close();p.close();z.close()
 for c in q.trims.values():c.close()
