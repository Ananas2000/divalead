"""Jointly refit all52 supported stock WaveShaper curve controls to original.

Every derivative/candidate is real nativeDLL+two officialZL DSP. Linear feature
fits propose presets only. The unchanged complete original criterion, stereo
guards, fresh6/cold2 and exact saved-state replay gate any adoption.
"""
from pathlib import Path
import concurrent.futures,datetime,gzip,hashlib,io,json,os,queue,struct,tarfile,threading,traceback
import numpy as np,soundfile as sf
from scipy.optimize import lsq_linear
from scipy.stats import qmc
from native_chain import NativeChain
from fl20_curve import apply_candidate,extended_curve_bytes,native_dsp_settings_SHA256,HIGH_FORMAT
from win_vst3 import WinVST3
from native_post_trim import NativePostTrim
trims={}
H=Path(__file__).resolve().parent;A=Path('/workspace/divalead-work/pc-stereo-20261024');N=Path('/workspace/divalead-work/native-low-latency-effects');R=Path('/workspace/divalead-work/stereo-refinement-20261026/WS_INTERLEAVED31_ORIGINAL');R.mkdir(exist_ok=False);STATE=N/'ORIGINAL_NATIVE_WS_INTERLEAVED31_ORIGINAL_STUDY.json'
prior=json.loads((A/'stereo-continuous87/BEST_CANDIDATE.json').read_text());seed=prior['native_base'];base=np.array(seed['x']);bundle=seed['native_saved_state_bundle'];bundledir=Path(bundle['directory']);wsrow=next(row for row in bundle['manifest']if row['node']==0);canonical=(bundledir/wsrow['state']).read_bytes();assert struct.unpack_from('<I',canonical,30)[0]==129
origin=np.zeros(31);assert prior['accepted_full_public_kit']=='ZL33'and prior['native_base_export_directory'].endswith('_10')
step=np.full(31,.0008);training_air_cap=None;training_lowmid_cap=None
for name,key in [('PRIMARY.bin','native_ZL_component_state'),('POST.bin','post_ZL_component_state')]:(R/name).write_bytes(Path(prior[key]).read_bytes())
(R/'PRIOR_COMBINED_CANDIDATE.json').write_text(json.dumps(prior,indent=2)+'\n');os.environ['DIVALEAD_NATIVE_OBJECTIVE_ROOT']=str(R/'assessment')
from fl20_objective import FeaturesOriginal,a,SCALES,TONE
features=FeaturesOriginal();reg=float(np.sum(base[:28]**2))*.00000025;ref,sr=sf.read('/workspace/divalead/diva-lead/v83-wip/Diva_original_lead_reference.wav',always_2d=True);np.testing.assert_array_equal(ref,a.REF);freq=np.fft.rfftfreq(len(ref),1/48000);masks=[(freq>=lo)&(freq<hi)for lo,hi in [(300,800),(2000,5000),(5000,10000),(10000,14000)]]
cache=threading.local()
def capture(module,name,key):
 old=getattr(module,name)
 def wrapped(*args,**kwargs):
  result=old(*args,**kwargs);setattr(cache,key,result);return result
 setattr(module,name,wrapped)
capture(a,'powers','power');capture(a,'erbpower','erb');capture(a.wave,'features','shape');capture(a.h,'harmonic_errors','harmonic')
weights=np.maximum(a.h.HT,1e-5)**.5;weights[:,0]=0;weights/=weights.sum();factors=None
def rawgroups(metrics):
 error=10*np.log10(np.maximum(cache.power[0],1e-15)/np.maximum(a.TP,1e-15));erb=10*np.log10(np.maximum(cache.erb,1e-12)/np.maximum(a.TE,1e-12));phase=cache.shape[0];targets=[a.TS,a.TS*np.exp(1j*np.pi*(1-a.wave.ORDERS))[None]];chosen=min(targets,key=lambda target:np.sum(abs(phase-target)**2*a.TW));d=(phase-chosen)*np.sqrt(a.TW)
 groups=dict(H24=(np.array(cache.harmonic['harmonic_errors_db'])*np.sqrt(weights)).ravel(),upper_harm=error[:,4:,:2].ravel()/np.sqrt(error[:,4:,:2].size),upper_off=error[:,4:,2:].ravel()/np.sqrt(error[:,4:,2:].size),low_harm=error[:,:4,:2].ravel()/np.sqrt(error[:,:4,:2].size),ERB=(erb*np.sqrt(a.EW)).ravel(),relative_phase=np.r_[d.real.ravel(),d.imag.ravel()])
 for key,v in groups.items():assert abs(float(np.linalg.norm(v))-metrics[key])<1e-6,(key,np.linalg.norm(v),metrics[key])
 return groups
def lr(y):
 p=abs(np.fft.rfft(y,axis=0))**2;return np.array([10*np.log10(p[m,0].sum()/p[m,1].sum())for m in masks])
target=lr(ref)
def assess(y):
 residual=features.residual(y[:288000]);last=features.local.last;groups=rawgroups(last['metrics']);edit=a.h.edit_aligned(a.h.align_with_pdc(y,dict(alignment_frames=819),latency=0));v=lr(edit);air=float(np.maximum(10*np.log10(np.maximum(cache.power[0],1e-15)/np.maximum(a.TP,1e-15))[:,4:6,2:],0).mean());low=abs(float(v[0]-target[0]));original=bool(np.sqrt(np.mean((v[1:]-target[1:])**2))<=1.48 and max(abs(v[1:]))<=1.6 and low<=3.25)
 return dict(loss=float(residual@residual)+reg,assessment=last,LR_dB=v.tolist(),lowmid_error=low,positive_excess_air_dB=air,original_stereo_preservation_passed=original,stereo_preservation_passed=bool(original and(training_lowmid_cap is None or low<=training_lowmid_cap))),groups

Y0=np.array([struct.unpack_from('<d',canonical,34+24*k+8)[0]for k in range(129)]);assert min(np.diff(Y0))>=-1e-10
u=np.linspace(0,1,129);centers=np.linspace(.03,.63,31);width=.0065
basis=(u[:,None]*(1-u[:,None])/(centers*(1-centers)))**2*np.exp(-.5*((u[:,None]-centers)/width)**2);basis/=basis.max(axis=0)
def curve(v):
 y=Y0+basis@np.array(v)
 if min(y)<-1e-12 or max(y)>1+1e-12 or min(np.diff(y))<-1e-10:return None
 if np.array_equal(v,origin):return canonical
 b=bytearray(canonical)
 for k,value in enumerate(np.clip(y,0,1)):struct.pack_into('<d',b,34+24*k+8,float(value))
 return bytes(b)

def native(tag):
 c=NativeChain(seed['source_manifest']['native_input'],tag,fl_graph=True,phase_pair=True,engine_override='fl_native_fl20_host.exe');apply_candidate(c,base,seed)
 for key,value in seed['chorus_overrides'].items():c.set(3,int(key),int(value))
 return c
def configure(c,v):
 b=curve(v);assert b is not None;p=c.output.parent/(c.output.stem+'-WS48-current.bin');p.write_bytes(b);c.load_state(0,p)
def cascade(raw,p,z):
 p.load(R/'PRIMARY.bin');z.load(R/'POST.bin');mid,_=p.render(raw);out,_=z.render(mid);assert p.latency()+z.latency()==0;return trims[p.child.pid].render(out)
clients=[];pool=queue.Queue();mutex=threading.Lock();rows=[]
def record(phase,**kw):
 s=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),cases=len(rows),actual_native_hosts=[c.proc.pid for c,p,z in clients],actual_ZL_hosts=[c.child.pid for p,z in [(p,z)for c,p,z in clients]for c in [p,z]],original_is_the_only_target=True,v83_Finish_not_used=True,only_native_WaveShaper_interleaved31_curve_controls_varied=True,actual_native_post_trim_hosts=[c.chain.proc.pid for c in trims.values()],other11_native_source_MIDI_ARP_ADSR_routing_and_both_ZL_unchanged=True,not_adopted=True,reference_match_reached=False,**kw);p=STATE.with_suffix('.partial');p.write_text(json.dumps(s,indent=2)+'\n');p.replace(STATE)
def evaluate(case,reps=4,keep=True):
 label,v=case;v=np.array(v);c,p,z=pool.get()
 try:
  configure(c,v);captures=[];grouped=[]
  for rep in range(reps):raw,_=c.render();out=cascade(raw,p,z);d,g=assess(out);captures.append(d);grouped.append(g)
  groups={key:np.mean([g[key]for g in grouped],axis=0).tolist()for key in TONE};row=dict(label=label,curve_vector=v.tolist(),loss=float(np.mean([r['loss']for r in captures])),positive_excess_air_dB=float(np.mean([r['positive_excess_air_dB']for r in captures])),lowmid_error=float(np.mean([r['lowmid_error']for r in captures])),realization_losses=[r['loss']for r in captures],stereo_preservation_passed=bool(all(r['stereo_preservation_passed']for r in captures)and(training_air_cap is None or np.mean([r['positive_excess_air_dB']for r in captures])<=training_air_cap)),physical_feature_groups=groups,assessment=captures[len(captures)//2])
  if keep:
   with mutex:rows.append(row)
  return row
 finally:pool.put((c,p,z))
def vector(row):return np.concatenate([np.array(row['physical_feature_groups'][key])*factors[key]for key in TONE])
def add(tar,name,y,members):
 stream=io.BytesIO();sf.write(stream,y,48000,format='WAV',subtype='FLOAT');b=stream.getvalue();info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b));members.append(dict(name=name,SHA256=hashlib.sha256(b).hexdigest()))
