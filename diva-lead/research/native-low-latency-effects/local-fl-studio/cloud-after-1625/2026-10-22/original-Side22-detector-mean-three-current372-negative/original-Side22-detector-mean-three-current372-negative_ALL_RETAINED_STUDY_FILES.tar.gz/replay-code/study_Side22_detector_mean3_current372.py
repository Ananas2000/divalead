"""Actual Side22 detector parameters, omitted from older14..21 detector study."""
from pathlib import Path
import concurrent.futures,csv,datetime,gzip,hashlib,io,json,os,struct,tarfile,threading,traceback,xml.etree.ElementTree as ET
import numpy as np,soundfile as sf
import Side22_detector_mean3_current372_support as q
from mean_three_real_primary_fit import MeanThreePrimaryFit
from native_post_trim import NativePostTrim
R=q.ROOT;STATE=q.STATE;p=z=trim=n=fit=None;captures=[];members=[];cache=threading.local();oldpowers=q.a.powers
params={r['title']:int(r['id'])for r in csv.DictReader((q.D/'ZL-default-parameters.tsv').open(),delimiter='\t')}
def values(path):
 b=Path(path).read_bytes();return {x.attrib['id']:float(x.attrib['value'])for x in ET.fromstring(b[8:8+struct.unpack_from('<I',b,4)[0]]).find('Para')}
origin=values(R/'PRIMARY.bin');assert origin['lr_mode22']==4 and origin['dynamic_on22']==1 and origin['filter_status22']==2
specs=[dict(title='Knee Width22',key='knee_width22',lo=0.,hi=24.,step=3.),dict(title='Dynamic RMS Length22',key='dynamic_rms_length22',lo=0.,hi=40.,step=3.),dict(title='Dynamic RMS Mix22',key='dynamic_rms_mix22',lo=0.,hi=100.,step=15.),dict(title='Dynamic Smooth22',key='dynamic_smooth22',lo=0.,hi=100.,step=15.)]
anchor=Path('/workspace/divalead/diva-lead/research/native-low-latency-effects/local-fl-studio/cloud-after-1625/2026-10-22/ZL-WIP37/verification/ZL37_PRIMARY_COMPONENT.bin');(R/'ANCHOR37_PRIMARY.bin').write_bytes(anchor.read_bytes())
def powers(*args,**kw):
 v=oldpowers(*args,**kw);cache.power=v[0];return v
q.a.powers=powers
def assess(y):
 d=q.assess(y);e=10*np.log10(np.maximum(cache.power,1e-15)/np.maximum(q.a.TP,1e-15));d['positive_excess_air_dB']=float(np.maximum(e[:,4:6,2:],0).mean());v=np.array(d['LR_dB']);d['original_stereo_preservation_passed']=bool(np.sqrt(np.mean((v[1:]-q.reference_LR[1:])**2))<=1.48 and max(abs(v[1:]))<=1.6 and abs(v[0]-q.reference_LR[0])<=3.25);return d
def record(phase,**kw):
 d=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),actual_fit_ZL_hosts=[]if fit is None else[c.child.pid for pair in fit.clients for c in pair],actual_fit_trim_hosts=[]if fit is None else[c.chain.proc.pid for c in fit.trims.values()],only_existing_Side22_detector_knee_RMSlength_RMSmix_smooth_changed=True,source281_MIDI3held_ARP_ADSR_native12_POST37_trim_and_other_PRIMARY_XML_unchanged=True,original_is_only_target=True,not_adopted=True,reference_match_reached=False,**kw);tmp=STATE.with_suffix('.partial');tmp.write_text(json.dumps(d,indent=2)+'\n');tmp.replace(STATE)
def cascade(raw,component):
 p.load(component);z.load(R/'POST.bin');mid,_=p.render(raw);pre,_=z.render(mid);assert p.latency()+z.latency()==0;return trim.render(pre)
def configure(host,x):
 host.load(R/'PRIMARY.bin')
 for spec,value in zip(specs,x):host.text(params[spec['title']],format(value,'.12g'))
def add(tar,name,y):
 b=io.BytesIO();sf.write(b,y,48000,format='WAV',subtype='FLOAT');data=b.getvalue();info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data));members.append(dict(name=name,bytes=len(data),SHA256=hashlib.sha256(data).hexdigest()))
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(parameters=specs,older24detector_study_only14_15_16_17_20_21_not22=True,actual22_is_Side_mode4_and20_21_are_Mid_mode3=True,three_COMMON_native_inputs_two_fresh_unseen=True,trainingAir_min_control_MINUS0005_anchor37_plus001=True,first6_AND_first10_gain_over_max0005_3SEM=True,bothcold_positive=True,all_original_stereo148_abs16_lowmid325_and_both_controls_lowmid_plus002=True,local_first10_Air_decrease_min0005_and_bothcold_not_increased=True,cumulative_anchor37_first10_and_bothcold_Air_plus002=True,no_new_filter_source_or_MIDI=True,latest_context_full_export_required=True),indent=2)+'\n')
try:
 p=q.WinVST3('Side22Detector-'+str(os.getpid())+'-primary');z=q.WinVST3('Side22Detector-'+str(os.getpid())+'-post');trim=NativePostTrim(R/'buffers','Side22Detector-'+str(os.getpid())+'-trim',cleanup_on_close=True);trim.load(q.prior['post_native_trim_state']);n=q.native(q.source['native_input'],'Side22Detector-'+str(os.getpid())+'-native');inputs=[];controls=[];anchors=[];record('five_actual_common_native_control_and_anchor_inputs')
 for k in range(5):
  raw,_=n.render();inputs.append(raw);c=cascade(raw,R/'PRIMARY.bin');a=cascade(raw,R/'ANCHOR37_PRIMARY.bin');controls.append(assess(c));anchors.append(assess(a));sf.write(R/f'TRAINING_NATIVE_{k}.wav',raw,48000,subtype='FLOAT');sf.write(R/f'TRAINING_CONTROL_{k}.wav',c,48000,subtype='FLOAT');sf.write(R/f'TRAINING_ANCHOR37_{k}.wav',a,48000,subtype='FLOAT')
 n.close();n=None;p.close();p=None;z.close();z=None;trim.close();trim=None;(R/'CONTROL_ANCHOR_ASSESSMENTS.json').write_text(json.dumps(dict(controls=controls,anchors=anchors),indent=2)+'\n');air_cap=min(float(np.mean([d['positive_excess_air_dB']for d in controls[:3]]))-.005,float(np.mean([d['positive_excess_air_dB']for d in anchors[:3]]))+.01);low_cap=min(3.25,float(np.mean([d['lowmid_error']for d in controls[:3]]))+.005,float(np.mean([d['lowmid_error']for d in anchors[:3]]))+.005)
 fit=MeanThreePrimaryFit(R,R/'PRIMARY.bin',R/'POST.bin',assess,record,inputs,q.prior['post_native_trim_state'],air_cap,low_cap);fit.configure=configure;fit.specs=specs;fit.initial=[origin[s['key']]for s in specs];current=fit.evaluate(('initial-exact-current-detector22',fit.initial));initial=current;rng=np.random.default_rng(2026102801)
 def choose(cases,current):
  rows=[current,*cases];valid=[x for x in rows if x['stereo_preservation_passed']]
  if valid:return min(valid,key=lambda x:x['loss'])
  return min(rows,key=lambda x:(max(0,x['positive_excess_air_dB']-air_cap)/.01+max(0,x['lowmid_error']-low_cap)/.02+(0 if x['original_stereo_preservation_passed']else 100),x['loss']))
 with concurrent.futures.ThreadPoolExecutor(2)as ex:
  cases=[]
  for j in range(32):
   x=[float(np.clip(v+rng.normal()*s['step']*float(rng.choice([.5,1,2])),s['lo'],s['hi']))for s,v in zip(specs,current['x'])];cases.append(('coupled-'+str(j),x))
  current=choose(list(ex.map(fit.evaluate,cases)),current)
  for sweep in range(4):
   for j in rng.permutation(4):
    cases=[]
    for factor in[-2,-1,1,2]:x=list(current['x']);s=specs[j];x[j]=float(np.clip(x[j]+factor*s['step']*(.65**sweep),s['lo'],s['hi']));cases.append((f'coordinate-{sweep}-{j}-{factor}',x))
    current=choose(list(ex.map(fit.evaluate,cases)),current);record('actual_Side22_detector_mean3_fit',cases=len(fit.rows),sweep=int(sweep),coordinate=int(j),selected_loss=current['loss'],feasible=bool(current['stereo_preservation_passed']))
 held=[fit.evaluate(('heldout-'+str(k),current['x']),k,False)for k in[3,4]];gain=float(np.mean([controls[k]['loss']-d['loss']for k,d in zip([3,4],held)]));held_ok=bool(all(d['original_stereo_preservation_passed']and d['lowmid_error']<=controls[k]['lowmid_error']+.02 and d['lowmid_error']<=anchors[k]['lowmid_error']+.02 and d['positive_excess_air_dB']<=controls[k]['positive_excess_air_dB']and d['positive_excess_air_dB']<=anchors[k]['positive_excess_air_dB']+.02 for k,d in zip([3,4],held)));p0,z0=fit.clients[0];configure(p0,current['x']);component=R/'CANDIDATE_PRIMARY.bin';p0.save(component);now=values(component);changed={key:[v,now[key]]for key,v in origin.items()if v!=now[key]};assert set(changed)<={s['key']for s in specs};mid,_=p0.render(inputs[0]);z0.load(R/'POST.bin');pre,_=z0.render(mid);out=fit.trims[p0.child.pid].render(pre);sf.write(R/'SELECTED_FULL_TRAINING_WIP.wav',out,48000,subtype='FLOAT');(R/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(fit.rows).encode(),mtime=0));summary=dict(training_cases=len(fit.rows),actual_training_DSP_renders=3*len(fit.rows),initial=initial,selected=current,heldout=held,heldout_mean_gain=gain,heldout_constraints_passed=held_ok,changed_XML_fields=changed,component=str(component),sufficient_screen=bool(gain>.0003 and held_ok and current['stereo_preservation_passed']),robust_improvement=False,not_adopted=True,reference_match_reached=False);fit.close();fit=None;(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
 if summary['sufficient_screen']:
  p=q.WinVST3('Side22Detector-'+str(os.getpid())+'-validation-primary');z=q.WinVST3('Side22Detector-'+str(os.getpid())+'-validation-post');trim=NativePostTrim(R/'buffers','Side22Detector-'+str(os.getpid())+'-validation-trim',cleanup_on_close=True);trim.load(q.prior['post_native_trim_state']);n=q.native(q.source['native_input'],'Side22Detector-'+str(os.getpid())+'-validation-native')
  with tarfile.open(R/'TWELVE_NEW_NATIVE_ANCHOR_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in[10,11]:n.close();n=q.native(q.source['native_input'],'Side22Detector-'+str(os.getpid())+'-cold-native-'+str(rep))
    raw,_=n.render();a=cascade(raw,R/'ANCHOR37_PRIMARY.bin');da=assess(a);c=cascade(raw,R/'PRIMARY.bin');dc=assess(c);y=cascade(raw,component);dy=assess(y);captures.append(dict(rep=rep,anchor37=da,control=dc,candidate=dy,improvement=dc['loss']-dy['loss'],air_increase=dy['positive_excess_air_dB']-dc['positive_excess_air_dB'],anchor_air_increase=dy['positive_excess_air_dB']-da['positive_excess_air_dB']))
    for name,v in [('native',raw),('anchor37',a),('control',c),('candidate',y)]:add(tar,f'{name}-{rep}.wav',v)
    if rep==0:
     for name,v in [('NATIVE_INPUT',raw),('ANCHOR37',a),('CONTROL',c),('CANDIDATE',y)]:sf.write(R/(name+'_00.wav'),v,48000,subtype='FLOAT')
    record('Side22_detector_first6_AND_first10_two_cold',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  d=np.array([x['improvement']for x in captures]);air=np.array([x['air_increase']for x in captures]);aa=np.array([x['anchor_air_increase']for x in captures]);sem6=float(d[:6].std(ddof=1)/np.sqrt(6));sem10=float(d[:10].std(ddof=1)/np.sqrt(10));guard=all(x['candidate']['original_stereo_preservation_passed']and x['candidate']['lowmid_error']<=min(x['control']['lowmid_error'],x['anchor37']['lowmid_error'])+.02 for x in captures);robust=bool(d[:6].mean()>max(.0005,3*sem6)and d[:10].mean()>max(.0005,3*sem10)and min(d[10:])>0 and air[:10].mean()<=-.005 and max(air[10:])<=0 and aa[:10].mean()<=.02 and max(aa[10:])<=.02 and guard);summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(d[:6].mean()),first6_SEM=sem6,first10_mean_improvement=float(d[:10].mean()),first10_SEM=sem10,cold2_improvements=d[10:].tolist(),first10_air_increase=float(air[:10].mean()),cold2_air_increase=air[10:].tolist(),anchor_first10_air_increase=float(aa[:10].mean()),anchor_cold2_air_increase=aa[10:].tolist(),all12_stereo_lowmid_guards_passed=guard,robust_improvement=robust)
  with tarfile.open(R/'TWELVE_NEW_NATIVE_ANCHOR_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_Side22_detector_complete_not_adopted',sufficient_screen=summary['sufficient_screen'],robust_improvement=summary['robust_improvement']);print(json.dumps({k:v for k,v in summary.items()if k not in ['initial','selected','heldout','captures','archive_members']}),flush=True)
except BaseException:record('failed_preserve_current_accepted372',error=traceback.format_exc());raise
finally:
 if fit is not None:fit.close()
 for c in[n,p,z,trim]:
  if c is not None:c.close()
