"""Test four small Diva source-tone/drive alternatives with their own primary fit.

Actual Diva source with exactly one changed parameter and identical MIDI;
each model gets its own actual two-ZL primary refit and held-out native inputs.
The original WAV is the sole target. Research is never silently adopted.
"""
from pathlib import Path
import datetime,gzip,hashlib,io,json,os,tarfile,traceback
import numpy as np,soundfile as sf
import original_Diva_tone_drive_four_library as q
from normal_real_ZL_refit import RealPrimaryFit
from win_vst3 import WinVST3
R=q.ROOT;H=Path(__file__).resolve().parent;STATE=q.STATE;seed=q.seed
assert q.prior['accepted_full_public_kit']=='ZL32'
models=[dict(name='offset_minus014',section='VCA1',key='Offset',value=-.14,index=175),dict(name='VCA_level48',section='VCA1',key='Vol',value=48.,index=168),dict(name='cutoff14316',section='VCF1',key='Freq',value=143.16,index=148),dict(name='OscMix7',section='OSC',key='OscMix',value=7.,index=96)]
def record(phase,**extra):
 s=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),only_three_held_notes=True,original_is_the_only_target=True,source_change_only_one_recorded_tone_drive_parameter=True,all12_native_plugin_states_unchanged=True,all_external_Chorus_settings_and_parallel_mix_unchanged=True,primary_refitted_for_each_source=True,not_adopted=True,reference_match_reached=False,**extra);p=STATE.with_suffix('.partial');p.write_text(json.dumps(s,indent=2)+'\n');p.replace(STATE)
def native(source,wet,tag):
 c=q.native(source,tag)
 if wet is not None:c.gain(0,1-wet);c.gain(1,wet)
 return c
def cascade(raw,p,z,primary):
 p.load(primary);z.load(R/'POST.bin');mid,_=p.render(raw);out,_=z.render(mid);assert p.latency()+z.latency()==0;return out
def add(tar,name,y,members):
 b=io.BytesIO();sf.write(b,y,48000,format='WAV',subtype='FLOAT');data=b.getvalue();i=tarfile.TarInfo(name);i.size=len(data);tar.addfile(i,io.BytesIO(data));members.append(dict(name=name,bytes=len(data),SHA256=hashlib.sha256(data).hexdigest()))
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(models=models,all281_Diva_parameters_and_all12_note_events_audited=True,source_changed_parameter_indices=[175,168,148,96],same_ARP_ADSR_incoming_3_long_notes=True,all12_native_plugin_states_and_WS52_unchanged=True,all_native_plugin_states_and_parallel_mix_unchanged=True,one_separate_actual_primary_refit_for_each_model=True,three_new_native_training_inputs_two_heldouts=True,full_original_score_weights_alignment_stereo_guards_unchanged=True,BOTH_first6_AND_first10_gain_over_max_0005_and_3SEM=True,two_cold_gains_positive=True,new_source_chunk_cold_replay_byte_exact=True,not_adopted_without_latest_context_and_full_export=True),indent=2)+'\n')
fit=None;hosts=[];natives=[];results=[]
try:
 record('capture_three_new_actual_baseline32_native_inputs');c=native(q.source['native_input'],None,'DivaToneDrive4-control');natives=[c];p=WinVST3('DivaToneDrive4-control-primary');z=WinVST3('DivaToneDrive4-control-post');hosts=[p,z];controls=[]
 for k in range(3):
  raw,_=c.render();out=cascade(raw,p,z,R/'PRIMARY.bin');controls.append(q.assess(out));sf.write(R/f'CONTROL_NATIVE_{k}.wav',raw,48000,subtype='FLOAT');sf.write(R/f'CONTROL_PROCESSED_{k}.wav',out,48000,subtype='FLOAT')
 c.close();natives=[];p.close();z.close();hosts=[];control_mean=float(np.mean([r['loss']for r in controls]));(R/'CONTROL_ASSESSMENTS.json').write_text(json.dumps(controls,indent=2)+'\n')
 for model in models:
  folder=R/model['name'];folder.mkdir();h2p=folder/'Diva.h2p';h2p.write_text(q.patched({(model['section'],model['key']):model['value']}));raw,actual=q.actual_Diva(h2p,folder/'actual-Diva');changed={i for i in q.original if actual[i]['normalized']!=q.original[i]['normalized']};assert changed=={model['index']},changed
  padded=folder/'source-with-tail.wav';sf.write(padded,np.pad(raw,((0,32768),(0,0))),48000,subtype='FLOAT');source=dict(source_preset=str(h2p),source_audio=str(folder/'actual-Diva/Diva_source.wav'),source_VST_chunk=str(folder/'actual-Diva/Diva_VST_chunk.bin'),native_input=str(padded),changed_parameters={actual[i]['name']:dict(before=q.original[i],after=actual[i])for i in changed},all281_audited=True,all12_MIDI_events_exact=True,ARP_ADSR_and_only_three_held_notes_unchanged=True);(folder/'ACTUAL_SOURCE_PROOF.json').write_text(json.dumps(source,indent=2)+'\n')
  record('render_actual_Diva_source_tone_drive_and_native_training_inputs',model=model);c=native(padded,None,'DivaToneDrive4-'+model['name']);natives=[c]
  for k in range(3):
   raw,_=c.render();raw.astype('<f4').tofile(folder/f'frozen-native-{k}.f32');sf.write(folder/f'TRAINING_NATIVE_{k}.wav',raw,48000,subtype='FLOAT')
  c.close();natives=[];fit=RealPrimaryFit(folder,R/'PRIMARY.bin',R/'POST.bin',q.assess,lambda phase,**kw:record('actual_source_tone_drive_and_primary_refit',model=model,fit_phase=phase,**kw));initial,current=fit.fit(sweeps=1);held=[fit.evaluate(('heldout-'+str(k),current['x']),k,False)for k in [1,2]];p,z=fit.clients[0];fit.configure(p,current['x']);p.save(folder/'PRIMARY_MODEL.bin');mid,_=p.render(input_file=folder/'frozen-native-0.f32');z.load(R/'POST.bin');out,_=z.render(mid);sf.write(folder/'SELECTED_TRAINING_FULL_WIP.wav',out,48000,subtype='FLOAT');(folder/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(fit.rows).encode(),mtime=0));row=dict(model=model,source=source,folder=str(folder),training_cases=len(fit.rows),initial=initial,selected=current,heldout=held,heldout_mean=float(np.mean([r['loss']for r in held])),all_heldout_stereo_passed=all(r['stereo_preservation_passed']for r in held),not_adopted=True);results.append(row);(folder/'SCREEN_RESULT.json').write_text(json.dumps(row,indent=2)+'\n');fit.close();fit=None;(R/'COMPLETED_MODEL_REFITS.json').write_text(json.dumps(results,indent=2)+'\n');record('source_tone_drive_model_completed',model=model,heldout_mean=row['heldout_mean'],control_mean=control_mean)
 eligible=[r for r in results if r['all_heldout_stereo_passed']];winner=min(eligible,key=lambda r:r['heldout_mean'])if eligible else None;ready=bool(winner and control_mean-winner['heldout_mean']>.0003);summary=dict(training_cases=sum(r['training_cases']for r in results),control_mean=control_mean,winner=winner,sufficient_screen=ready,robust_improvement=False,original_is_the_only_target=True,requires_latest_context_revalidation=True,not_adopted=True,reference_match_reached=False);(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
 if ready:
  folder=Path(winner['folder']);model=winner['model'];source=winner['source'];cold,actual=q.actual_Diva(Path(source['source_VST_chunk']),R/'cold-source-chunk-replay');want,rate=sf.read(source['source_audio'],dtype='float32',always_2d=True);np.testing.assert_array_equal(cold,want);assert actual==q.parameters(Path(source['source_audio']).parent/'all281.tsv');assert(R/'cold-source-chunk-replay/Diva_VST_chunk.bin').read_bytes()==Path(source['source_VST_chunk']).read_bytes()
  c0=native(q.source['native_input'],None,'DivaToneDrive4-confirm-control');c1=native(source['native_input'],None,'DivaToneDrive4-confirm-candidate');natives=[c0,c1];p0=WinVST3('DivaToneDrive4-confirm-primary0');z0=WinVST3('DivaToneDrive4-confirm-post0');p1=WinVST3('DivaToneDrive4-confirm-primary1');z1=WinVST3('DivaToneDrive4-confirm-post1');hosts=[p0,z0,p1,z1];captures=[];members=[]
  with tarfile.open(R/'TWELVE_NEW_NATIVE_PROCESSED_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in [10,11]:
     c0.close();c1.close();c0=native(q.source['native_input'],None,'DivaToneDrive4-cold-control-'+str(rep));c1=native(source['native_input'],None,'DivaToneDrive4-cold-candidate-'+str(rep));natives=[c0,c1]
    raw0,_=c0.render();old=cascade(raw0,p0,z0,R/'PRIMARY.bin');d0=q.assess(old);raw1,_=c1.render();out=cascade(raw1,p1,z1,folder/'PRIMARY_MODEL.bin');d1=q.assess(out);captures.append(dict(rep=rep,control=d0,candidate=d1,improvement=d0['loss']-d1['loss']))
    for name,y in [('native-control',raw0),('native-candidate',raw1),('control',old),('candidate',out)]:add(tar,f'{name}-{rep}.wav',y,members)
    if rep==0:
     for name,y in [('NATIVE_CONTROL',raw0),('NATIVE_CANDIDATE',raw1),('CONTROL',old),('CANDIDATE',out)]:sf.write(R/(name+'_00.wav'),y,48000,subtype='FLOAT')
    record('fresh6_AND_first10_plus_cold2',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  delta=np.array([r['improvement']for r in captures]);sem6=float(np.std(delta[:6],ddof=1)/np.sqrt(6));sem10=float(np.std(delta[:10],ddof=1)/np.sqrt(10));robust=bool(np.mean(delta[:6])>max(.0005,3*sem6)and np.mean(delta[:10])>max(.0005,3*sem10)and min(delta[10:])>0 and all(r['candidate']['stereo_preservation_passed']for r in captures));summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(np.mean(delta[:6])),first6_SEM=sem6,first10_mean_improvement=float(np.mean(delta[:10])),first10_SEM=sem10,cold2_improvements=delta[10:].tolist(),robust_improvement=robust,source_chunk_audio_params_events_byte_exact=True)
  with tarfile.open(R/'TWELVE_NEW_NATIVE_PROCESSED_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_Diva_tone_drive_four_study_complete_not_adopted',robust_improvement=summary['robust_improvement'],sufficient_screen=ready);print(json.dumps({k:v for k,v in summary.items()if k not in ['winner','captures','archive_members']}),flush=True)
except BaseException:record('failed_preserve_full32_and_current_best',error=traceback.format_exc());raise
finally:
 if fit is not None:fit.close()
 for c in natives:c.close()
 for c in hosts:c.close()
