"""Observe this finite actual fit; back up closed data, never adopt a research point."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,traceback
U=Path(__file__).resolve().parent;N=U.parent/'native-low-latency-effects';R=Path('/tmp/divalead-WS-native-OS-joint109-left003-current39-20261031');S=N/'ORIGINAL_NATIVE_WS_OS_JOINT109_LEFT003_CURRENT39_STUDY.json';O=U.parent/'stereo-refinement-20261025';P=Path('/workspace/divalead');PUBLIC=P/'diva-lead/research/native-low-latency-effects/local-fl-studio/cloud-after-1625/2026-10-22';state=json.loads(S.read_text());pid=state['PID'];proc=Path('/proc')/str(pid);started=(proc/'stat').read_text().split()[21];watchstate=U/'WS_OS_LEFT003_AUTOBACKUP_CONTROLLER.json'
def live():
 try:
  stat=(proc/'stat').read_text().split();return stat[2]!='Z'and stat[21]==started
 except OSError:return False

def record(phase,**kw):
 d=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),watcher_PID=os.getpid(),observed_study_PID=pid,observed_study_starttime=started,phase=phase,study_root=str(R),never_automatically_adopt_research=True,reference_match_reached=False,**kw);tmp=watchstate.with_suffix('.partial');tmp.write_text(json.dumps(d,indent=2)+'\n');tmp.replace(watchstate)
try:
 record('waiting_for_actual_finite_study_to_exit')
 while live():time.sleep(20)
 complete=R/'completion.json';summary=json.loads(complete.read_text())if complete.exists()else{};positive=bool(summary.get('robust_improvement'));kind='positive-not-adopted'if positive else'negative'if complete.exists()else'interrupted';snapshot_label='original-WS-OS-joint109-left003-live-snapshot-20261031';snapshot=PUBLIC/snapshot_label;receipt=O/(snapshot_label+'_PUBLICATION.json');reused=[]
 if receipt.exists():
  rep=json.loads(receipt.read_text());assert rep['all_retained_study_files_and_WAVs_remote_Git_verified'];members={x['name']:x for x in json.loads((snapshot/'ARCHIVE_MEMBER_SHA256.json').read_text())}
  for p in R.rglob('*.wav'):
   name=p.relative_to(R).as_posix()
   if name not in members or(positive and name=='CURRENT_DIVA_REAL_RUN/Diva_source.wav'):continue
   row=members[name];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['SHA256'];reused.append(row)
  reuse=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),snapshot_commit=rep['commit'],snapshot_public_path=rep['public_path'],all_reused_closed_WAVs_previously_remote_Git_verified=True,training_WAVs_and_source_data_reused_instead_of_duplicate_archive_bytes=True,files=reused)
  (R/'REUSED_REMOTE_FIXED_TRAINING_WAVS.json').write_text(json.dumps(reuse,indent=2)+'\n')
  for row in reused:
   p=R/row['name'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['SHA256'];p.unlink()
 code=R/'replay-code';code.mkdir(exist_ok=True)
 for name in['WS_OS_joint109_left003_support.py','prepare_WS_OS_joint109_left003.py','study_WS_OS_both_ZL109_left003_current39.py','watch_WS_OS_left003_complete_backup.py','snapshot_live_WS_OS_joint109_left003.py']:shutil.copyfile(U/name,code/name)
 for source in[U.parent/'continuation-20261030/joint_primary_post_fit.py',U.parent/'stereo-refinement-20261026/checked_mean_three_real_primary_fit.py',U.parent/'stereo-refinement-20261026/normal_staged_primary_fit.py',Path('/tmp/divalead-local-1625/fl20_curve.py')]:shutil.copyfile(source,code/source.name)
 shutil.copyfile(U/'WS_OS_JOINT109_LEFT003_CURRENT39.log',R/'ACTUAL_STUDY_PROCESS.log');(R/'ACTUAL_CLOSURE_AND_BACKUP_SCOPE.json').write_text(json.dumps(dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_observed_PID=pid,actual_starttime=started,actual_process_no_longer_live=True,completion_json_present=complete.exists(),result_classification=kind,reference_match_reached=False,not_adopted=True,full_supported_OS_schema_export_cold_ZIP_and_latest_context_required_before_any_adoption=True,reused_training_WAV_count=len(reused),legacy_shared_fitter_phase_name_not_actual109_model_description=True),indent=2)+'\n');label='original-WS-native-OS-joint109-left003-'+kind+'-20261031';record('publishing_closed_actual_study',label=label,robust_positive_but_not_adopted=positive)
 command=['/workspace/.venvs/divalead/bin/python','-B',str(O/'backup_complete_finite_study.py'),'--root',str(R),'--label',label,'--note','Результат '+kind+' отдельного настоящего nativeWS Oversamplingstep1 + LeftTrim−.030dB + bothZL109refit. Оригинал единственнаяцель; sourceDiva281/12MIDI/3ноты/ARP/ADSR/11othernative неизменны. Итоговые гейты определяетcompletion.json, а не поисковыйloss. Еслиcompletion отсутствует, серия прервана и успешное завершение не утверждается. Все новые оставшиеся WAV/состояния/измерения/код сохранены; фиксированные trainingWAV при наличии точного SHA повторно не дублируются, а полностью сохранены в отдельном live-snapshot, указанном REUSED_REMOTE_FIXED_TRAINING_WAVS.json. Ничего не принято: нуженlatestBESTконтекст, явная поддержкаOSbyte18, полныйFL20экспорт и независимыйcoldZIP.']
 if positive:command.append('--retain-local-audio')
 with(U/'WS_OS_LEFT003_COMPLETED_BACKUP.log').open('w')as log:done=subprocess.run(command,stdout=log,stderr=log)
 record('closed_actual_study_backup_verified'if done.returncode==0 else'backup_failed_preserve_all_unuploaded_data_and_logs',returncode=done.returncode,label=label,robust_positive_but_not_adopted=positive);raise SystemExit(done.returncode)
except BaseException as e:
 if not isinstance(e,SystemExit):record('watcher_failed_preserve_all_data',error=traceback.format_exc())
 raise
