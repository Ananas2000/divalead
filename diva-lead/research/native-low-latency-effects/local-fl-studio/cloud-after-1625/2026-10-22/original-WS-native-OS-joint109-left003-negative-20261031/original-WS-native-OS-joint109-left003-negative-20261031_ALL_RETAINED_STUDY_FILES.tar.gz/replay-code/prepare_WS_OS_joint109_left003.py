from pathlib import Path
u=Path(__file__).resolve().parent;q=(u/'WS_OS_joint109_support.py').read_text().replace('/tmp/divalead-WS-native-oversampling-joint109-current39-20261031','/tmp/divalead-WS-native-OS-joint109-left003-current39-20261031').replace('ORIGINAL_NATIVE_WS_OVERSAMPLING_JOINT109_CURRENT39_STUDY','ORIGINAL_NATIVE_WS_OS_JOINT109_LEFT003_CURRENT39_STUDY');(u/'WS_OS_joint109_left003_support.py').write_text(q)
s=(u/'study_WS_OS_both_ZL109_current39.py').read_text().replace('import WS_OS_joint109_support as q','import WS_OS_joint109_left003_support as q').replace("'WS_OS_JOINT109_CURRENT39'","'WS_OS_JOINT109_LEFT003_CURRENT39'")
pos=s.index('def candidate_native(')
s=s[:pos]+'''CANDIDATE_TRIM=R/'CANDIDATE_NATIVE_POST_TRIM_LEFT003.bin';prep=NativePostTrim(R/'prepare-trim-buffers','OSJ109-Left003-prepare-'+str(os.getpid()),cleanup_on_close=True)
try:
 prep.configure(NativePostTrim.raw_from_dB(-.03),12800);prep.save(CANDIDATE_TRIM);prep.load(CANDIDATE_TRIM);prep.save(R/'CANDIDATE_TRIM_RESAVED.bin');assert CANDIDATE_TRIM.read_bytes()==(R/'CANDIDATE_TRIM_RESAVED.bin').read_bytes()
finally:prep.close()
assert CANDIDATE_TRIM.read_bytes()!=Path(q.prior['post_native_trim_state']).read_bytes();(R/'NEW_DSP_POINT_AND_UNCHANGED_GATES.json').write_text(json.dumps(dict(only_additional_change_vs_failed_OS_seed_model='native final left trim requested -.020 to -.030dB, right0',old_native_trim_SHA256=hashlib.sha256(Path(q.prior['post_native_trim_state']).read_bytes()).hexdigest(),candidate_native_trim_SHA256=hashlib.sha256(CANDIDATE_TRIM.read_bytes()).hexdigest(),training_paired_lowmid_extra_limit_plus0005_and_all_final_limits_unchanged=True,no_retest_of_same_failed_DSP_point=True,actual_native_trim_resave_exact=True),indent=2)+'\\n')
'''+s[pos:]
s=s.replace('def cascade(raw,component,post_component=None):\n p.load(component);',"def cascade(raw,component,post_component=None,candidate=False):\n trim.load(CANDIDATE_TRIM if candidate else q.prior['post_native_trim_state']);p.load(component);")
s=s.replace('def set_seed(delta):\n  p.load', 'def set_seed(delta):\n  trim.load(CANDIDATE_TRIM);p.load')
s=s.replace("inputs,q.prior['post_native_trim_state'],air_cap,low_cap)","inputs,CANDIDATE_TRIM,air_cap,low_cap)")
s=s.replace('new=cascade(candidate_raw,component,post_component)','new=cascade(candidate_raw,component,post_component,candidate=True)')
s=s.replace('source_Diva281_MIDI3held_ARP_ADSR_other11native_nativeTrim_unchanged_only_GUI_WS_oversampling_step1=True', 'source_Diva281_MIDI3held_ARP_ADSR_other11native_unchanged_GUI_WS_OS_step1_and_leftTrim003_changed=True')
s=s.replace('no_source_MIDI_or_trim_change=True,only_WS_native_GUI_oversampling_step1_changed=True', 'no_source_or_MIDI_change=True,WS_native_GUI_oversampling_step1_and_final_leftTrim003_changed=True')
s=s.replace('source_WS_GUI_oversampling_step1_requires_explicit_generator_schema_migration=True)',"source_WS_GUI_oversampling_step1_requires_explicit_generator_schema_migration=True,post_native_trim_state=str(CANDIDATE_TRIM),post_native_trim=dict(q.prior['post_native_trim'],requested_left_dB=-.03,left_raw=NativePostTrim.raw_from_dB(-.03)),post_native_trim_state_SHA256=hashlib.sha256(CANDIDATE_TRIM.read_bytes()).hexdigest())")
(u/'study_WS_OS_both_ZL109_left003_current39.py').write_text(s)
