"""New DSP point: relative air mode plus an air-constrained primary refit."""
from pathlib import Path
import ast,gzip,hashlib,io,json,os,tarfile,traceback
import numpy as np,soundfile as sf
from normal_real_ZL_refit import RealPrimaryFit
H=Path(__file__).resolve().parent
# Reuse the executed original-WAV assessor, canonical native loader, actual
# VST3 wrapper, and WAV archiver, without running the prior finite experiment.
support=H/'study_existing_relative_air_dynamics_original.py'
prefix=support.read_text().split("(R/'PREDECLARED_PROTOCOL.json').write_text",1)[0]
prefix=prefix.replace("R=H/'PRIMARY_RELATIVE_AIR_DYNAMICS'","R=H/'RELATIVE_AIR_PRIMARY_JOINT'").replace("ORIGINAL_PRIMARY_RELATIVE_AIR_DYNAMICS_STUDY.json","ORIGINAL_RELATIVE_AIR_PRIMARY_JOINT_STUDY.json")
exec(compile(prefix,str(support)+'-support-only','exec'),globals())
failed=H/'PRIMARY_RELATIVE_AIR_DYNAMICS';assert not json.loads((failed/'completion.json').read_text())['robust_improvement'];(R/'RELATIVE_START_PRIMARY.bin').write_bytes((failed/'CANDIDATE_PRIMARY.bin').read_bytes())
maximum_training_air=None
def constrained(y):
 d=assess(y);d['original_stereo_preservation_passed']=d['stereo_preservation_passed'];d['stereo_preservation_passed']=bool(d['stereo_preservation_passed']and(maximum_training_air is None or d['positive_excess_air_3500_6500_dB']<=maximum_training_air));return d
def cascade(raw,p,z,component):
 p.load(component);z.load(R/'POST.bin');mid,_=p.render(raw);out,_=z.render(mid);assert p.latency()+z.latency()==0;return out
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(new_candidate_requires_changed_primary_from_rejected_relative_state=True,no_added_filters_or_plugins=True,relative_mode21_preserved=True,new_native_inputs3_two_heldouts=True,original_score_weights_alignment_stereo_guards_unchanged=True,training_air_cap_control_mean_plus_dB=.01,heldout_air_cap_same_input_control_plus_dB=.02,BOTH_first6_AND_first10_gain_over_max_0005_and_3SEM=True,warm10_cold2=True,both_cold_gains_positive=True,all_candidate_render_PDC_frames_zero=True,same_native_input_per_control_candidate_pair=True,first10_air_excess_increase_limit_dB=.02,both_cold_air_increase_limit_dB=.02,constrained_fit_fallback_must_be_feasible_once_feasible_candidates_exist=True,reused_executed_assessor_source_SHA256=hashlib.sha256(support.read_bytes()).hexdigest()),indent=2)+'\n')
c=None;fit=None;clients=[]
try:
 record('three_new_native_inputs_and_original_controls');c=native('RelativeAirPrimaryJoint-native-training');p=WinVST3('RelativeAirPrimaryJoint-control-primary');z=WinVST3('RelativeAirPrimaryJoint-control-post');clients=[(p,z)];controls=[]
 for k in range(3):
  raw,_=c.render();raw.astype('<f4').tofile(R/f'frozen-native-{k}.f32');sf.write(R/f'TRAINING_NATIVE_{k}.wav',raw,48000,subtype='FLOAT');out=cascade(raw,p,z,R/'CONTROL_PRIMARY.bin');controls.append(assess(out));sf.write(R/f'TRAINING_CONTROL_{k}.wav',out,48000,subtype='FLOAT')
 c.close();c=None;p.close();z.close();clients=[];control_mean=float(np.mean([r['loss']for r in controls]));maximum_training_air=float(np.mean([r['positive_excess_air_3500_6500_dB']for r in controls]))+.01
 fit=RealPrimaryFit(R,R/'RELATIVE_START_PRIMARY.bin',R/'POST.bin',constrained,lambda phase,**kw:record('actual_air_constrained_primary87_joint_fit',fit_phase=phase,**kw));clients=fit.clients;rows=fit.rows;initial,current=fit.fit(sweeps=2);held=[fit.evaluate(('new-heldout-'+str(k),current['x']),k,False)for k in [1,2]];p,z=fit.clients[0];fit.configure(p,current['x']);p.save(R/'CANDIDATE_PRIMARY.bin');p.dump(R/'CANDIDATE_610_PARAMETERS.tsv');now=values(R/'CANDIDATE_PRIMARY.bin');start_values=values(R/'RELATIVE_START_PRIMARY.bin');changed={k:[v,now[k]]for k,v in start_values.items()if now[k]!=v};assert changed
 allowed_prefixes=['freq','q','gain','side_freq','side_q','target_gain','threshold','attack','release'];allowed={k for k in original if k.rstrip('0123456789')in allowed_prefixes}|{'total_output_gain'};assert set(changed).issubset(allowed),changed;assert now['dynamic_relative21']==1 and all(now[k]==start_values[k]for k in now if k.startswith(('filter_status','filter_type','lr_mode','order','dynamic_relative')))
 (R/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(fit.rows).encode(),mtime=0));newpoint=(R/'CANDIDATE_PRIMARY.bin').read_bytes()!=(R/'RELATIVE_START_PRIMARY.bin').read_bytes();fit.close();fit=None;clients=[];(R/'CONTROL_ASSESSMENTS.json').write_text(json.dumps(controls,indent=2)+'\n');(R/'HELDOUT.json').write_text(json.dumps(held,indent=2)+'\n');frozen=dict(new_primary_changed_from_rejected_state=newpoint,selected_vector=current['x'],changed_XML_fields=changed,primary_SHA256=hashlib.sha256((R/'CANDIDATE_PRIMARY.bin').read_bytes()).hexdigest(),maximum_training_air=maximum_training_air,not_adopted=True);(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(frozen,indent=2)+'\n')
 ready=bool(newpoint and current['stereo_preservation_passed']and control_mean-float(np.mean([r['loss']for r in held]))>.0003 and all(r['original_stereo_preservation_passed']and r['loss']<controls[k]['loss']-.0001 and r['positive_excess_air_3500_6500_dB']<=controls[k]['positive_excess_air_3500_6500_dB']+.02 for k,r in zip([1,2],held)))
 summary=dict(training_cases=len(rows),control_mean=control_mean,maximum_training_air=maximum_training_air,initial_relative=initial,selected_training=current,heldout=held,new_primary_changed_from_rejected_state=newpoint,sufficient_screen=ready,robust_improvement=False,original_is_the_only_target=True,not_adopted=True,reference_match_reached=False)
 if ready:
  record('new_DSP_point_twelve_new_native_paired_validation');c=native('RelativeAirPrimaryJoint-native-validation');p=WinVST3('RelativeAirPrimaryJoint-validation-primary');z=WinVST3('RelativeAirPrimaryJoint-validation-post');clients=[(p,z)];captures=[];members=[]
  with tarfile.open(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in[10,11]:c.close();c=native('RelativeAirPrimaryJoint-native-cold-'+str(rep))
    raw,_=c.render();old=cascade(raw,p,z,R/'CONTROL_PRIMARY.bin');d0=assess(old);out=cascade(raw,p,z,R/'CANDIDATE_PRIMARY.bin');d1=assess(out);captures.append(dict(rep=rep,control=d0,candidate=d1,improvement=d0['loss']-d1['loss'],air_increase=d1['positive_excess_air_3500_6500_dB']-d0['positive_excess_air_3500_6500_dB']))
    for name,y in[('native',raw),('control',old),('candidate',out)]:add(tar,f'{name}-{rep}.wav',y,members)
    if rep==0:
     for name,y in[('NATIVE_INPUT',raw),('CONTROL',old),('CANDIDATE',out)]:sf.write(R/(name+'_00.wav'),y,48000,subtype='FLOAT')
    record('fresh6_AND_first10_cold2_and_air_limit',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  c.close();c=None;delta=np.array([r['improvement']for r in captures]);air=np.array([r['air_increase']for r in captures]);s6=float(np.std(delta[:6],ddof=1)/np.sqrt(6));s10=float(np.std(delta[:10],ddof=1)/np.sqrt(10));robust=bool(np.mean(delta[:6])>max(.0005,3*s6)and np.mean(delta[:10])>max(.0005,3*s10)and min(delta[10:])>0 and all(r['candidate']['stereo_preservation_passed']for r in captures)and np.mean(air[:10])<=.02 and max(air[10:])<=.02)
  with tarfile.open(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
  summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(np.mean(delta[:6])),first6_SEM=s6,first10_mean_improvement=float(np.mean(delta[:10])),first10_SEM=s10,cold2_improvements=delta[10:].tolist(),first10_air_increase=float(np.mean(air[:10])),cold2_air_increase=air[10:].tolist(),robust_improvement=robust)
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_relative_air_primary_joint_complete_not_adopted',sufficient_screen=ready,robust_improvement=summary['robust_improvement']);print(json.dumps({k:v for k,v in summary.items()if k not in['captures','archive_members','initial_relative','selected_training','heldout']}),flush=True)
except BaseException:record('failed_preserve_current_full32_and_BEST',error=traceback.format_exc());raise
finally:
 if c is not None:c.close()
 if fit is not None:fit.close();clients=[]
 for p,z in clients:p.close();z.close()
