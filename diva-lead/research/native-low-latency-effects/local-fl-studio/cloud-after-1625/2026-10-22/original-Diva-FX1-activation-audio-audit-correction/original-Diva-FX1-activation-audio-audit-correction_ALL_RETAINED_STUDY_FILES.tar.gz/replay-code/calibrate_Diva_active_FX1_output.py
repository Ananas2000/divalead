"""Audit actual Diva FX1 activation and stack rather than parameter labels alone."""
from pathlib import Path
import datetime,hashlib,json,os,traceback
import numpy as np,soundfile as sf
import Diva_active_FX1_output_support as q
R=q.ROOT
models=[('fresh_original', {}, set()), ('FX1_on_wet0_output_plus10', {('main', '#FX1'): 1, ('main', 'CcOp'): 129.61}, {0, 1}), ('FX1_on_wet0_output_plus20', {('main', '#FX1'): 1, ('main', 'CcOp'): 139.61}, {0, 1}), ('FX1_on_wet15_output_plus10', {('main', '#FX1'): 1, ('main', 'CcOp'): 129.61, ('Chrs1', 'Wet'): 15}, {0, 1, 182}), ('stack2_output_minus10', {('VCC', 'Voicing'): 2, ('main', 'CcOp'): 109.61}, {0, 5})]
results=[];fresh=None
try:
 for name,values,allowed in models:
  folder=R/name;folder.mkdir();h2p=folder/'Diva.h2p';h2p.write_text(q.patched(values));raw,actual=q.actual_Diva(h2p,folder/'actual-Diva');changed={i for i in q.original if actual[i]['normalized']!=q.original[i]['normalized']};assert changed==allowed,(name,changed)
  if fresh is None:fresh=raw.copy()
  error=float(np.max(np.abs(raw-fresh)));baseline_error=float(np.max(np.abs(raw-q.baseline_raw)))
  row=dict(model=name,changed_parameters={i:dict(before=q.original[i],after=actual[i])for i in sorted(changed)},all281_audited=True,all12_incoming_MIDI_events_exact=True,max_raw_error_vs_fresh_original=error,max_raw_error_vs_saved_original=baseline_error,raw_audio_changed=bool(error>0),raw_RMS=float(np.sqrt(np.mean(raw.astype(float)**2))),source_SHA256=hashlib.sha256((folder/'actual-Diva/Diva_source.wav').read_bytes()).hexdigest(),not_adopted=True)
  if name in ['FX1_on_wet15','voice_stack2']:
   cold,params=q.actual_Diva(folder/'actual-Diva/Diva_VST_chunk.bin',folder/'cold-chunk-replay');row['cold_max_error']=float(np.max(np.abs(cold-raw)));row['cold_parameters_exact']=params==actual;row['cold_chunk_resave_exact']=(folder/'cold-chunk-replay/Diva_VST_chunk.bin').read_bytes()==(folder/'actual-Diva/Diva_VST_chunk.bin').read_bytes();row['cold_audio_bit_exact']=bool(np.array_equal(cold,raw))
  results.append(row);(R/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 (R/'completion.json').write_text(json.dumps(dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),models=results,original_is_the_only_target=True,only_three_held_notes=True,reference_match_reached=False,not_adopted=True),indent=2)+'\n')
except BaseException:
 (R/'FAILURE.txt').write_text(traceback.format_exc());raise
