"""Finite-difference real-DSP Jacobian, joint bounded LM proposals; original loss unchanged."""
from pathlib import Path
import os,ast,concurrent.futures,csv,datetime,gzip,hashlib,io,json,os,queue,struct,tarfile,threading,traceback,xml.etree.ElementTree as ET
import numpy as np,soundfile as sf
import Primary_real_jacobian_constrained_support as q
from native_post_trim import NativePostTrim
R=q.ROOT;STATE=q.STATE;n=None;clients=[];pool=queue.Queue();cache=threading.local();rows=[];captures=[];members=[];lock=threading.Lock();native_inputs=[];controls=[];oldpowers=q.a.powers;oldres=q.features.residual
params={r['title']:int(r['id'])for r in csv.DictReader((q.D/'ZL-default-parameters.tsv').open(),delimiter='\t')};ns=dict(Path=Path,ET=ET,struct=struct,np=np,params=params);source=Path('/workspace/divalead-work/pc-stereo-20261024/continue_stereo_ZL_matching.py').read_text();tree=ast.parse(source)
for name in ['specs_from_component','configure']:
 node=next(v for v in tree.body if isinstance(v,ast.FunctionDef)and v.name==name);exec(compile(ast.get_source_segment(source,node),'<main-'+name+'>','exec'),ns)
specs,dynamic=ns['specs_from_component'](R/'PRIMARY.bin');ns.update(specs=specs,dynamic=dynamic);configure=ns['configure'];initial=np.array([s['value']for s in specs]);steps=np.array([s['step']for s in specs]);air_cap=low_cap=None

def powers(*args,**kw):
 v=oldpowers(*args,**kw);cache.power=v[0];return v
q.a.powers=powers
from fl20_objective import TONE,SCALES
def assess(y):
 d=q.assess(y);e=10*np.log10(np.maximum(cache.power,1e-15)/np.maximum(q.a.TP,1e-15));d['positive_excess_air_dB']=float(np.maximum(e[:,4:6,2:],0).mean());v=np.array(d['LR_dB']);d['original_stereo_preservation_passed']=bool(np.sqrt(np.mean((v[1:]-q.reference_LR[1:])**2))<=1.48 and max(abs(v[1:]))<=1.6 and abs(v[0]-q.reference_LR[0])<=3.25)
 parts=[];m=d['assessment']['metrics']
 for key in sorted(set(TONE)|set(q.a.WEIGHTS)):
  contribution=(.65*TONE.get(key,0)+.35*q.a.WEIGHTS.get(key,0))*m[key]/SCALES[key];assert contribution>=0
  if key=='H24':
   shape=np.array(q.HARMONIC_CACHE.vector,copy=True);norm=float(np.linalg.norm(shape));assert norm>0;parts.append(shape/norm*np.sqrt(contribution))
  else:parts.append(np.array([np.sqrt(contribution)]))
 gain=d['assessment']['diagnostics']['global_RMS_gain_for_AB'];parts.append(np.array([np.sqrt(.05*abs(np.log(gain))),np.sqrt(20)*max(0,d['assessment']['peak']-.95)]));cache.residual=np.concatenate(parts);np.testing.assert_allclose(cache.residual@cache.residual,d['loss']-q.reg,rtol=1e-12,atol=1e-12)
 return d

def record(phase,**kw):
 d=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),PID=os.getpid(),phase=phase,root=str(R),actual_ZL_hosts=[c.child.pid for p,z,t in clients for c in[p,z]],actual_nativeTrim_hosts=[t.chain.proc.pid for p,z,t in clients],source_Diva281_threeheld_MIDI_ARP_ADSR_native12_POST_trim_unchanged=True,all_residual_weights_alignment_and_final_quality_thresholds_unchanged=True,real_DSP_finite_difference_Jacobian_no_surrogate_audio=True,not_adopted=True,reference_match_reached=False,**kw);tmp=STATE.with_suffix('.partial');tmp.write_text(json.dumps(d,indent=2)+'\n');tmp.replace(STATE)
def project(t):
 return np.array([float(np.clip(v*2**(s['step']*d)if s['log']else v+s['step']*d,s['lo'],s['hi']))for v,s,d in zip(initial,specs,t)])
def effective(j,v):return float(np.log2(v/initial[j])/steps[j])if specs[j]['log']else float((v-initial[j])/steps[j])
def evaluate(case,indices=(0,1,2),keep=True):
 label,x=case;p,z,trim=pool.get()
 try:
  ds=[];rs=[]
  for k in indices:
   p.load(R/'PRIMARY.bin');configure(p,x);z.load(R/'POST.bin');mid,_=p.render(native_inputs[k]);pre,_=z.render(mid);y=trim.render(pre);assert p.latency()+z.latency()==0;ds.append(assess(y));rs.append(cache.residual.copy())
  row=dict(label=label,x=list(map(float,x)),loss=float(np.mean([d['loss']for d in ds])),positive_excess_air_dB=float(np.mean([d['positive_excess_air_dB']for d in ds])),lowmid_error=float(np.mean([d['lowmid_error']for d in ds])),captures=ds,original_stereo_preservation_passed=all(d['original_stereo_preservation_passed']for d in ds));row['feasible']=bool(row['original_stereo_preservation_passed']and(air_cap is None or row['positive_excess_air_dB']<=air_cap)and(low_cap is None or row['lowmid_error']<=low_cap))
  if keep:
   with lock:rows.append(row)
  return row,np.concatenate(rs)/np.sqrt(len(rs))
 finally:pool.put((p,z,trim))
def cascade(raw,component,p,z,t):
 p.load(component);z.load(R/'POST.bin');mid,_=p.render(raw);pre,_=z.render(mid);return t.render(pre)
def add(tar,name,y):
 b=io.BytesIO();sf.write(b,y,48000,format='WAV',subtype='FLOAT');data=b.getvalue();info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data));members.append(dict(name=name,bytes=len(data),SHA256=hashlib.sha256(data).hexdigest()))
(R/'PREDECLARED_PROTOCOL.json').write_text(json.dumps(dict(parameter_count=len(specs),parameters=specs,three_COMMON_actual_native_training_inputs_two_unseen=True,finite_difference_scaled_steps_plusminus05=True,both_hosts_baseline_loaded_every_case_and_neutral_identity_required=True,detailed_H24_plus_metric_residual_exactly_matches_original_loss=True,physical_bounds_and_log_parameterization_preserved=True,LM_solver_regularizations=[.001,.01,.1,1.],constrained_LM_SLSQP_actual_Air_stereo_gradients=True,trust_radii=[.5,1.,2.,4.],line_search_scales=[.25,.5,1.],reused_actual_403_baseline_Jacobian_and_native_inputs_exact=True,trainingAir_current_plus0=True,training_lowmid_current_mean_plus0005=True,strict_first6AND10_gain_over_max0005_3SEM_bothcold_positive=True,all_original_stereo148_abs16_lowmid325_localAir002_unchanged=True,latest_context_full_export_required=True),indent=2)+'\n')
try:
 for k in range(2):
  tag='RealJacConstrained-'+str(os.getpid())+'-'+str(k);p=q.WinVST3(tag+'-primary');p.load(R/'PRIMARY.bin');z=q.WinVST3(tag+'-post');z.load(R/'POST.bin');t=NativePostTrim(R/'buffers',tag+'-trim',cleanup_on_close=True);t.load(q.prior['post_native_trim_state']);clients.append((p,z,t));pool.put((p,z,t))
 record('reuse_five_recorded_actual_common_native_inputs_exact_prior403')
 for k in range(5):
  raw,sr=sf.read(q.H/'PRIMARY_REAL_JACOBIAN_FIXED_BASE'/f'TRAINING_NATIVE_{k}.wav',dtype='float32',always_2d=True);assert sr==48000;native_inputs.append(raw);os.link(q.H/'PRIMARY_REAL_JACOBIAN_FIXED_BASE'/f'TRAINING_NATIVE_{k}.wav',R/f'TRAINING_NATIVE_{k}.wav');p,z,t=clients[0];y=cascade(raw,R/'PRIMARY.bin',p,z,t);controls.append(assess(y));sf.write(R/f'TRAINING_CONTROL_{k}.wav',y,48000,subtype='FLOAT')
 neutral=[]
 for i,(host,post,nt)in enumerate(clients):
  direct=cascade(native_inputs[0],R/'PRIMARY.bin',host,post,nt);host.load(R/'PRIMARY.bin');configure(host,initial);post.load(R/'POST.bin');mid,_=host.render(native_inputs[0]);pre,_=post.render(mid);got=nt.render(pre);np.testing.assert_allclose(got,direct,rtol=8*np.finfo(np.float32).eps,atol=1e-12);neutral.append(dict(worker=i,neutral_configured_vs_direct_load_max_error=float(abs(got-direct).max()),baseline_loaded_into_both_hosts=True))
 (R/'BOTH_HOST_BASELINE_NEUTRAL_IDENTITY.json').write_text(json.dumps(neutral,indent=2)+'\n');(R/'CONTROL_ASSESSMENTS.json').write_text(json.dumps(controls,indent=2)+'\n');air_cap=float(np.mean([d['positive_excess_air_dB']for d in controls[:3]]));low_cap=min(3.25,float(np.mean([d['lowmid_error']for d in controls[:3]]))+.005);baseline,r0=evaluate(('actual-baseline',initial));columns=[];denominators=[]
 with concurrent.futures.ThreadPoolExecutor(2)as ex:
  from scipy.optimize import minimize,LinearConstraint,Bounds
  oldR=q.H/'PRIMARY_REAL_JACOBIAN_FIXED_BASE';data=np.load(oldR/'ACTUAL_SCALED_JACOBIAN.npz');J=data['J'];np.testing.assert_array_equal(data['initial'],initial);np.testing.assert_allclose(data['residual'],r0,rtol=1e-7,atol=1e-10);history=json.loads(gzip.decompress((oldR/'TRAINING_RESULTS.json.gz').read_bytes()));bylabel={r['label']:r for r in history}
  def constraints_vector(row):
   return np.array([row['positive_excess_air_dB'],row['lowmid_error'],*[d['upper_LR_error']for d in row['captures']],*[v for d in row['captures']for v in d['LR_dB'][1:]],*[d['lowmid_error']for d in row['captures']]])
  G=np.column_stack([(constraints_vector(bylabel[s['title']+'-plus'])-constraints_vector(bylabel[s['title']+'-minus']))/den for s,den in zip(specs,data['denominators'])]);c0=constraints_vector(baseline);lower=np.array([-np.inf]*5+[-1.6]*9+[-np.inf]*3);upper=np.array([air_cap,low_cap]+[1.48]*3+[1.6]*9+[3.25]*3);jtj=J.T@J;g=J.T@r0;scale=max(float(np.max(np.diag(jtj))),1e-10);cases=[];directions=[];solver_records=[]
  np.savez_compressed(R/'REUSED_ACTUAL_JACOBIAN_AND_CONSTRAINTS.npz',J=J,G=G,residual=r0,initial=initial,constraints_baseline=c0,lower=lower,upper=upper)
  for damping in[.001,.01,.1,1.]:
   Hess=jtj+damping*scale*np.eye(len(specs))
   for trust in[.5,1.,2.,4.]:
    # The stricter proposal margin is not a changed acceptance threshold.
    hi=upper-c0;hi[0]-=.003
    solve=minimize(lambda d:.5*d@Hess@d+g@d,np.zeros(len(specs)),jac=lambda d:Hess@d+g,method='SLSQP',bounds=Bounds(-trust*np.ones(len(specs)),trust*np.ones(len(specs))),constraints=[LinearConstraint(G,lower-c0,hi)],options=dict(ftol=1e-11,maxiter=300))
    rec=dict(damping=damping,trust=trust,success=bool(solve.success),message=str(solve.message),linear_constraint_max_excess=float(np.max(G@solve.x-hi)),delta=solve.x.tolist());directions.append(rec)
    if solve.success and rec['linear_constraint_max_excess']<1e-7:
     for alpha in[.25,.5,1.]:cases.append((f'constrained-LM-{damping}-trust-{trust}-scale-{alpha}',project(solve.x*alpha)))
  (R/'CONSTRAINED_SOLVER_RECORDS.json').write_text(json.dumps(directions,indent=2)+'\n');record('actual_DSP_check_of_constrained_joint_proposals',proposals=len(cases),reused_actual_Jacobian_shape=list(J.shape),all_baseline_components_and_recorded_native_inputs_identical_to_fixed_base_study=True)
  candidates=list(ex.map(evaluate,cases));valid=[row for row,r in candidates if row['feasible']];selected=min([baseline,*valid],key=lambda d:d['loss']);(R/'LM_DIRECTIONS.json').write_text(json.dumps(directions,indent=2)+'\n');held=[evaluate(('unseen-'+str(k),selected['x']),(k,),False)[0]for k in[3,4]]
 gain=float(np.mean([controls[k]['loss']-d['loss']for k,d in zip([3,4],held)]));ok=all(d['original_stereo_preservation_passed']and d['lowmid_error']<=controls[k]['lowmid_error']+.02 and d['positive_excess_air_dB']<=controls[k]['positive_excess_air_dB']+.02 for k,d in zip([3,4],held));p,z,t=clients[0];configure(p,selected['x']);component=R/'CANDIDATE_PRIMARY.bin';p.save(component);y=cascade(native_inputs[0],component,p,z,t);sf.write(R/'SELECTED_FULL_TRAINING_WIP.wav',y,48000,subtype='FLOAT');(R/'TRAINING_RESULTS.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0));summary=dict(training_cases=len(rows),actual_training_DSP_renders=3*len(rows),Jacobian_shape=list(J.shape),reused_actual_prior403_Jacobian=True,constrained_Air_stereo_trust_proposals=True,baseline=baseline,selected=selected,heldout=held,heldout_mean_gain=gain,heldout_constraints_passed=ok,component=str(component),sufficient_screen=bool(gain>.0003 and ok),robust_improvement=False,not_adopted=True,reference_match_reached=False);(R/'FROZEN_BEFORE_FRESH_VALIDATION.json').write_text(json.dumps(summary,indent=2)+'\n')
 if summary['sufficient_screen']:
  n=q.native(q.source['native_input'],'RealJacConstrained-'+str(os.getpid())+'-validation')
  with tarfile.open(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz','w:gz',compresslevel=3)as tar:
   for rep in range(12):
    if rep in[10,11]:n.close();n=q.native(q.source['native_input'],'RealJacConstrained-'+str(os.getpid())+'-cold-'+str(rep))
    raw,_=n.render();a=cascade(raw,R/'PRIMARY.bin',p,z,t);da=assess(a);b=cascade(raw,component,p,z,t);db=assess(b);captures.append(dict(rep=rep,control=da,candidate=db,improvement=da['loss']-db['loss'],air_increase=db['positive_excess_air_dB']-da['positive_excess_air_dB']))
    for name,y in [('native',raw),('control',a),('candidate',b)]:add(tar,f'{name}-{rep}.wav',y)
    if rep==0:
     for name,y in [('NATIVE_INPUT',raw),('CONTROL',a),('CANDIDATE',b)]:sf.write(R/(name+'_00.wav'),y,48000,subtype='FLOAT')
    record('joint_actual_first6AND10_cold2_validation',completed_pairs=rep+1,latest_gain=captures[-1]['improvement'])
  d=np.array([v['improvement']for v in captures]);air=np.array([v['air_increase']for v in captures]);s6=float(d[:6].std(ddof=1)/np.sqrt(6));s10=float(d[:10].std(ddof=1)/np.sqrt(10));guard=all(v['candidate']['original_stereo_preservation_passed']and v['candidate']['lowmid_error']<=v['control']['lowmid_error']+.02 for v in captures);robust=bool(d[:6].mean()>max(.0005,3*s6)and d[:10].mean()>max(.0005,3*s10)and min(d[10:])>0 and air[:10].mean()<=.02 and max(air[10:])<=.02 and guard);summary.update(captures=captures,archive_members=members,first6_mean_improvement=float(d[:6].mean()),first6_SEM=s6,first10_mean_improvement=float(d[:10].mean()),first10_SEM=s10,cold2_improvements=d[10:].tolist(),first10_air_increase=float(air[:10].mean()),cold2_air_increase=air[10:].tolist(),robust_improvement=robust)
  with tarfile.open(R/'TWELVE_NEW_NATIVE_CONTROL_CANDIDATE_WAVs.tar.gz')as tar:
   for row in members:assert hashlib.sha256(tar.extractfile(row['name']).read()).hexdigest()==row['SHA256']
 (R/'completion.json').write_text(json.dumps(summary,indent=2)+'\n');record('finite_real_Jacobian_primary_complete_not_adopted',sufficient_screen=summary['sufficient_screen'],robust_improvement=summary['robust_improvement']);print(json.dumps({k:v for k,v in summary.items()if k not in ['baseline','selected','heldout','captures','archive_members']}),flush=True)
except BaseException:record('failed_preserve_current_accepted_state',error=traceback.format_exc());raise
finally:
 if n is not None:n.close()
 for p,z,t in clients:p.close();z.close();t.close()
